import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Read the image file
const imagePath = path.join(__dirname, 'new kerurdan-02.png');
const imageBuffer = fs.readFileSync(imagePath);

// Convert to base64
const base64String = imageBuffer.toString('base64');

// Create the base64 data URL
const base64DataUrl = `data:image/png;base64,${base64String}`;

// Write to the middleGraphicBase64.ts file
fs.writeFileSync(
  path.join(__dirname, 'src', 'assets', 'middleGraphicBase64.ts'),
  `export const middleGraphicBase64 = '${base64DataUrl}';`
);

console.log('Image converted and saved to middleGraphicBase64.ts'); 