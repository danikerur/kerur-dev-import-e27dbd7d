const CACHE_NAME = 'kerurdandev-v3';
const urlsToCache = ['/', '/index.html', '/manifest.json', '/icon-192x192.png', '/icon-512x512.png'];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(urlsToCache)));
  self.skipWaiting();
});

self.addEventListener('fetch', (event) => {
  const req = event.request;

  // לא מתערבים בקריאות חיצוניות או ל-supabase
  if (!req.url.startsWith(self.location.origin) || req.url.includes('supabase.co')) return;

  // בקשות ניווט/HTML: network-first כדי למנוע גרסאות ישנות
  const isNavigation =
    req.mode === 'navigate' ||
    (req.headers.get('accept') || '').includes('text/html') ||
    req.destination === 'document';

  if (isNavigation) {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(req, copy)).catch(() => {});
          return res;
        })
        .catch(async () => {
          const cached = await caches.match(req);
          return cached || (await caches.match('/index.html'));
        })
    );
    return;
  }

  // נכסים סטטיים: cache-first עם רענון ברקע
  event.respondWith(
    caches.match(req).then((cached) => {
      const fetchPromise = fetch(req)
        .then((res) => {
          if (res && res.status === 200 && res.type === 'basic') {
            const copy = res.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(req, copy)).catch(() => {});
          }
          return res;
        })
        .catch(() => cached);
      return cached || fetchPromise;
    })
  );
});

self.addEventListener('activate', (event) => {
  const keep = [CACHE_NAME];
  event.waitUntil(
    caches
      .keys()
      .then((names) => Promise.all(names.map((n) => (keep.includes(n) ? undefined : caches.delete(n)))))
      .then(() => self.clients.claim())
  );
});
