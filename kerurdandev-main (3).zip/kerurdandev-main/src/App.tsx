import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { LoginPage } from './pages/LoginPage';
import { DashboardPage as ClientLocatorPage } from './pages/ClientLocatorPage';
import { ProductsPage } from './pages/ProductsPage';
import { AddProductPage } from './pages/AddProductPage';
import { EditProductPage } from './pages/EditProductPage';
import { CustomersPage } from './pages/CustomersPage';
import { AddCustomerPage } from './pages/AddCustomerPage';
import { EditCustomerPage } from './pages/EditCustomerPage';
import { DeliveriesPage } from './pages/DeliveriesPage';
import NewDeliveryPage from './pages/NewDeliveryPage';
import { EditDeliveryPage } from './pages/EditDeliveryPage';
import { DriversPage } from './pages/DriversPage';
import { WarehousesPage } from './pages/WarehousesPage';
import InventoryTrackingPage from './pages/InventoryTrackingPage';
import SuppliersPage from './pages/SuppliersPage';
import { QuickQuotePage } from './components/QuickQuotePage';
import QuotesPage from './pages/QuotesPage';
import { Sidebar } from './components/Sidebar';
import CustomerOrdersPage from './pages/customer-orders';
import CustomerOrderDetailsPage from './pages/customer-orders/[id]';
import NewCustomerOrderPage from './pages/customer-orders/new';
import { useAuth } from './hooks/useAuth';
import SupplierOrdersPage from './pages/SupplierOrdersPage';
import SupplierShipmentsPage from './pages/SupplierShipmentsPage';
import NewDashboardPage from './pages/NewDashboardPage';
import CategoryImagesPage from './pages/CategoryImagesPage';
import LeadsPage from './pages/LeadsPage';

function App() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-500" />
      </div>
    );
  }

  if (!user) {
    return <LoginPage />;
  }

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col lg:flex-row">
      <main className="flex-1 p-4 lg:p-8 lg:mr-64 mt-16 lg:mt-0">
        <Routes>
          <Route path="/" element={<NewDashboardPage />} />
          <Route path="/dashboard" element={<NewDashboardPage />} />
          <Route path="/dashboard-search" element={<ClientLocatorPage />} />
          <Route path="/products" element={<ProductsPage />} />
          <Route path="/products/add" element={<AddProductPage />} />
          <Route path="/products/edit/:id" element={<EditProductPage />} />
          <Route path="/customers" element={<CustomersPage />} />
          <Route path="/customers/add" element={<AddCustomerPage />} />
          <Route path="/customers/edit/:id" element={<EditCustomerPage />} />
          <Route path="/deliveries" element={<DeliveriesPage />} />
          <Route path="/deliveries/new" element={<NewDeliveryPage />} />
          <Route path="/deliveries/edit/:id" element={<EditDeliveryPage />} />
          <Route path="/drivers" element={<DriversPage />} />
          <Route path="/warehouses" element={<WarehousesPage />} />
          <Route path="/inventory" element={<InventoryTrackingPage />} />
          <Route path="/suppliers" element={<SuppliersPage />} />
          <Route path="/supplier-orders" element={<SuppliersPage />} />
          <Route path="/supplier-containers" element={<SupplierOrdersPage />} />
          <Route path="/supplier-shipments" element={<SupplierShipmentsPage />} />
          <Route path="/category-images" element={<CategoryImagesPage />} />
          <Route path="/leads" element={<LeadsPage />} />
          <Route path="/quick-quote" element={<QuickQuotePage />} />
          <Route path="/quotes" element={<QuotesPage />} />
          <Route path="/customer-orders" element={<CustomerOrdersPage />} />
          <Route path="/customer-orders/new" element={<NewCustomerOrderPage />} />
          <Route path="/customer-orders/:id" element={<CustomerOrderDetailsPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      <Sidebar />
    </div>
  );
}

export default App;