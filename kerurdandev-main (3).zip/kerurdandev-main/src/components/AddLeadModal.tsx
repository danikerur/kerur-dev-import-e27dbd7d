import React, { useState } from 'react';
import { X, Loader2 } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface AddLeadModalProps {
  onClose: () => void;
  onAdded: () => void;
}

const statusOptions = ['חדש', 'בתהליך', 'הושלם', 'לא רלוונטי'];

export default function AddLeadModal({ onClose, onAdded }: AddLeadModalProps) {
  const today = new Date().toISOString().slice(0, 10);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({
    customer_name: '',
    business_name: '',
    city: '',
    phone: '',
    inquiry_date: today,
    status: 'חדש',
    call_summary: '',
  });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!form.customer_name && !form.business_name) {
      setError('יש להזין שם לקוח או שם עסק');
      return;
    }
    if (!form.phone) {
      setError('יש להזין מספר פלאפון');
      return;
    }
    setIsLoading(true);
    const { error } = await (supabase as any)
      .from('leads')
      .insert({
        customer_name: form.customer_name || null,
        business_name: form.business_name || null,
        city: form.city || null,
        phone: form.phone || null,
        inquiry_date: form.inquiry_date,
        status: form.status,
        call_summary: form.call_summary || null,
      });
    setIsLoading(false);
    if (error) {
      setError(error.message);
      return;
    }
    onAdded();
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl">
        <div className="p-4 border-b flex justify-between items-center">
          <h2 className="text-lg font-semibold">הוספת ליד</h2>
          <button type="button" onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="w-5 h-5" />
          </button>
        </div>
        <form onSubmit={submit} className="p-4 space-y-4">
          {error && <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm">{error}</div>}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <input
              className="border rounded-md px-3 py-2"
              placeholder="שם לקוח"
              value={form.customer_name}
              onChange={(e) => setForm((v) => ({ ...v, customer_name: e.target.value }))}
            />
            <input
              className="border rounded-md px-3 py-2"
              placeholder="שם עסק"
              value={form.business_name}
              onChange={(e) => setForm((v) => ({ ...v, business_name: e.target.value }))}
            />
            <input
              className="border rounded-md px-3 py-2"
              placeholder="עיר"
              value={form.city}
              onChange={(e) => setForm((v) => ({ ...v, city: e.target.value }))}
            />
            <input
              className="border rounded-md px-3 py-2"
              placeholder="מספר פלאפון"
              value={form.phone}
              onChange={(e) => setForm((v) => ({ ...v, phone: e.target.value }))}
            />
            <input
              type="date"
              className="border rounded-md px-3 py-2"
              value={form.inquiry_date}
              onChange={(e) => setForm((v) => ({ ...v, inquiry_date: e.target.value }))}
            />
            <select
              className="border rounded-md px-3 py-2"
              value={form.status}
              onChange={(e) => setForm((v) => ({ ...v, status: e.target.value }))}
            >
              {statusOptions.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
            <textarea
              className="border rounded-md px-3 py-2 md:col-span-2"
              placeholder="סיכום שיחה / פרטים נוספים"
              value={form.call_summary}
              onChange={(e) => setForm((v) => ({ ...v, call_summary: e.target.value }))}
            />
          </div>
          <div className="flex justify-end gap-2">
            <button type="button" onClick={onClose} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">
              ביטול
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center gap-2"
            >
              {isLoading ? (<><Loader2 className="w-4 h-4 animate-spin" /> שומר...</>) : 'שמור'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}


