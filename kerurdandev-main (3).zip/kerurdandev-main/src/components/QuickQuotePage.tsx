import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import 'jspdf-autotable';
import { Plus, Trash2, Pencil } from 'lucide-react';
import { SelectProductModal } from './delivery/SelectProductModal';
import { SelectDimensionModal } from './delivery/SelectDimensionModal';
import type { Product as DeliveryProduct, Dimension as DeliveryDimension } from '../types/delivery';
import { heeboBase64 } from '../fonts/heebo';
import html2pdf from 'html2pdf.js';
import { useLocation } from 'react-router-dom';
import { middleGraphicBase64 } from '../assets/middleGraphicBase64';

// הגדרות הטיפוסים המקומיים
interface Product extends DeliveryProduct {
  product_code?: string;
  code?: string;
  image_url?: string;
  dimensions?: Dimension[];
  specifications: {
    length: number;
    width: number;
    height: number;
    depth?: number;
  };
}

interface Dimension extends DeliveryDimension {
  code?: string;
  product_code?: string;
  depth?: number;
  name?: string;
}

interface QuoteItem {
  productId?: string;
  productName?: string;
  dimensionIndex?: number;
  dimension?: Dimension;
  quantity?: number;
  unitPrice?: number;
  isManual?: boolean;
  manualText?: string;
  manualPrice?: number;
}

export function QuickQuotePage() {
  const [customerName, setCustomerName] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [vatNumber, setVatNumber] = useState('');
  const [products, setProducts] = useState<Product[]>([]);
  const [quoteItems, setQuoteItems] = useState<QuoteItem[]>([]);
  const [isProductModalOpen, setProductModalOpen] = useState(false);
  const [isDimensionModalOpen, setDimensionModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [finalTotalWithVat, setFinalTotalWithVat] = useState<number | null>(null);
  const [showPdfDiv, setShowPdfDiv] = useState(false);
  const [currentQuoteNumber, setCurrentQuoteNumber] = useState<number>(() => {
    const savedNumber = localStorage.getItem('lastQuoteNumber');
    return savedNumber ? parseInt(savedNumber) : 2999;
  });
  const location = useLocation();
  const today = new Date();
  const formattedDate = today.toLocaleDateString('he-IL');

  useEffect(() => {
    fetchProducts();
    // טען הצעת מחיר לעריכה אם יש id ב-query params
    const params = new URLSearchParams(location.search);
    const quoteId = params.get('id');
    if (quoteId) {
      (async () => {
        // טען את הצעת המחיר
        const { data: quote, error: quoteError } = await supabase
          .from('quick_quotes')
          .select('*')
          .eq('id', quoteId)
          .single();
        if (quoteError || !quote) return;
        setCustomerName(quote.client_name || '');
        setAddress(quote.client_address || '');
        setPhone(quote.client_phone || '');
        setVatNumber(quote.vat_number || '');
        // טען את המוצרים/שורות
        const { data: rows, error: rowsError } = await supabase
          .from('quick_quote_products')
          .select('*')
          .eq('quote_id', quoteId);
        if (!rowsError && rows) {
          setQuoteItems(rows.map((row: any) => {
            if (!row.product_id) {
              // שורה ידנית
              return {
                isManual: true,
                manualText: row.selected_dimension || '',
                manualPrice: row.unit_price || row.total_price || 0
              };
            } else {
              // מוצר רגיל
              return {
                productId: row.product_id,
                productName: row.product_name, // אם יש
                dimension: row.selected_dimension ? JSON.parse(row.selected_dimension) : undefined,
                quantity: row.quantity,
                unitPrice: row.unit_price
              };
            }
          }));
        }
      })();
    }
  }, [location.search]);

  const fetchProducts = async () => {
    const { data, error } = await supabase
      .from('products')
      .select('*');
    if (error) {
      console.error('Error fetching products:', error);
      return;
    }
    const parsedProducts = (data || []).map((product: any) => ({
      ...product,
      dimensions: (typeof product.dimensions === 'string'
        ? JSON.parse(product.dimensions)
        : product.dimensions
      )?.map((dim: any) => ({
        ...dim,
        code: dim.code || dim.product_code || product.product_code || product.code || ''
      }))
    }));
    console.log('products from supabase:', parsedProducts);
    setProducts(parsedProducts);
  };

  const addQuoteItem = () => {
    setProductModalOpen(true);
  };

  const addManualRow = () => {
    setQuoteItems([
      ...quoteItems,
      { isManual: true, manualText: '', manualPrice: 0 }
    ]);
  };

  const handleSelectProduct = (product: Product, variation?: { id: number; name: string }) => {
    if (variation) {
      setQuoteItems([
        ...quoteItems,
        {
          productId: product.id,
          productName: product.name,
          dimension: { id: String(variation.id), name: variation.name, length: 0, width: 0, height: 0 },
          quantity: 1,
          unitPrice: 0
        }
      ]);
      setProductModalOpen(false);
      setSelectedProduct(null);
      return;
    }
    setSelectedProduct(product);
    if (product.dimensions && product.dimensions.length > 1) {
      setDimensionModalOpen(true);
    } else {
      // מידה אחת בלבד
      let dimension: Dimension;
      if (product.dimensions && product.dimensions.length === 1) {
        const rawDimension = product.dimensions[0];
        dimension = {
          ...rawDimension,
          depth:
            rawDimension.depth ??
            rawDimension.width ??
            product.specifications.depth ??
            product.specifications.width
        };
      } else {
        dimension = {
          id: '1',
          length: product.specifications.length,
          width: product.specifications.width,
          height: product.specifications.height,
          depth:
            product.specifications.depth ??
            product.specifications.width
        };
      }
      setQuoteItems([
        ...quoteItems,
        {
          productId: product.id,
          productName: product.name,
          dimensionIndex: 0,
          dimension,
          quantity: 1,
          unitPrice: 0
        }
      ]);
      setProductModalOpen(false);
      setSelectedProduct(null);
    }
  };

  const handleSelectDimension = (dimensionIndex: number) => {
    if (!selectedProduct) return;
    const rawDimension = selectedProduct.dimensions![dimensionIndex];
    const dimension = {
      ...rawDimension,
      depth:
        rawDimension.depth ??
        rawDimension.width ??
        selectedProduct.specifications.depth ??
        selectedProduct.specifications.width
    };
    setQuoteItems([
      ...quoteItems,
      {
        productId: selectedProduct.id,
        productName: selectedProduct.name,
        dimensionIndex,
        dimension,
        quantity: 1,
        unitPrice: 0
      }
    ]);
    setDimensionModalOpen(false);
    setProductModalOpen(false);
    setSelectedProduct(null);
  };

  const removeQuoteItem = (index: number) => {
    setQuoteItems(quoteItems.filter((_, i) => i !== index));
  };

  const updateQuoteItem = (index: number, field: keyof QuoteItem, value: any) => {
    const newItems = [...quoteItems];
    newItems[index] = { ...newItems[index], [field]: value };
    setQuoteItems(newItems);
  };

  const calculateTotal = (item: QuoteItem) => {
    if (item.isManual) return item.manualPrice || 0;
    return (item.quantity || 0) * (item.unitPrice || 0);
  };
  const calculateTotalWithVat = (item: QuoteItem) => calculateTotal(item) * 1.18;

  const total = quoteItems.reduce((sum, item) => sum + calculateTotal(item), 0);
  const totalWithVat = quoteItems.reduce((sum, item) => sum + calculateTotalWithVat(item), 0);

  // כאשר המשתמש משנה את המחיר הכולל כולל מע"מ
  const handleFinalTotalWithVatChange = (value: number) => {
    setFinalTotalWithVat(value);
    // לא משנים מחירי מוצרים, רק מציגים את האחוז
  };

  // חישוב אחוז הנחה/תוספת
  let discountPercent: number | null = null;
  let discountType: 'discount' | 'addition' | null = null;
  if (finalTotalWithVat !== null && totalWithVat > 0 && finalTotalWithVat !== totalWithVat) {
    const diff = finalTotalWithVat - totalWithVat;
    discountPercent = Math.abs((diff / totalWithVat) * 100);
    discountType = diff < 0 ? 'discount' : 'addition';
  }

  // קומפוננטת PDF מוסתרת
  const pdfContent = (
    <div
      id="quote-pdf"
      style={{
        direction: 'rtl',
        fontFamily: 'Heebo, Arial, sans-serif',
        background: '#fff',
        width: '210mm',
        minHeight: '297mm',
        position: 'relative',
        boxSizing: 'border-box',
        padding: 0,
        color: '#222',
        fontSize: 14,
        visibility: showPdfDiv ? 'visible' : 'hidden',
        overflow: 'hidden',
      }}
    >
      <style>{`
        .pdf-page {
          width: 210mm;
          box-sizing: border-box;
          overflow: hidden;
        }
        .pdf-content {
          position: relative;
          z-index: 2;
          padding: 0px 16mm 0px 16mm;
          box-sizing: border-box;
          display: flex;
          flex-direction: column;
        }
      `}</style>
      <div className="pdf-page">
        <img
          src={middleGraphicBase64}
          alt="גרפיקה עליונה"
          crossOrigin="anonymous"
          style={{
            width: '100%',
            maxWidth: '210mm',
            height: 110,
            objectFit: 'contain',
            display: 'block',
            margin: '0 auto',
          }}
        />
        <div className="pdf-content">
          {/* קו דק מתחת לגרפיקה העליונה */}
          <div
            style={{
              width: '100%',
              height: '1px',
              background: 'linear-gradient(to right, transparent, #e5e7eb, transparent)',
              margin: '0 0 24px 0',
            }}
          />
          {/* תוכן ההצעה */}
          <div style={{ position: 'relative', zIndex: 2, flex: 1 }}>
            <h1 style={{
              color: '#000',
              fontSize: 24,
              fontWeight: 700,
              marginBottom: 8,
              textAlign: 'center',
              letterSpacing: 0.5,
              marginLeft: 'auto',
              marginRight: 'auto',
              marginTop: 24,
            }}>
              הצעת מחיר מס' {currentQuoteNumber}
            </h1>
            <div style={{ textAlign: 'center', fontSize: 16, color: '#444', marginBottom: 20 }}>
              תאריך: {formattedDate}
            </div>
            {/* בלוק פרטי הלקוח */}
            <div style={{
              marginBottom: 24,
              lineHeight: 1.7,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'flex-start',
              gap: 4,
              fontSize: 15,
              color: '#222',
              fontWeight: 500,
              textAlign: 'right',
            }}>
              {customerName && <div>שם לקוח: {customerName}</div>}
              {phone && <div>טלפון: {phone}</div>}
              {address && <div>כתובת: {address}</div>}
              {vatNumber && <div>ח.פ: {vatNumber}</div>}
            </div>
            {/* כרטיסי מוצרים */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16, marginBottom: 32 }}>
              {quoteItems.map((item, idx) => {
                if (item.isManual) {
                  return (
                    <div key={idx} style={{
                      background: '#f8f9fa',
                      border: '1px solid #e5e7eb',
                      borderRadius: 12,
                      padding: '18px 24px',
                      fontSize: 15,
                      color: '#222',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      minHeight: 48,
                      fontWeight: 500,
                      breakInside: 'avoid',
                      pageBreakInside: 'avoid',
                    }}>
                      <span style={{ flex: 1, textAlign: 'right' }}>{item.manualText}</span>
                      {(typeof item.manualPrice === 'number' && item.manualPrice > 0) && (
                        <span style={{ color: '#000', fontWeight: 600, marginRight: 24 }}>
                          ₪{item.manualPrice?.toLocaleString()}
                        </span>
                      )}
                    </div>
                  );
                }
                const product = products.find(p => p.id === item.productId);
                console.log('product found in PDF:', product);
                const mainProductCode = product?.product_code || product?.code || '';
                const code = item.dimension?.code || mainProductCode || '-';
                return (
                  <div key={idx} style={{
                    display: 'flex',
                    alignItems: 'center',
                    background: '#fff',
                    border: '1px solid #e5e7eb',
                    borderRadius: 12,
                    overflow: 'hidden',
                    boxShadow: '0 1px 4px rgba(0,0,0,0.05)',
                    minHeight: 140,
                    height: 140,
                    padding: 20,
                    breakInside: 'avoid',
                    pageBreakInside: 'avoid',
                  }}>
                    <div style={{
                      width: 120,
                      height: 120,
                      background: '#f3f4f6',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderRadius: 8
                    }}>
                      {product && product.image_url ? (
                        <img
                          src={product.image_url}
                          alt="מוצר"
                          crossOrigin="anonymous"
                          style={{ width: 90, height: 90, objectFit: 'cover', borderRadius: 8 }}
                        />
                      ) : (
                        <span style={{ fontSize: 12, color: '#888' }}>ללא תמונה</span>
                      )}
                    </div>
                    <div style={{
                      flex: 1,
                      display: 'flex',
                      flexDirection: 'column',
                      justifyContent: 'center',
                      gap: 8,
                      height: '100%',
                      paddingLeft: 20,
                      paddingRight: 20
                    }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingLeft: 4, paddingRight: 4 }}>
                        <div style={{ fontSize: 17, fontWeight: 600, color: '#000' }}>{item.productName}</div>
                        <div style={{ fontSize: 13, color: '#666' }}>
                          מק"ט: {code}
                        </div>
                      </div>
                      <div style={{ fontSize: 14, color: '#4b5563', paddingLeft: 4, paddingRight: 4 }}>
                        מידה: {item.dimension ? `${item.dimension.height}×${item.dimension.depth ?? item.dimension.length ?? '-'}×${item.dimension.width}` : '-'} | כמות: {item.quantity ?? '-'}
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingLeft: 4, paddingRight: 4 }}>
                        <div style={{ fontSize: 15, color: '#000' }}>מחיר ליחידה: ₪{item.unitPrice?.toLocaleString()}</div>
                        <div style={{ fontWeight: 600, color: '#000', fontSize: 17 }}>סה"כ: ₪{calculateTotal(item).toLocaleString()}</div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            {/* סה"כ כולל מע"מ */}
            <div style={{
              textAlign: 'left',
              background: '#f5f5f5',
              borderRadius: 14,
              padding: '24px 32px',
              margin: '32px 0 0 0',
              letterSpacing: 0.5,
              boxShadow: '0 1px 4px rgba(0,0,0,0.04)',
              minWidth: 320,
              maxWidth: 420,
              alignSelf: 'flex-start',
              marginLeft: 0,
              marginRight: 0,
              marginBottom: 120,
              breakInside: 'avoid',
              pageBreakInside: 'avoid',
            }}>
              {discountPercent !== null && (
                <div style={{ 
                  fontSize: 16, 
                  color: '#000', 
                  fontWeight: 600,
                  marginBottom: 16,
                  paddingBottom: 16,
                  borderBottom: '1px solid #e5e7eb'
                }}>
                  הנחה של {discountType === 'discount' ? '' : '-'}{discountPercent.toFixed(2)}% הוחלה על ההצעה
                </div>
              )}
              <div style={{ fontSize: 16, color: '#222', fontWeight: 500, marginBottom: 4 }}>
                סה"כ לפני מע"מ: ₪{total.toLocaleString()}
              </div>
              <div style={{ fontSize: 13, color: '#444', fontWeight: 400, marginBottom: 8 }}>
                מע"מ (18%): ₪{(totalWithVat - total).toLocaleString()}
              </div>
              <div style={{ fontSize: 22, color: '#000', fontWeight: 700 }}>
                סה"כ כולל מע"מ: ₪{(finalTotalWithVat ?? totalWithVat).toLocaleString()}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
  

  const generatePDF = async () => {
    console.log('🚀 generatePDF called');
    // Increment quote number and save to localStorage
    const newQuoteNumber = currentQuoteNumber + 1;
    setCurrentQuoteNumber(newQuoteNumber);
    localStorage.setItem('lastQuoteNumber', newQuoteNumber.toString());

    // Save to Supabase (quick_quotes)
    const { data: quote, error } = await supabase
  .from('quick_quotes')
  .insert([{
    client_name: customerName,
    client_address: address,
    client_phone: phone,
    vat_number: vatNumber,
    quote_number: newQuoteNumber,
    total_price: total,
    total_price_with_vat: finalTotalWithVat ?? totalWithVat,
    pdf_url: '', // יתעדכן לאחר ההעלאה
  }])
  .select()
  .single();


    if (error || !quote) {
      alert('שגיאה בשמירת הצעת המחיר למסד הנתונים');
      return;
    }

    // Save products/rows (quick_quote_products)
    const productsToInsert = quoteItems.map(item => ({
      quote_id: quote.id,
      product_id: item.isManual ? null : item.productId,
      selected_dimension: item.dimension ? JSON.stringify(item.dimension) : null,
      quantity: item.quantity ?? 1,
      unit_price: item.unitPrice ?? item.manualPrice ?? 0,
      total_price: ((item.unitPrice ?? item.manualPrice ?? 0) * (item.quantity ?? 1)),
    }));
    const { error: productsError } = await supabase.from('quick_quote_products').insert(productsToInsert);
    if (productsError) {
      alert('שגיאה בשמירת המוצרים למסד הנתונים');
      return;
    }

    setShowPdfDiv(true);
    console.log('📄 Show PDF div activated');
    setTimeout(() => {
      const element = document.getElementById('quote-pdf');
      console.log('📦 Found PDF element:', !!element);
      if (!element) return;

      const images = Array.from(element.querySelectorAll('img'));
      const imageLoadPromises = images.map(img => {
        return new Promise<void>((resolve) => {
          if (img.complete) {
            resolve();
          } else {
            img.onload = () => resolve();
            img.onerror = () => resolve();
          }
        });
      });

      Promise.all(imageLoadPromises).then(() => {
        console.log('📸 All images loaded, creating PDF');
        const safeQuoteNumber = currentQuoteNumber.toString().padStart(4, '0');
        const fileName = `quote-${safeQuoteNumber}.pdf`;
        
        const html2pdfInstance = html2pdf()
          .set({
            margin: 0,
            filename: fileName,
            html2canvas: {
              scale: 2,
              useCORS: true
            },
            jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
          })
          .from(element);

        // קבל Blob אמיתי של PDF והעלה ל-Supabase
        html2pdfInstance.output('blob').then((pdfBlob) => {
          supabase.storage
            .from('quotes')
            .upload(fileName, pdfBlob, { contentType: 'application/pdf', upsert: true })
            .then(({ data: uploadData, error: uploadError }) => {
              if (uploadError) {
                console.error('שגיאה בהעלאת ה-PDF לשרת Supabase:', uploadError);
                alert('שגיאה בהעלאת ה-PDF לשרת');
                setShowPdfDiv(false);
                return;
              }

              // קבל URL ציבורי
              const { data: publicData } = supabase.storage.from('quotes').getPublicUrl(fileName);
              const publicUrl = publicData?.publicUrl || '';
              console.log('📤 PDF public URL:', publicUrl);
              
              // עדכן את quick_quotes עם ה-URL
              supabase.from('quick_quotes')
                .update({ pdf_url: publicUrl })
                .eq('id', quote.id)
                .then(() => {
                  // הורד למשתמש
                  const url = window.URL.createObjectURL(pdfBlob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = fileName;
                  a.click();
                  window.URL.revokeObjectURL(url);
                  setShowPdfDiv(false);
                });
            });
        });
      });
    }, 100);
  };

  return (
    <div className="p-4 max-w-5xl mx-auto">
      {/* קומפוננטת PDF מוסתרת */}
      {showPdfDiv && pdfContent}
      <h1 className="text-3xl font-bold mb-8 text-right text-gray-800 tracking-tight">הצעת מחיר בדקה</h1>

      {/* Customer Details Form */}
      <div className="max-w-4xl w-full mx-auto">
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8 flex flex-col md:flex-row md:items-end gap-4">
          <div className="flex-1">
            <label className="block text-sm text-gray-500 mb-1 text-right">שם לקוח *</label>
            <input
              type="text"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-100 text-right text-lg bg-gray-50 transition"
              required
            />
          </div>
          <div className="flex-1">
            <label className="block text-sm text-gray-500 mb-1 text-right">כתובת</label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-100 text-right text-lg bg-gray-50 transition"
            />
          </div>
          <div className="flex-1">
            <label className="block text-sm text-gray-500 mb-1 text-right">טלפון</label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-100 text-right text-lg bg-gray-50 transition"
            />
          </div>
          <div className="flex-1">
            <label className="block text-sm text-gray-500 mb-1 text-right">ח.פ</label>
            <input
              type="text"
              value={vatNumber}
              onChange={(e) => setVatNumber(e.target.value)}
              className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-100 text-right text-lg bg-gray-50 transition"
            />
          </div>
        </div>
      </div>

      {/* Products Table */}
      <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold text-right text-gray-700">מוצרים להצעה</h2>
          <div className="flex gap-4">
            <div className="flex flex-col items-center">
              <button
                onClick={addQuoteItem}
                className="bg-blue-500 hover:bg-blue-600 text-white rounded-full p-3 shadow transition flex items-center justify-center"
                title="הוסף מוצר"
              >
                <Plus className="w-6 h-6" />
              </button>
              <span className="text-xs text-gray-600 mt-1">הוסף מוצר</span>
            </div>
            <div className="flex flex-col items-center">
              <button
                onClick={addManualRow}
                className="bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-full p-3 shadow transition flex items-center justify-center"
                title="הוסף שורת טקסט"
              >
                <Pencil className="w-6 h-6" />
                <Plus className="w-3 h-3 -ml-2 -mt-2 absolute" />
              </button>
              <span className="text-xs text-gray-600 mt-1">הוסף שורת טקסט</span>
            </div>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-right border-separate border-spacing-y-2">
            <thead>
              <tr className="bg-gray-50 text-gray-600">
                <th className="p-2 font-medium">מוצר</th>
                <th className="p-2 font-medium">מידה</th>
                <th className="p-2 font-medium">כמות</th>
                <th className="p-2 font-medium">מחיר ליחידה</th>
                <th className="p-2 font-medium">סה"כ</th>
                <th className="p-2 font-medium">סה"כ כולל מע"מ</th>
                <th className="p-2"></th>
              </tr>
            </thead>
            <tbody>
              {quoteItems.length === 0 && (
                <tr>
                  <td colSpan={7} className="text-center text-gray-400 py-8">לא נבחרו מוצרים</td>
                </tr>
              )}
              {quoteItems.map((item, index) => (
                item.isManual ? (
                  <tr key={index} className={index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                    <td colSpan={2} className="p-2" style={{ minWidth: 200 }}>
                      <input
                        type="text"
                        value={item.manualText}
                        onChange={e => updateQuoteItem(index, 'manualText', e.target.value)}
                        className="w-full px-2 py-1 rounded-lg border border-gray-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-100 text-right bg-gray-50"
                        placeholder="הזן טקסט חופשי (למשל: אחריות לשנה, הובלה חינם...)"
                      />
                    </td>
                    <td></td>
                    <td></td>
                    <td className="p-2 text-blue-700 font-bold">
                      <input
                        type="number"
                        value={item.manualPrice === 0 ? '' : item.manualPrice}
                        onChange={e => updateQuoteItem(index, 'manualPrice', Number(e.target.value))}
                        className="w-24 px-2 py-1 rounded-lg border border-gray-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-100 text-right bg-gray-50"
                        placeholder="₪"
                        min="0"
                      />
                    </td>
                    <td className="p-2 text-green-700 font-bold">₪{calculateTotalWithVat(item).toFixed(2)}</td>
                    <td className="p-2">
                      <button
                        onClick={() => removeQuoteItem(index)}
                        className="text-red-500 hover:text-red-700 rounded-full p-2 bg-red-50 hover:bg-red-100 transition"
                        title="מחק שורה"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </td>
                  </tr>
                ) : (
                  <tr key={index} className={index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                    <td className="p-2 font-medium text-gray-800">
                      {item.productName}
                      {item.dimension?.name && (
                        <div className="text-xs text-gray-500 mt-1">{item.dimension.name}</div>
                      )}
                    </td>
                    <td className="p-2 text-gray-600">
                      {(() => {
                        if (item.dimension) {
                          console.log('QuickQuote Table - Dimension object:', item.dimension);
                          console.log('QuickQuote Table - Length:', item.dimension.length, 'Depth:', item.dimension.depth, 'Height:', item.dimension.height);
                        }
                        return null;
                      })()}
                                             {item.dimension?.depth ?? '-'}×{item.dimension?.height}×{item.dimension?.length}
                    </td>
                    <td className="p-2">
                      <input
                        type="number"
                        value={item.quantity}
                        onChange={(e) => updateQuoteItem(index, 'quantity', Number(e.target.value))}
                        className="w-20 px-2 py-1 rounded-lg border border-gray-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-100 text-right bg-gray-50"
                        min="1"
                      />
                    </td>
                    <td className="p-2">
                      <input
                        type="number"
                        value={item.unitPrice}
                        onChange={(e) => updateQuoteItem(index, 'unitPrice', Number(e.target.value))}
                        className="w-24 px-2 py-1 rounded-lg border border-gray-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-100 text-right bg-gray-50"
                        min="0"
                      />
                    </td>
                    <td className="p-2 text-blue-700 font-bold">₪{calculateTotal(item)}</td>
                    <td className="p-2 text-green-700 font-bold">₪{calculateTotalWithVat(item).toFixed(2)}</td>
                    <td className="p-2">
                      <button
                        onClick={() => removeQuoteItem(index)}
                        className="text-red-500 hover:text-red-700 rounded-full p-2 bg-red-50 hover:bg-red-100 transition"
                        title="מחק מוצר"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </td>
                  </tr>
                )
              ))}
            </tbody>
            <tfoot>
              <tr className="font-bold bg-gray-100">
                <td colSpan={4} className="text-right p-2">סה"כ לפני מע"מ</td>
                <td className="text-blue-700 p-2">₪{total.toFixed(2)}</td>
                <td></td>
                <td></td>
              </tr>
              <tr className="font-bold bg-gray-100">
                <td colSpan={4} className="text-right p-2">סה"כ כולל מע"מ (18%)</td>
                <td className="text-green-700 p-2 text-2xl">₪{totalWithVat.toFixed(2)}</td>
                <td></td>
                <td></td>
              </tr>
              <tr className="font-bold bg-gray-100">
                <td colSpan={4} className="text-right p-2">סדר מחיר סופי כולל מע"מ</td>
                <td className="p-2">
                  <input
                    type="number"
                    value={finalTotalWithVat === null ? totalWithVat.toFixed(2) : finalTotalWithVat}
                    onChange={e => handleFinalTotalWithVatChange(Number(e.target.value))}
                    className="w-32 px-2 py-1 rounded-lg border border-gray-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-100 text-right bg-gray-50 text-xl font-bold"
                    min="0"
                  />
                  {/* הצגת אחוז הנחה/תוספת */}
                  {discountPercent !== null && (
                    <div className={discountType === 'discount' ? 'text-green-600 mt-2 text-sm font-bold' : 'text-orange-600 mt-2 text-sm font-bold'}>
                      {discountType === 'discount'
                        ? `הנחה של ${discountPercent.toFixed(2)}%`
                        : `תוספת של ${discountPercent.toFixed(2)}%`}
                    </div>
                  )}
                </td>
                <td></td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Generate PDF Button */}
      <div className="flex justify-center mt-8">
        <button
          onClick={generatePDF}
          disabled={!customerName || quoteItems.length === 0}
          className="bg-green-500 hover:bg-green-600 text-white rounded-full p-4 shadow-lg flex items-center gap-2 text-lg font-bold disabled:bg-gray-300 disabled:cursor-not-allowed transition"
          title="צור PDF"
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
            <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75A2.25 2.25 0 0014.25 4.5h-4.5A2.25 2.25 0 007.5 6.75v6.75m9 0V17.25A2.25 2.25 0 0114.25 19.5h-4.5A2.25 2.25 0 017.5 17.25v-3.75m9 0h-9" />
          </svg>
          צור PDF
        </button>
      </div>

      {/* מודלים */}
      {isProductModalOpen && (
        <SelectProductModal
          products={products}
          searchTerm={searchTerm}
          onSearchChange={setSearchTerm}
          onSelectProduct={handleSelectProduct}
          onClose={() => setProductModalOpen(false)}
        />
      )}
      {isDimensionModalOpen && selectedProduct && (
        <SelectDimensionModal
          product={selectedProduct}
          onSelectDimension={handleSelectDimension}
          onClose={() => {
            setDimensionModalOpen(false);
            setProductModalOpen(false);
            setSelectedProduct(null);
          }}
        />
      )}
    </div>
  );
} 