import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

interface Supplier {
  id: number;
  name: string;
  // Add other fields as needed
}

export default function SuppliersTest() {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchSuppliers() {
      try {
        const { data, error } = await supabase
          .from('suppliers')
          .select('*');

        if (error) {
          throw error;
        }

        setSuppliers(data || []);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An error occurred');
      } finally {
        setLoading(false);
      }
    }

    fetchSuppliers();
  }, []);

  if (loading) return <div>Loading suppliers...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Suppliers Test</h2>
      {suppliers.length === 0 ? (
        <p>No suppliers found</p>
      ) : (
        <ul className="space-y-2">
          {suppliers.map((supplier) => (
            <li key={supplier.id} className="p-2 bg-gray-100 rounded">
              {supplier.name}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
} 