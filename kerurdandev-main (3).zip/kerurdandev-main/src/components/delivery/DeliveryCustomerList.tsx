import React from 'react';
import { MapPin } from 'lucide-react';
import type { DeliveryCustomer } from '../../types/delivery';

interface Props {
  customers: DeliveryCustomer[];
}

export function DeliveryCustomerList({ customers }: Props) {
  const sortedCustomers = [...customers].sort((a, b) => a.order - b.order);

  const getProductDimensions = (product: any, dimensionIndex?: number) => {
    // Check if product has dimensions array and it's not empty
    if (product.dimensions && Array.isArray(product.dimensions) && product.dimensions.length > 0) {
      const dimension = product.dimensions[dimensionIndex || 0] || product.dimensions[0];
      return dimension;
    }
    
    // Check if product has specifications with dimensions
    if (product.specifications && typeof product.specifications === 'object') {
      const { length = 0, width = 0, height = 0 } = product.specifications;
      return { length, width, height };
    }

    // Return default dimensions if no valid data is found
    return { length: 0, width: 0, height: 0 };
  };

  return (
    <div className="mt-4 space-y-3 pr-10">
      {sortedCustomers.map((customer, index) => (
        <div key={customer.id} className="flex items-start gap-3 p-2 rounded-lg bg-gray-50">
          <div className="bg-blue-100 text-blue-800 text-sm font-medium px-2 py-0.5 rounded-full flex-shrink-0">
            {index + 1}
          </div>
          <div>
            <div className="font-medium">{customer.customer.name}</div>
            <div className="text-sm text-gray-500">{customer.customer.phone}</div>
            <div className="text-sm text-gray-500 flex items-center gap-1">
              <MapPin className="w-4 h-4" />
              {customer.address}
            </div>
            {customer.products.length > 0 && (
              <div className="mt-2 space-y-1">
                <div className="text-xs text-gray-500">מוצרים:</div>
                {customer.products.map((product) => {
                  const dimensions = getProductDimensions(product.product, product.dimension_index);
                  return (
                    <div key={product.id} className="text-sm">
                      <div className="font-medium">
                        {product.product.name} - כמות: {product.quantity}
                      </div>
                      <div className="text-gray-500 text-xs">
                        מידות: {dimensions.length} × {dimensions.width} × {dimensions.height} ס"מ
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}