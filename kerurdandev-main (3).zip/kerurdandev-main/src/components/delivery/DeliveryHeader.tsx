import React from 'react';
import { Link } from 'react-router-dom';
import { Plus, FileSpreadsheet } from 'lucide-react';

interface Props {
  onExport: () => void;
}

export function DeliveryHeader({ onExport }: Props) {
  return (
    <div className="flex justify-between items-center mb-6">
      <h1 className="text-2xl font-bold">ניהול אספקות</h1>
      <div className="flex gap-2">
        <button
          onClick={onExport}
          className="bg-green-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-green-700"
        >
          <FileSpreadsheet className="w-5 h-5" />
          ייצא לאקסל
        </button>
        <Link
          to="/deliveries/new"
          className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700"
        >
          <Plus className="w-5 h-5" />
          אספקה חדשה
        </Link>
      </div>
    </div>
  );
}