import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, ChevronUp, ChevronDown, ChevronRight, Check, Ban, Printer, Trash2 } from 'lucide-react';
import type { Delivery } from '../../types/delivery';
import { DeliveryCustomerList } from './DeliveryCustomerList';

interface Props {
  delivery: Delivery;
  isExpanded: boolean;
  onToggleExpand: () => void;
  onUpdateStatus: (status: 'completed' | 'canceled') => void;
  onPrint: () => void;
  onDelete: () => void;
  getStatusText: (status: string) => string;
  getStatusColor: (status: string) => string;
}

export function DeliveryItem({
  delivery,
  isExpanded,
  onToggleExpand,
  onUpdateStatus,
  onPrint,
  onDelete,
  getStatusText,
  getStatusColor
}: Props) {
  console.log('DeliveryItem rendered for delivery:', delivery.id);
  return (
    <div className="p-4 hover:bg-gray-50">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={onToggleExpand}
            className="p-1 hover:bg-gray-200 rounded-full transition-colors"
          >
            {isExpanded ? (
              <ChevronUp className="w-5 h-5" />
            ) : (
              <ChevronDown className="w-5 h-5" />
            )}
          </button>
          
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-gray-400" />
            <span>
              {delivery.delivery_date
                ? new Date(delivery.delivery_date).toLocaleDateString('he-IL')
                : 'לא נקבע'}
            </span>
          </div>

          <div>
            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(delivery.status)}`}>
              {getStatusText(delivery.status)}
            </span>
          </div>

          {delivery.driver && (
            <div className="text-sm">
              <span className="font-medium">{delivery.driver.full_name}</span>
              <span className="text-gray-500 mr-2">{delivery.driver.phone}</span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          <Link
            to={`/deliveries/edit/${delivery.id}`}
            className="p-1 text-blue-600 hover:bg-blue-50 rounded transition-colors"
            title="ערוך אספקה"
          >
            <ChevronRight className="w-5 h-5" />
          </Link>

          {delivery.status === 'planned' && (
            <>
              <button
                onClick={() => onUpdateStatus('completed')}
                className="p-1 text-green-600 hover:bg-green-50 rounded transition-colors"
                title="סמן כהושלמה"
              >
                <Check className="w-5 h-5" />
              </button>

              <button
                onClick={() => onUpdateStatus('canceled')}
                className="p-1 text-red-600 hover:bg-red-50 rounded transition-colors"
                title="בטל אספקה"
              >
                <Ban className="w-5 h-5" />
              </button>
            </>
          )}

          <button
            onClick={onPrint}
            className="p-1 text-gray-600 hover:bg-gray-100 rounded transition-colors"
            title="הדפס אספקה"
          >
            <Printer className="w-5 h-5" />
          </button>

          <button
            onClick={() => {
              console.log('Delete button clicked for delivery:', delivery.id);
              onDelete();
            }}
            className="p-1 text-red-600 hover:bg-red-50 rounded transition-colors"
            title="מחק אספקה"
          >
            <Trash2 className="w-5 h-5" />
          </button>
        </div>
      </div>

      {isExpanded && <DeliveryCustomerList customers={delivery.customers} />}
    </div>
  );
}