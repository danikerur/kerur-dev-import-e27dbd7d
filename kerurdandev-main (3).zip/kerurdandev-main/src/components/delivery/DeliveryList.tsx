import React from 'react';
import { Link } from 'react-router-dom';
import { Plus, Truck } from 'lucide-react';
import type { MonthGroup } from '../../types/delivery';
import { DeliveryItem } from './DeliveryItem';

interface Props {
  groupedDeliveries: MonthGroup[];
  expandedDeliveries: Set<string>;
  onToggleExpand: (deliveryId: string) => void;
  onUpdateStatus: (deliveryId: string, status: 'completed' | 'canceled') => void;
  onPrint: (deliveryId: string) => void;
  onDelete: (deliveryId: string) => void;
  getStatusText: (status: string) => string;
  getStatusColor: (status: string) => string;
}

export function DeliveryList({
  groupedDeliveries,
  expandedDeliveries,
  onToggleExpand,
  onUpdateStatus,
  onPrint,
  onDelete,
  getStatusText,
  getStatusColor
}: Props) {
  console.log('DeliveryList rendered with deliveries:', groupedDeliveries.map(g => g.deliveries.map(d => d.id)).flat());
  if (groupedDeliveries.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-md p-8 text-center">
        <Truck className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <h2 className="text-xl font-medium text-gray-900 mb-2">אין אספקות</h2>
        <p className="text-gray-500 mb-4">
          התחל על ידי יצירת אספקה חדשה
        </p>
        <Link
          to="/deliveries/new"
          className="inline-flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
        >
          <Plus className="w-5 h-5" />
          צור אספקה חדשה
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {groupedDeliveries.map(group => (
        <div key={`${group.year}-${group.month}`}>
          <h2 className="text-lg font-semibold mb-4">
            {group.month} {group.year}
          </h2>

          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="divide-y divide-gray-200">
              {group.deliveries.map((delivery) => (
                <DeliveryItem
                  key={delivery.id}
                  delivery={delivery}
                  isExpanded={expandedDeliveries.has(delivery.id)}
                  onToggleExpand={() => onToggleExpand(delivery.id)}
                  onUpdateStatus={(status) => onUpdateStatus(delivery.id, status)}
                  onPrint={() => onPrint(delivery.id)}
                  onDelete={() => onDelete(delivery.id)}
                  getStatusText={getStatusText}
                  getStatusColor={getStatusColor}
                />
              ))}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}