import React, { useState } from 'react';
import { X, FileSpreadsheet, Calendar, CalendarRange } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import * as XLSX from 'xlsx';

interface Props {
  onClose: () => void;
}

type ExportType = 'date-range' | 'month';

export function ExportDeliveriesModal({ onClose }: Props) {
  const [exportType, setExportType] = useState<ExportType>('date-range');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedMonth, setSelectedMonth] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleExport = async () => {
    setIsLoading(true);

    try {
      let query = supabase
        .from('deliveries')
        .select(`
          delivery_date,
          driver:drivers(full_name),
          customers:delivery_customers(
            address,
            customer:customers(name)
          )
        `)
        .order('delivery_date', { ascending: true });

      if (exportType === 'date-range') {
        if (!startDate || !endDate) {
          alert('יש לבחור תאריך התחלה ותאריך סיום');
          return;
        }
        query = query
          .gte('delivery_date', startDate)
          .lte('delivery_date', endDate);
      } else {
        if (!selectedMonth) {
          alert('יש לבחור חודש');
          return;
        }
        const [year, month] = selectedMonth.split('-');
        const startOfMonth = `${year}-${month}-01`;
        const endOfMonth = `${year}-${month}-${new Date(parseInt(year), parseInt(month), 0).getDate()}`;
        query = query
          .gte('delivery_date', startOfMonth)
          .lte('delivery_date', endOfMonth);
      }

      const { data: deliveries, error } = await query;

      if (error) throw error;

      if (!deliveries || deliveries.length === 0) {
        alert('לא נמצאו אספקות בטווח התאריכים שנבחר');
        return;
      }

      // Prepare data for Excel - simple format
      const excelData = deliveries.flatMap(delivery => 
        delivery.customers.map(customer => ({
          'תאריך אספקה': new Date(delivery.delivery_date).toLocaleDateString('he-IL'),
          'שם לקוח': customer.customer.name,
          'כתובת': customer.address,
          'שם מוביל': delivery.driver?.full_name || 'לא נקבע'
        }))
      );

      // Create workbook and worksheet
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.json_to_sheet(excelData, { 
        header: [
          'תאריך אספקה',
          'שם לקוח',
          'כתובת',
          'שם מוביל'
        ]
      });

      // Set column widths
      const colWidths = [
        { wch: 15 },  // תאריך אספקה
        { wch: 25 },  // שם לקוח
        { wch: 40 },  // כתובת
        { wch: 20 }   // שם מוביל
      ];
      ws['!cols'] = colWidths;

      // Add worksheet to workbook
      XLSX.utils.book_append_sheet(wb, ws, 'אספקות');

      // Generate filename based on export type
      let filename = '';
      if (exportType === 'date-range') {
        filename = `אספקות_${startDate}_עד_${endDate}.xlsx`;
      } else {
        const [year, month] = selectedMonth.split('-');
        const monthName = new Date(parseInt(year), parseInt(month) - 1).toLocaleString('he-IL', { month: 'long' });
        filename = `אספקות_${monthName}_${year}.xlsx`;
      }

      // Save file
      XLSX.writeFile(wb, filename);
      onClose();
    } catch (error) {
      console.error('Error exporting deliveries:', error);
      alert('שגיאה בייצוא האספקות. אנא נסה שוב.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
        <div className="p-4 border-b flex justify-between items-center">
          <h2 className="text-lg font-semibold">ייצוא אספקות לאקסל</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-4">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                בחר שיטת ייצוא
              </label>
              <div className="grid grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => setExportType('date-range')}
                  className={`p-4 border rounded-lg flex flex-col items-center gap-2 ${
                    exportType === 'date-range'
                      ? 'border-blue-500 bg-blue-50 text-blue-700'
                      : 'hover:bg-gray-50'
                  }`}
                >
                  <CalendarRange className="w-6 h-6" />
                  <span>טווח תאריכים</span>
                </button>
                <button
                  type="button"
                  onClick={() => setExportType('month')}
                  className={`p-4 border rounded-lg flex flex-col items-center gap-2 ${
                    exportType === 'month'
                      ? 'border-blue-500 bg-blue-50 text-blue-700'
                      : 'hover:bg-gray-50'
                  }`}
                >
                  <Calendar className="w-6 h-6" />
                  <span>חודש</span>
                </button>
              </div>
            </div>

            {exportType === 'date-range' ? (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    מתאריך
                  </label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    עד תאריך
                  </label>
                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              </div>
            ) : (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  בחר חודש
                </label>
                <input
                  type="month"
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(e.target.value)}
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
            )}
          </div>

          <div className="flex justify-end gap-3 mt-6">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
            >
              ביטול
            </button>
            <button
              type="button"
              onClick={handleExport}
              disabled={isLoading}
              className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 disabled:opacity-50 flex items-center gap-2"
            >
              {isLoading ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
                  מייצא...
                </>
              ) : (
                <>
                  <FileSpreadsheet className="w-5 h-5" />
                  ייצא לאקסל
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}