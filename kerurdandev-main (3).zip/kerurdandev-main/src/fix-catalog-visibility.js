// Script to fix catalog visibility for all products
import { supabase } from './lib/supabase';

async function fixCatalogVisibility() {
  console.log('Starting catalog visibility fix...');
  
  try {
    // First, check current products and their visibility
    const { data: beforeProducts, error: beforeError } = await supabase
      .from('products')
      .select('id, name, catalog_visible');
    
    if (beforeError) {
      throw new Error(`Error fetching products: ${beforeError.message}`);
    }
    
    console.log(`Found ${beforeProducts.length} products`);
    console.log(`Visible products before fix: ${beforeProducts.filter(p => p.catalog_visible === true).length}`);
    console.log(`Hidden products before fix: ${beforeProducts.filter(p => p.catalog_visible === false).length}`);
    console.log(`Null visibility products: ${beforeProducts.filter(p => p.catalog_visible === null).length}`);
    
    // Update all products to be visible
    const { data: updateData, error: updateError } = await supabase
      .from('products')
      .update({ catalog_visible: true })
      .is('catalog_visible', null);
    
    if (updateError) {
      throw new Error(`Error updating null visibility products: ${updateError.message}`);
    }
    
    console.log(`Updated ${updateData?.length || 0} products with null visibility`);
    
    // Update products with false visibility
    const { data: updateFalseData, error: updateFalseError } = await supabase
      .from('products')
      .update({ catalog_visible: true })
      .eq('catalog_visible', false);
    
    if (updateFalseError) {
      throw new Error(`Error updating hidden products: ${updateFalseError.message}`);
    }
    
    console.log(`Updated ${updateFalseData?.length || 0} hidden products`);
    
    // Check products after update
    const { data: afterProducts, error: afterError } = await supabase
      .from('products')
      .select('id, name, catalog_visible');
    
    if (afterError) {
      throw new Error(`Error fetching products after update: ${afterError.message}`);
    }
    
    console.log(`Visible products after fix: ${afterProducts.filter(p => p.catalog_visible === true).length}`);
    console.log(`Hidden products after fix: ${afterProducts.filter(p => p.catalog_visible === false).length}`);
    console.log(`Null visibility products after fix: ${afterProducts.filter(p => p.catalog_visible === null).length}`);
    
    console.log('Catalog visibility fix completed successfully!');
    
    return { success: true, message: 'Catalog visibility fixed successfully' };
  } catch (error) {
    console.error('Error fixing catalog visibility:', error);
    return { success: false, error: error.message };
  }
}

export { fixCatalogVisibility };