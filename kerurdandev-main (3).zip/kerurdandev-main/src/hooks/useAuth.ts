import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import type { User } from '@supabase/supabase-js';

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    // Get initial session
    const initAuth = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (mounted) {
          if (session?.user) {
            setUser(session.user);
          } else {
            setUser(null);
            // If no session, ensure we're signed out
            await supabase.auth.signOut();
          }
          setLoading(false);
        }
      } catch (error) {
        console.error('Error getting auth session:', error);
        if (mounted) {
          setUser(null);
          setLoading(false);
          // Clear invalid session and tokens
          await supabase.auth.signOut();
          // Clear any remaining auth data from localStorage
          try {
            Object.keys(localStorage)
              .filter((k) => k.startsWith('sb-') || k.startsWith('supabase.auth'))
              .forEach((k) => localStorage.removeItem(k));
          } catch {
            /* ignore */
          }
        }
      }
    };

    initAuth();

    // Listen for auth changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (mounted) {
        if (event === 'SIGNED_OUT' || event === 'USER_DELETED') {
          setUser(null);
          // Ensure complete signout and cleanup
          await supabase.auth.signOut();
          try {
            Object.keys(localStorage)
              .filter((k) => k.startsWith('sb-') || k.startsWith('supabase.auth'))
              .forEach((k) => localStorage.removeItem(k));
          } catch {
            /* ignore */
          }
        } else if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
          setUser(session?.user ?? null);
        }
        setLoading(false);
      }
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  return { user, loading };
}