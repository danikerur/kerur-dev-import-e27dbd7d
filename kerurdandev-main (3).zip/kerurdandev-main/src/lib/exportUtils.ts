import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';

interface OrderItem {
  modelName: string;
  dimensions: string;
  quantity: number;
}

export const exportOrderToPDF = (items: OrderItem[], supplierName: string, orderNumber: number | null) => {
  const doc = new jsPDF();
  
  // Header styling
  doc.setFontSize(18);
  doc.text(`Purchase Order${supplierName ? ' – ' + supplierName : ''}`, 14, 20);
  
  doc.setFontSize(12);
  doc.text(`Order #${orderNumber ?? ''}`, 14, 30);
  doc.text(`Supplier: ${String(supplierName || '')}`, 14, 38);
  doc.text(`Date: ${new Date().toLocaleDateString()}`, 14, 46);
  
  // Prepare table data
  const tableBody: any[] = [];
  items.forEach((item, idx) => {
    const modelName = String(item.modelName || '');
    const dimensions = String(item.dimensions || '');
    const quantity = String(item.quantity ?? '');
    if (!modelName || !dimensions || !quantity) {
      console.error('Skipping row in PDF export due to missing data:', { modelName, dimensions, quantity, idx });
      return;
    }
    tableBody.push([modelName, dimensions, quantity]);
  });
  
  // Add some vertical space before the table
  const tableStartY = 56;
  
  autoTable(doc, {
    head: [['Model Name', 'Dimensions (W×D×H)', 'Quantity']],
    body: tableBody,
    startY: tableStartY,
    margin: { left: 14, right: 14 },
    styles: {
      fontSize: 11,
      cellPadding: 3,
      valign: 'middle',
    },
    headStyles: {
      fillColor: [41, 128, 185],
      textColor: 255,
      fontStyle: 'bold',
    },
    alternateRowStyles: { fillColor: [245, 245, 245] },
    tableLineColor: [200, 200, 200],
    tableLineWidth: 0.1,
  });
  
  // Save the PDF
  doc.save(`order_${supplierName}_${orderNumber || ''}_${new Date().toISOString().split('T')[0]}.pdf`);
};

export const exportOrderToCSV = (items: OrderItem[], supplierName: string, orderNumber: number | null) => {
  const headers = ['Model Name', 'Dimensions (W×D×H)', 'Quantity'];
  let csvContent = '';
  csvContent += `Purchase Order - ${String(supplierName || '')}\n`;
  if (orderNumber) {
    csvContent += `Order #${orderNumber}\n`;
  }
  csvContent += `Date: ${new Date().toLocaleDateString()}\n`;
  csvContent += headers.join(',') + '\n';
  csvContent += items.map(item => [
    String(item.modelName || ''),
    String(item.dimensions || ''),
    String(item.quantity ?? '')
  ].join(',')).join('\n');
  
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', `order_${supplierName}_${orderNumber || ''}_${new Date().toISOString().split('T')[0]}.csv`);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}; 