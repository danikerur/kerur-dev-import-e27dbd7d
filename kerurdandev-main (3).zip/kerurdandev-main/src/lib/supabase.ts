import { createClient } from '@supabase/supabase-js';
import { Database } from './database.types';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Basic runtime validation to surface config issues early
if (!supabaseUrl || !supabaseAnonKey) {
  // eslint-disable-next-line no-console
  console.error(
    'Supabase configuration is missing. Check VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY.'
  );
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
    // Use the browser's localStorage directly (SDK handles serialization)
    storage: localStorage,
  },
  db: {
    schema: 'public',
  },
});

// Handle auth state changes globally
supabase.auth.onAuthStateChange((event) => {
  if (event === 'TOKEN_REFRESHED') {
    // eslint-disable-next-line no-console
    console.log('Token refreshed successfully');
  } else if (event === 'SIGNED_OUT') {
    // Clear all Supabase auth cache (including legacy/custom keys) to avoid loops
    try {
      Object.keys(localStorage)
        .filter((k) => k.startsWith('sb-') || k.startsWith('supabase.auth'))
        .forEach((k) => localStorage.removeItem(k));
    } catch {
      /* ignore */
    }
    // eslint-disable-next-line no-console
    console.log('User signed out, cleared auth data');
  }
});