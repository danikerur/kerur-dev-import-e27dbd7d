import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { ChevronDown, ChevronRight, Search, Loader2, X, Info, ChevronLeft, Filter, SlidersHorizontal } from 'lucide-react';
import { DotPattern } from '../components/ui/dot-pattern';
import { cn } from '../lib/utils';

interface Dimension {
  id: string;
  length: number;
  width: number;
  height: number;
}

interface Product {
  id: string;
  name: string;
  description: string;
  image_url: string;
  specifications: {
    length: number;
    width: number;
    height: number;
  };
  dimensions?: Dimension[];
  catalog_visible?: boolean;
  catalog_order?: number;
  category_id: string | null;
  tag?: string;
}

interface Category {
  id: string;
  name: string;
  parent_id: string | null;
}

export function CatalogPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set());
  const [selectedDimensions, setSelectedDimensions] = useState<Record<string, number>>({});
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [showMobileFilters, setShowMobileFilters] = useState(false);
  const [showDesktopFilters, setShowDesktopFilters] = useState(false);

  useEffect(() => {
    fetchProducts();
    fetchCategories();
  }, []);

  async function fetchProducts() {
    setIsLoading(true);
    setError(null);
    try {
      console.log('Fetching products for catalog...');
      const { data, error } = await supabase
        .from('products')
        .select('*, dimensions(*)')
        .order('catalog_order', { ascending: true })
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching products:', error);
        setError('שגיאה בטעינת המוצרים. אנא רענן את העמוד ונסה שוב.');
        return;
      }

      console.log('Fetched products:', data?.length || 0);
      
      // Filter visible products
      const visibleProducts = data?.filter(p => p.catalog_visible !== false) || [];
      console.log('Visible products:', visibleProducts.length);

      // Initialize selected dimensions to the first dimension for each product
      const initialDimensions: Record<string, number> = {};
      visibleProducts.forEach(product => {
        if (product.dimensions && product.dimensions.length > 0) {
          initialDimensions[product.id] = 0; // Select first dimension by default
        }
      });
      
      setSelectedDimensions(initialDimensions);
      setProducts(visibleProducts);
    } catch (err) {
      console.error('Error in fetchProducts:', err);
      setError('שגיאה בטעינת המוצרים. אנא רענן את העמוד ונסה שוב.');
    } finally {
      setIsLoading(false);
    }
  }

  async function fetchCategories() {
    try {
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .order('name');

      if (error) {
        console.error('Error fetching categories:', error);
        return;
      }

      setCategories(data || []);
    } catch (err) {
      console.error('Error in fetchCategories:', err);
    }
  }

  // Get parent categories only
  const parentCategories = categories.filter(cat => !cat.parent_id);

  // Get child categories for a specific parent
  const getChildCategories = (parentId: string) => {
    return categories.filter(cat => cat.parent_id === parentId);
  };

  // Toggle category expansion
  const toggleCategory = (categoryId: string) => {
    setExpandedCategories(prev => {
      const newSet = new Set(prev);
      if (newSet.has(categoryId)) {
        newSet.delete(categoryId);
      } else {
        newSet.add(categoryId);
      }
      return newSet;
    });
  };

  // Filter products based on search and selected category
  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.description?.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (!selectedCategory) {
      return matchesSearch;
    }
    
    // Check if selected category is a parent category
    const selectedCat = categories.find(c => c.id === selectedCategory);
    if (selectedCat && !selectedCat.parent_id) {
      // If it's a parent category, include all products from its child categories
      const childCatIds = categories
        .filter(c => c.parent_id === selectedCategory)
        .map(c => c.id);
      return matchesSearch && (childCatIds.includes(product.category_id || '') || product.category_id === selectedCategory);
    }
    
    return matchesSearch && product.category_id === selectedCategory;
  });

  // Group products by category
  const groupProductsByCategory = () => {
    const grouped: Record<string, Product[]> = {};
    
    // First, handle products with no category
    const uncategorizedProducts = filteredProducts.filter(p => !p.category_id);
    if (uncategorizedProducts.length > 0) {
      grouped['uncategorized'] = uncategorizedProducts;
    }
    
    // Group by parent category
    parentCategories.forEach(parentCat => {
      const childCategories = getChildCategories(parentCat.id);
      
      // Products directly in parent category
      const directProducts = filteredProducts.filter(p => p.category_id === parentCat.id);
      if (directProducts.length > 0) {
        grouped[parentCat.id] = directProducts;
      }
      
      // Products in child categories
      childCategories.forEach(childCat => {
        const childProducts = filteredProducts.filter(p => p.category_id === childCat.id);
        if (childProducts.length > 0) {
          grouped[childCat.id] = childProducts;
        }
      });
    });
    
    return grouped;
  };

  // Get dimensions to display for a product
  const getProductDimensions = (product: Product) => {
    if (product.dimensions && product.dimensions.length > 0) {
      return product.dimensions;
    }
    // Fallback to specifications if dimensions array is not available
    return [{ 
      id: '1', 
      length: product.specifications.length, 
      width: product.specifications.width, 
      height: product.specifications.height 
    }];
  };

  // Get the currently selected dimension for a product
  const getSelectedDimension = (product: Product) => {
    const dimensions = getProductDimensions(product);
    const selectedIndex = selectedDimensions[product.id] || 0;
    return dimensions[selectedIndex] || dimensions[0];
  };

  // Open product details modal
  const openProductDetails = (product: Product) => {
    setSelectedProduct(product);
  };

  // Close product details modal
  const closeProductDetails = () => {
    setSelectedProduct(null);
  };

  // Get category name by ID
  const getCategoryName = (categoryId: string) => {
    const category = categories.find(c => c.id === categoryId);
    return category ? category.name : 'קטגוריה לא ידועה';
  };

  // Get parent category name
  const getParentCategoryName = (categoryId: string) => {
    const category = categories.find(c => c.id === categoryId);
    if (category && category.parent_id) {
      const parentCategory = categories.find(c => c.id === category.parent_id);
      return parentCategory ? parentCategory.name : '';
    }
    return '';
  };

  // Parse description to get feature list
  const parseProductFeatures = (description: string) => {
    if (!description) return [];
    
    // Split by new lines or commas
    const features = description.split(/[\n,]+/).map(item => item.trim()).filter(item => item);
    return features;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 relative">
      {/* Dot Pattern Background */}
      <DotPattern 
        className={cn(
          "opacity-50 [mask-image:radial-gradient(ellipse_at_center,white,transparent)]",
          "z-0"
        )}
        width={24}
        height={24}
        cx={12}
        cy={12}
        cr={1.5}
      />
      
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-white/80 backdrop-blur-sm z-10">
        <div className="max-w-7xl mx-auto">
          <div className="relative z-10 pb-8 bg-white/80 sm:pb-16 md:pb-20 lg:w-full lg:pb-28 xl:pb-32">
            <div className="pt-6 px-4 sm:px-6 lg:px-8">
              <nav className="relative flex items-center justify-between sm:h-10 lg:justify-start" aria-label="Global">
                <div className="flex items-center flex-grow flex-shrink-0 lg:flex-grow-0">
                  <div className="flex items-center justify-between w-full md:w-auto">
                    <img
                      src="https://jthvcbeoblgvgettmehi.supabase.co/storage/v1/object/public/products/logo/logosys.png"
                      alt="קירור דן"
                      className="h-12 w-auto ml-auto"
                    />
                  </div>
                </div>
              </nav>
            </div>

            <main className="mt-10 mx-auto max-w-7xl px-4 sm:mt-12 sm:px-6 lg:mt-16 lg:px-8">
              <div className="text-center">
                <h1 className="text-4xl tracking-tight font-extrabold text-gray-900 sm:text-5xl md:text-6xl">
                  <span className="block">קטלוג המוצרים שלנו</span>
                  <span className="block text-blue-600 mt-2">איכות ומקצועיות</span>
                </h1>
                <p className="mt-3 max-w-md mx-auto text-base text-gray-500 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
                  גלו את מגוון המוצרים האיכותיים שלנו. כל המוצרים מיוצרים תחת פיקוח קפדני ועומדים בסטנדרטים הגבוהים ביותר.
                </p>
              </div>
            </main>
          </div>
        </div>
      </div>

      {/* Search and Filter Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 relative z-10">
        <div className="bg-white/90 rounded-xl shadow-lg p-6 mb-8 backdrop-blur-sm">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="חיפוש מוצרים..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="block w-full pr-10 rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>
            
            {/* Mobile filter button */}
            <button
              onClick={() => setShowMobileFilters(!showMobileFilters)}
              className="md:hidden bg-blue-50 text-blue-700 px-4 py-2 rounded-lg flex items-center justify-center gap-2"
            >
              <SlidersHorizontal className="w-5 h-5" />
              <span>סינון לפי קטגוריה</span>
            </button>
            
            {/* Desktop filter button */}
            <button
              onClick={() => setShowDesktopFilters(!showDesktopFilters)}
              className="hidden md:flex bg-blue-50 text-blue-700 px-4 py-2 rounded-lg items-center justify-center gap-2"
            >
              <SlidersHorizontal className="w-5 h-5" />
              <span>סינון לפי קטגוריה</span>
            </button>
          </div>
          
          {/* Mobile filters panel */}
          {showMobileFilters && (
            <div className="md:hidden mt-4 bg-gray-50 rounded-lg p-4 animate-fadeIn">
              <div className="flex justify-between items-center mb-3">
                <h3 className="font-medium">סינון לפי קטגוריה</h3>
                <button 
                  onClick={() => setShowMobileFilters(false)}
                  className="text-gray-500 p-1"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <div className="space-y-2">
                <button
                  onClick={() => {
                    setSelectedCategory('');
                    setShowMobileFilters(false);
                  }}
                  className={`w-full text-right px-3 py-2 rounded-lg ${
                    !selectedCategory
                      ? 'bg-blue-100 text-blue-700'
                      : 'bg-white text-gray-700'
                  }`}
                >
                  הצג הכל
                </button>
                
                {parentCategories.map(parentCat => {
                  const childCategories = getChildCategories(parentCat.id);
                  const isExpanded = expandedCategories.has(parentCat.id);
                  
                  return (
                    <div key={parentCat.id} className="space-y-1">
                      <button
                        onClick={() => toggleCategory(parentCat.id)}
                        className="w-full text-right px-3 py-2 rounded-lg bg-white flex items-center justify-between"
                      >
                        <span>{parentCat.name}</span>
                        {isExpanded ? (
                          <ChevronDown className="w-4 h-4" />
                        ) : (
                          <ChevronRight className="w-4 h-4" />
                        )}
                      </button>
                      
                      {isExpanded && (
                        <div className="pr-4 space-y-1">
                          {childCategories.map(childCat => (
                            <button
                              key={childCat.id}
                              onClick={() => {
                                setSelectedCategory(childCat.id);
                                setShowMobileFilters(false);
                              }}
                              className={`w-full text-right px-3 py-2 rounded-lg ${
                                selectedCategory === childCat.id 
                                  ? 'bg-blue-50 text-blue-700' 
                                  : 'bg-white text-gray-700'
                              }`}
                            >
                              {childCat.name}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
          
          {/* Desktop filters panel */}
          {showDesktopFilters && (
            <div className="hidden md:block mt-4 bg-gray-50 rounded-lg p-4 animate-fadeIn">
              <div className="flex justify-between items-center mb-3">
                <h3 className="font-medium">סינון לפי קטגוריה</h3>
                <button 
                  onClick={() => setShowDesktopFilters(false)}
                  className="text-gray-500 p-1"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <div className="space-y-2">
                <button
                  onClick={() => {
                    setSelectedCategory('');
                    setShowDesktopFilters(false);
                  }}
                  className={`w-full text-right px-3 py-2 rounded-lg ${
                    !selectedCategory
                      ? 'bg-blue-100 text-blue-700'
                      : 'bg-white text-gray-700'
                  }`}
                >
                  הצג הכל
                </button>
                
                {parentCategories.map(parentCat => {
                  const childCategories = getChildCategories(parentCat.id);
                  const isExpanded = expandedCategories.has(parentCat.id);
                  
                  return (
                    <div key={parentCat.id} className="space-y-1">
                      <button
                        onClick={() => toggleCategory(parentCat.id)}
                        className="w-full text-right px-3 py-2 rounded-lg bg-white flex items-center justify-between"
                      >
                        <span>{parentCat.name}</span>
                        {isExpanded ? (
                          <ChevronDown className="w-4 h-4" />
                        ) : (
                          <ChevronRight className="w-4 h-4" />
                        )}
                      </button>
                      
                      {isExpanded && (
                        <div className="pr-4 space-y-1">
                          {childCategories.map(childCat => (
                            <button
                              key={childCat.id}
                              onClick={() => {
                                setSelectedCategory(childCat.id);
                                setShowDesktopFilters(false);
                              }}
                              className={`w-full text-right px-3 py-2 rounded-lg ${
                                selectedCategory === childCat.id 
                                  ? 'bg-blue-50 text-blue-700' 
                                  : 'bg-white text-gray-700'
                              }`}
                            >
                              {childCat.name}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center py-20">
            <div className="flex flex-col items-center gap-4">
              <Loader2 className="w-12 h-12 text-blue-500 animate-spin" />
              <p className="text-gray-500">טוען מוצרים...</p>
            </div>
          </div>
        ) : error ? (
          <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center text-red-700">
            {error}
          </div>
        ) : (
          <>
            {/* Products by Category */}
            <div className="space-y-12">
              {Object.entries(groupProductsByCategory()).map(([categoryId, categoryProducts]) => {
                // Skip if no products in this category
                if (categoryProducts.length === 0) return null;
                
                // Get category name
                let categoryName = 'מוצרים ללא קטגוריה';
                let parentName = '';
                
                if (categoryId !== 'uncategorized') {
                  categoryName = getCategoryName(categoryId);
                  parentName = getParentCategoryName(categoryId);
                }
                
                return (
                  <div key={categoryId} className="bg-white/95 rounded-xl shadow-lg p-6 backdrop-blur-sm">
                    <h2 className="text-2xl font-bold text-gray-900 mb-6 border-b pb-3 flex items-center">
                      <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm mr-3">
                        {categoryProducts.length} מוצרים
                      </span>
                      <span>{categoryName}</span>
                      {parentName && <span className="text-lg font-normal text-gray-500 mr-2">({parentName})</span>}
                    </h2>
                    
                    <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
                      {categoryProducts.map((product) => (
                        <div
                          key={product.id}
                          className="bg-white rounded-xl shadow-md overflow-hidden transform transition-all duration-300 hover:shadow-xl hover:-translate-y-1 cursor-pointer group"
                          onClick={() => openProductDetails(product)}
                        >
                          <div className="aspect-square relative overflow-hidden">
                            {product.image_url ? (
                              <img
                                src={product.image_url}
                                alt={product.name}
                                className="w-full h-full object-contain p-4 transition-transform duration-300 group-hover:scale-105"
                              />
                            ) : (
                              <div className="w-full h-full bg-gray-100 flex items-center justify-center">
                                <span className="text-gray-400">אין תמונה</span>
                              </div>
                            )}
                            {product.tag && (
                              <div className="absolute top-2 right-2 bg-[#e6dfd1] text-[#8a7e63] px-3 py-1 rounded-full text-xs font-medium">
                                {product.tag}
                              </div>
                            )}
                          </div>
                          <div className="p-4 border-t">
                            <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-2 break-words line-clamp-2">{product.name}</h3>
                            
                            <div className="flex justify-end items-center mt-3">
                              <button 
                                className="bg-blue-600 hover:bg-blue-700 text-white text-xs py-1.5 px-3 rounded-full flex items-center gap-1 transition-all transform hover:scale-105 shadow-sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  openProductDetails(product);
                                }}
                              >
                                <span>פרטים</span>
                                <ChevronLeft className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>

            {filteredProducts.length === 0 && !isLoading && (
              <div className="text-center py-12 bg-white/90 rounded-xl shadow-md p-8 backdrop-blur-sm">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-100 text-blue-600 mb-4">
                  <Search className="w-8 h-8" />
                </div>
                <p className="text-gray-500 text-lg">לא נמצאו מוצרים התואמים את החיפוש</p>
                <button 
                  onClick={() => setSearchTerm('')}
                  className="mt-4 text-blue-600 hover:text-blue-800 font-medium"
                >
                  נקה חיפוש
                </button>
              </div>
            )}
          </>
        )}
      </div>

      {/* Product Details Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 backdrop-blur-sm" onClick={closeProductDetails}>
          <div 
            className="bg-white rounded-xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-hidden flex flex-col animate-fadeIn"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-4 border-b flex justify-between items-center bg-blue-50">
              <h2 className="text-xl font-bold text-blue-800">{selectedProduct.name}</h2>
              <button
                onClick={closeProductDetails}
                className="text-gray-500 hover:text-gray-700 p-1 bg-white rounded-full hover:bg-gray-100 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            
            <div className="overflow-y-auto p-4 flex-1">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="aspect-square bg-gray-50 rounded-lg overflow-hidden relative">
                  {selectedProduct.image_url ? (
                    <img
                      src={selectedProduct.image_url}
                      alt={selectedProduct.name}
                      className="w-full h-full object-contain p-4"
                    />
                  ) : (
                    <div className="w-full h-full bg-gray-100 flex items-center justify-center">
                      <span className="text-gray-400">אין תמונה</span>
                    </div>
                  )}
                  {selectedProduct.tag && (
                    <div className="absolute top-2 right-2 bg-[#e6dfd1] text-[#8a7e63] px-3 py-1 rounded-full text-xs font-medium">
                      {selectedProduct.tag}
                    </div>
                  )}
                </div>
                
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-semibold mb-2">תיאור המוצר</h3>
                    <div className="space-y-2">
                      <div className="flex flex-col space-y-2">
                        {parseProductFeatures(selectedProduct.description).map((feature, index) => (
                          <div key={index} className="flex items-center gap-2">
                            <span className="text-green-500 flex-shrink-0">✓</span>
                            <span>{feature}</span>
                          </div>
                        ))}
                        {parseProductFeatures(selectedProduct.description).length === 0 && (
                          <p className="text-gray-500">אין תיאור למוצר זה</p>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold mb-2">מידות</h3>
                    
                    {/* Dimensions selector */}
                    {getProductDimensions(selectedProduct).length > 1 && (
                      <div className="mb-4">
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          בחר מידה:
                        </label>
                        <div className="flex flex-wrap gap-2">
                          {getProductDimensions(selectedProduct).map((dim, index) => (
                            <button
                              key={dim.id}
                              onClick={() => setSelectedDimensions({
                                ...selectedDimensions,
                                [selectedProduct.id]: index
                              })}
                              className={`px-3 py-1 text-sm rounded-full border ${
                                selectedDimensions[selectedProduct.id] === index
                                  ? 'bg-blue-50 border-blue-300 text-blue-700'
                                  : 'border-gray-300 hover:bg-gray-50'
                              }`}
                            >
                              {dim.length}×{dim.width}×{dim.height}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="flex justify-between items-center">
                        <div className="text-center flex-1">
                          <span className="block text-sm text-gray-500">אורך</span>
                          <span className="font-semibold">{getSelectedDimension(selectedProduct).length} ס"מ</span>
                        </div>
                        <div className="text-center flex-1">
                          <span className="block text-sm text-gray-500">רוחב</span>
                          <span className="font-semibold">{getSelectedDimension(selectedProduct).width} ס"מ</span>
                        </div>
                        <div className="text-center flex-1">
                          <span className="block text-sm text-gray-500">גובה</span>
                          <span className="font-semibold">{getSelectedDimension(selectedProduct).height} ס"מ</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="p-4 border-t">
              <button
                onClick={closeProductDetails}
                className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 font-medium"
              >
                <ChevronLeft className="w-5 h-5" />
                חזרה לקטלוג
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Contact Section */}
      <div className="bg-white/90 py-16 mt-16 relative z-10 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900">רוצים לשמוע עוד?</h2>
            <p className="mt-4 text-lg text-gray-500">
              צרו איתנו קשר לקבלת פרטים נוספים על המוצרים שלנו
            </p>
            <div className="mt-8">
              <a
                href="tel:+972123456789"
                className="inline-flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 md:py-4 md:text-lg md:px-10 shadow-md transition-all hover:shadow-lg"
              >
                התקשרו עכשיו
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}