import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Upload, Trash2, Send, X, Check, Phone, User, Eye, Download } from 'lucide-react';
import JSZip from 'jszip';

interface Category {
  id: string;
  name: string;
  parent_id?: string | null;
}

interface CategoryImage {
  id: string;
  category_id: string;
  image_url: string;
  created_at: string;
  group_tag?: string | null;
}

interface SelectedImage {
  id: string;
  image_url: string;
  category_name: string;
}

export default function CategoryImagesPage() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [mainCategories, setMainCategories] = useState<Category[]>([]);
  const [subCategories, setSubCategories] = useState<Category[]>([]);
  const [selectedMainCategory, setSelectedMainCategory] = useState<string | null>(null);
  const [selectedSubCategory, setSelectedSubCategory] = useState<string | null>(null);
  const [images, setImages] = useState<CategoryImage[]>([]);
  const [selectedImages, setSelectedImages] = useState<SelectedImage[]>([]);
  const [uploading, setUploading] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showContactModal, setShowContactModal] = useState(false);
  const [contactPhone, setContactPhone] = useState('');
  const [contactName, setContactName] = useState('');
  const [modalImageUrl, setModalImageUrl] = useState<string | null>(null);
  const [selectedSidebarSubCategory, setSelectedSidebarSubCategory] = useState<string | null>(null);
  const [filteredImages, setFilteredImages] = useState<CategoryImage[]>([]);
  const [uploadGroupTag, setUploadGroupTag] = useState('');
  const [groupTags, setGroupTags] = useState<string[]>([]);

  useEffect(() => {
    fetchCategories();
  }, []);

  useEffect(() => {
    setSelectedSubCategory(null);
    setSubCategories(categories.filter(cat => cat.parent_id === selectedMainCategory));
  }, [selectedMainCategory, categories]);

  useEffect(() => {
    if (selectedSubCategory !== null) {
      console.log('טוען תמונות לקטגוריה:', selectedSubCategory);
      fetchImages(selectedSubCategory);
    } else {
      setImages([]);
    }
  }, [selectedSubCategory]);

  // Update filtered images when main/sub category or images change
  useEffect(() => {
    if (!selectedMainCategory) {
      setFilteredImages([]);
      return;
    }
    if (!selectedSidebarSubCategory) {
      // Show all images from all subcategories of the main category
      const subCatIds = categories.filter(cat => cat.parent_id === selectedMainCategory).map(cat => cat.id);
      setFilteredImages(images.filter(img => subCatIds.includes(img.category_id)));
    } else {
      setFilteredImages(images.filter(img => img.category_id === selectedSidebarSubCategory));
    }
  }, [selectedMainCategory, selectedSidebarSubCategory, images, categories]);

  // Fetch all images for all subcategories when main category changes
  useEffect(() => {
    if (selectedMainCategory) {
      const subCatIds = categories.filter(cat => cat.parent_id === selectedMainCategory).map(cat => cat.id);
      if (subCatIds.length > 0) {
        fetchImagesForSubCategories(subCatIds);
      } else {
        setImages([]);
      }
      setSelectedSidebarSubCategory(null); // Reset filter
    }
  }, [selectedMainCategory, categories]);

  // Fetch group tags for selected subcategory
  useEffect(() => {
    if (!selectedSidebarSubCategory) {
      setGroupTags([]);
      return;
    }
    // Extract unique group tags from images in this subcategory
    const tags = Array.from(new Set(
      images
        .filter(img => img.category_id === selectedSidebarSubCategory && img.group_tag)
        .map(img => img.group_tag as string)
    ));
    setGroupTags(tags);
  }, [selectedSidebarSubCategory, images]);

  // Fetch images for multiple subcategories
  const fetchImagesForSubCategories = async (subCatIds: string[]) => {
    try {
      const { data, error } = await supabase
        .from('category_images')
        .select('*')
        .in('category_id', subCatIds)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setImages(data || []);
    } catch (error) {
      console.error('Error fetching images:', error);
      setImages([]);
    }
  };

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('categories')
        .select('id, name, parent_id')
        .order('name');

      console.log('categories data:', data);
      console.log('categories error:', error);

      if (error) throw error;
      const cats = Array.isArray(data) ? data : [];
      setCategories(cats);
      setMainCategories(cats.filter(cat => !cat.parent_id));
    } catch (error) {
      console.error('Error fetching categories:', error);
      setCategories([]);
      setMainCategories([]);
    } finally {
      setLoading(false);
    }
  };

  const fetchImages = async (categoryId: string) => {
    try {
      const { data, error } = await supabase
        .from('category_images')
        .select('*')
        .eq('category_id', categoryId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setImages(data || []);
      console.log('images לקטגוריה', categoryId, ':', data);
    } catch (error) {
      console.error('Error fetching images:', error);
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    if (!selectedSidebarSubCategory) {
      alert('נא לבחור קטגוריה משנית תחילה');
      return;
    }
    if (!uploadGroupTag.trim()) {
      alert('נא להזין שם קבוצה/תגית');
      return;
    }

    const files = event.target.files;
    if (!files || files.length === 0) return;

    if (files.length > 10) {
      alert('ניתן להעלות עד 10 תמונות בבת אחת');
      return;
    }

    setUploading(true);

    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const fileExt = file.name.split('.').pop();
        const fileName = `${Date.now()}_${Math.random()}.${fileExt}`;
        const filePath = `category-images/${selectedSidebarSubCategory}/${fileName}`;

        // קבל Signed Upload URL
        const { data: signedUrlData, error: signedUrlError } = await supabase.storage
          .from('category-images')
          .createSignedUploadUrl(filePath);
        if (signedUrlError) throw signedUrlError;

        // העלה את הקובץ ל-Storage עם fetch
        const response = await fetch(signedUrlData.signedUrl, {
          method: 'PUT',
          body: file,
          headers: {
            'Content-Type': file.type
          }
        });
        if (!response.ok) throw new Error('Upload failed');

        // קבל publicUrl
        const { data: { publicUrl } } = supabase.storage
          .from('category-images')
          .getPublicUrl(filePath);

        // שמור ל-DB
        const { error: dbError } = await supabase
          .from('category_images')
          .insert({
            category_id: selectedSidebarSubCategory,
            image_url: publicUrl,
            group_tag: uploadGroupTag.trim()
          });
        if (dbError) throw dbError;
      }

      // Refresh images
      await fetchImagesForSubCategories([selectedSidebarSubCategory]);
      alert('התמונות הועלו בהצלחה!');
      setUploadGroupTag('');
    } catch (error) {
      console.error('Error uploading images:', error);
      alert('שגיאה בהעלאת התמונות');
    } finally {
      setUploading(false);
      // Reset file input
      event.target.value = '';
    }
  };

  const deleteImage = async (imageId: string) => {
    if (!confirm('האם אתה בטוח שברצונך למחוק תמונה זו?')) return;

    try {
      const { error } = await supabase
        .from('category_images')
        .delete()
        .eq('id', imageId);

      if (error) throw error;

      // Remove from selected images if present
      setSelectedImages(prev => prev.filter(img => img.id !== imageId));
      
      // Refresh images
      if (selectedSubCategory) {
        await fetchImages(selectedSubCategory);
      }
    } catch (error) {
      console.error('Error deleting image:', error);
      alert('שגיאה במחיקת התמונה');
    }
  };

  const toggleImageSelection = (image: CategoryImage) => {
    const category = categories.find(cat => cat.id === image.category_id);
    const selectedImage: SelectedImage = {
      id: String(image.id),
      image_url: image.image_url,
      category_name: category?.name || 'לא ידוע'
    };

    setSelectedImages(prev => {
      const isSelected = prev.some(img => img.id === String(image.id));
      if (isSelected) {
        return prev.filter(img => img.id !== String(image.id));
      } else {
        return [...prev, selectedImage];
      }
    });
  };

  const removeSelectedImage = (imageId: string) => {
    setSelectedImages(prev => prev.filter(img => img.id !== imageId));
  };

  const sendToWhatsApp = () => {
    if (selectedImages.length === 0) {
      alert('נא לבחור תמונות תחילה');
      return;
    }

    if (!contactPhone.trim()) {
      alert('נא להזין מספר טלפון');
      return;
    }

    // Format phone number (remove spaces, dashes, etc.)
    const cleanPhone = contactPhone.replace(/[\s\-\(\)]/g, '');
    const phoneWithCountryCode = cleanPhone.startsWith('972') ? cleanPhone : `972${cleanPhone.replace(/^0/, '')}`;

    // Create message with image URLs
    const imageUrls = selectedImages.map(img => img.image_url).join('\n');
    const message = `שלום${contactName ? ` ${contactName}` : ''}!\n\nהנה התמונות שביקשת:\n${imageUrls}`;
    
    const whatsappUrl = `https://wa.me/${phoneWithCountryCode}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
    
    setShowContactModal(false);
    setContactPhone('');
    setContactName('');
  };

  const handleWhatsAppShare = () => {
    if (selectedImages.length === 0) {
      alert('בחר תמונות לשליחה');
      return;
    }

    // Create WhatsApp message with image URLs
    const imageUrls = selectedImages.map(img => img.image_url).join('\n');
    const message = `תמונות נבחרות:\n${imageUrls}`;
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const downloadImagesAsZip = async () => {
    if (selectedImages.length === 0) {
      alert('בחר תמונות להורדה');
      return;
    }

    try {
      const zip = new JSZip();
      
      // Download each image and add to zip
      for (let i = 0; i < selectedImages.length; i++) {
        const image = selectedImages[i];
        const response = await fetch(image.image_url);
        const blob = await response.blob();
        
        // Get file extension from URL or default to .jpg
        const urlParts = image.image_url.split('.');
        const extension = urlParts.length > 1 ? urlParts[urlParts.length - 1].split('?')[0] : 'jpg';
        const fileName = `image_${i + 1}.${extension}`;
        
        zip.file(fileName, blob);
      }

      // Generate and download zip file
      const zipBlob = await zip.generateAsync({ type: 'blob' });
      const url = window.URL.createObjectURL(zipBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `selected_images_${new Date().toISOString().split('T')[0]}.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error downloading images:', error);
      alert('שגיאה בהורדת התמונות');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-500" />
      </div>
    );
  }

  // מיפוי שם קטגוריה ראשית לתמונה
  const mainCategoryImages: Record<string, string> = {
    'חלביות': 'https://jthvcbeoblgvgettmehi.supabase.co/storage/v1/object/public/products/product-images/woo-4507-1740608031424.png',
    'מקרר תעשייתי': 'https://jthvcbeoblgvgettmehi.supabase.co/storage/v1/object/public/products/product-images/woo-4387-1740609179642.jpeg',
    'מעדניות': 'https://jthvcbeoblgvgettmehi.supabase.co/storage/v1/object/public/products/product-images/woo-4533-1740607625867.png',
    'מקפיאים תעשייתיים': 'https://jthvcbeoblgvgettmehi.supabase.co/storage/v1/object/public/products/product-images/woo-4397-1740609151749.jpeg',
    
  };
  const defaultMainCategoryImage = 'https://jthvcbeoblgvgettmehi.supabase.co/storage/v1/object/public/products/product-images/woo-4397-1740609151749.jpeg'; // תמונה דיפולטיבית

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">תמונות לפי קטגוריה</h1>
        {/* בחירת קטגוריה ראשית */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-4 text-center text-lg">בחר קטגוריה ראשית:</label>
          {mainCategories.length === 0 ? (
            <div className="text-red-600 font-semibold">לא קיימות קטגוריות ראשיות, יש להוסיף קטגוריות תחילה.</div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 justify-center">
              {mainCategories.map((cat) => {
                const isSelected = selectedMainCategory === cat.id;
                const imgSrc = mainCategoryImages[cat.name] || defaultMainCategoryImage;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setSelectedMainCategory(cat.id)}
                    className={`flex flex-col items-center p-4 rounded-xl shadow transition-all border-2 focus:outline-none
                      ${isSelected ? 'border-blue-600 bg-blue-50 shadow-lg' : 'border-gray-200 bg-white hover:border-blue-400 hover:bg-blue-50'}`}
                  >
                    <img
                      src={imgSrc}
                      alt={cat.name}
                      className="w-24 h-24 object-cover rounded-full mb-2 border"
                    />
                    <span className={`font-semibold text-lg ${isSelected ? 'text-blue-700' : 'text-gray-800'}`}>{cat.name}</span>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>
      {/* Sidebar + Images Layout */}
      {selectedMainCategory && (
        <div className="flex flex-col md:flex-row gap-4 md:gap-8">
          {/* Sidebar */}
          <aside className="w-full md:w-56 min-w-0 bg-white rounded-xl shadow p-3 md:p-4 mb-4 md:mb-0 order-1 md:order-none">
            <div className="mb-3 md:mb-4 font-bold text-base md:text-lg text-gray-700 text-center md:text-right">סינון לפי תת קטגוריה</div>
            <button
              className={`w-full text-center md:text-right px-3 py-2 rounded-lg mb-2 font-medium transition-colors ${!selectedSidebarSubCategory ? 'bg-blue-600 text-white' : 'hover:bg-blue-100'}`}
              onClick={() => setSelectedSidebarSubCategory(null)}
            >
              הצג הכל
            </button>
            {subCategories.map((cat) => (
              <button
                key={cat.id}
                className={`w-full text-center md:text-right px-3 py-2 rounded-lg mb-2 font-medium transition-colors ${selectedSidebarSubCategory === cat.id ? 'bg-blue-600 text-white' : 'hover:bg-blue-100'}`}
                onClick={() => setSelectedSidebarSubCategory(cat.id)}
              >
                {cat.name}
              </button>
            ))}
          </aside>
          {/* Images Grid + Upload */}
          <div className="flex-1 relative order-2 md:order-none">
            {/* Floating Upload Button (FAB) only if subcategory selected */}
            {selectedSidebarSubCategory && (
              <>
                <div className="fixed bottom-4 left-4 md:bottom-8 md:left-8 z-50 flex flex-col items-center gap-2">
                  <input
                    type="text"
                    className="mb-1 px-3 py-2 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 text-sm bg-white shadow"
                    placeholder="הזן קבוצה/תגית (חופשי)"
                    list="group-tags-list"
                    value={uploadGroupTag}
                    onChange={e => setUploadGroupTag(e.target.value)}
                    disabled={uploading}
                    style={{ direction: 'rtl', minWidth: 120 }}
                  />
                  <datalist id="group-tags-list">
                    {groupTags.map(tag => (
                      <option key={tag} value={tag} />
                    ))}
                  </datalist>
                  <label title="העלה תמונות" className="flex items-center justify-center w-12 h-12 md:w-16 md:h-16 bg-blue-600 text-white rounded-full shadow-lg cursor-pointer hover:bg-blue-700 transition-colors text-xl md:text-2xl">
                    <Upload className="w-6 h-6 md:w-8 md:h-8" />
                    <input
                      type="file"
                      multiple
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="hidden"
                      disabled={uploading}
                    />
                  </label>
                  {uploading && (
                    <div className="flex items-center gap-2 text-gray-600 mt-2 justify-center text-xs md:text-base">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-500" />
                      מעלה...
                    </div>
                  )}
                </div>
              </>
            )}
            {/* Images Grid */}
            <div className="mb-8">
              <h2 className="text-lg md:text-xl font-semibold mb-3 md:mb-4 text-center md:text-right">תמונות בקטגוריה</h2>
              {filteredImages.length === 0 ? (
                <div className="text-center py-8 text-gray-500 text-sm md:text-base">
                  אין תמונות בקטגוריה זו
                </div>
              ) : (
                Object.entries(
                  filteredImages.reduce((acc, img) => {
                    const tag = img.group_tag || 'ללא קבוצה';
                    if (!acc[tag]) acc[tag] = [];
                    acc[tag].push(img);
                    return acc;
                  }, {} as Record<string, CategoryImage[]>)
                ).map(([tag, images]) => (
                  <div key={tag} className="mb-8">
                    <div className="font-bold text-blue-700 mb-2 text-right text-base md:text-lg">{tag}</div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3 md:gap-4">
                      {images.map((image) => {
                        const isSelected = selectedImages.some(img => img.id === String(image.id));
                        return (
                          <div key={image.id} className="relative group">
                            <div className="relative">
                              <img
                                src={image.image_url}
                                alt="תמונה"
                                className="w-full h-32 md:h-36 object-cover rounded-lg"
                              />
                              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-200 rounded-lg flex items-center justify-center" />
                            </div>
                            <div className="flex items-center justify-center gap-2 mt-2 bg-white rounded-b-xl shadow-sm p-2">
                              <button
                                type="button"
                                onClick={() => setModalImageUrl(image.image_url)}
                                className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 border border-gray-300"
                              >
                                <Eye className="w-5 h-5 text-gray-700" />
                              </button>
                              <button
                                type="button"
                                onClick={() => toggleImageSelection(image)}
                                className={`px-4 py-1 rounded-full text-xs md:text-sm font-semibold transition-colors ${isSelected ? 'bg-red-500 text-white' : 'bg-blue-600 text-white hover:bg-blue-700'}`}
                              >
                                {isSelected ? 'הסר' : 'בחר'}
                              </button>
                            </div>
                            <button
                              onClick={() => deleteImage(String(image.id))}
                              className="absolute top-2 right-2 bg-red-600 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-200 hover:bg-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
      {/* Selected Images Bar */}
      {selectedImages.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg p-4 z-50">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <span className="text-sm font-medium text-gray-700">
                  נבחרו {selectedImages.length} תמונות
                </span>
                <div className="flex gap-2 overflow-x-auto max-w-md">
                  {selectedImages.map((image) => (
                    <div key={image.id} className="flex-shrink-0 relative">
                      <img
                        src={image.image_url}
                        alt="תמונה נבחרת"
                        className="w-12 h-12 object-cover rounded"
                      />
                      <button
                        onClick={() => removeSelectedImage(image.id)}
                        className="absolute -top-1 -right-1 bg-red-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs hover:bg-red-700"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={downloadImagesAsZip}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <Download className="w-4 h-4" />
                  הורד כ-ZIP
                </button>
                <button
                  onClick={() => setSelectedImages([])}
                  className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <X className="w-4 h-4" />
                  נקה בחירה
                </button>
              </div>
            </div>
            <div className="mt-2 text-sm text-gray-600">
              💡 טיפ: כדי לשלוח בוואטסאפ - הורד את התמונות כ-ZIP וגרור את הקבצים לחלון הצ'אט בוואטסאפ
            </div>
          </div>
        </div>
      )}

      {/* Contact Modal */}
      {showContactModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
            <h3 className="text-lg font-semibold mb-4">שלח בוואטסאפ</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  שם איש קשר (אופציונלי):
                </label>
                <div className="relative">
                  <User className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <input
                    type="text"
                    value={contactName}
                    onChange={(e) => setContactName(e.target.value)}
                    className="w-full pr-10 pl-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    placeholder="הכנס שם"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  מספר טלפון:
                </label>
                <div className="relative">
                  <Phone className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <input
                    type="tel"
                    value={contactPhone}
                    onChange={(e) => setContactPhone(e.target.value)}
                    className="w-full pr-10 pl-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    placeholder="05X-XXXXXXX"
                    required
                  />
                </div>
              </div>

              <div className="text-sm text-gray-600">
                יישלחו {selectedImages.length} תמונות
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setShowContactModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors"
              >
                ביטול
              </button>
              <button
                onClick={sendToWhatsApp}
                className="flex-1 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
              >
                שלח
              </button>
            </div>
          </div>
        </div>
      )}
      {/* פופאפ תצוגה */}
      {modalImageUrl && (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50">
          <div className="relative bg-white rounded-lg shadow-lg p-4 max-w-3xl w-full flex flex-col items-center">
            <button
              onClick={() => setModalImageUrl(null)}
              className="absolute top-2 left-2 bg-gray-200 hover:bg-gray-300 rounded-full p-1"
            >
              <X className="w-6 h-6 text-gray-700" />
            </button>
            <img src={modalImageUrl} alt="תמונה מוגדלת" className="max-h-[70vh] max-w-full rounded-lg" />
          </div>
        </div>
      )}
    </div>
  );
} 