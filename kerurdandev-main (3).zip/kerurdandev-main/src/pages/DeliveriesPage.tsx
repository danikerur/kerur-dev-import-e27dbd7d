import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import { heeboBase64 } from '../fonts/heebo';
import { ExportDeliveriesModal } from '../components/delivery/ExportDeliveriesModal';
import { DeliveryHeader } from '../components/delivery/DeliveryHeader';
import { DeliveryFilters } from '../components/delivery/DeliveryFilters';
import { DeliveryList } from '../components/delivery/DeliveryList';
import { logoBase64 } from '../assets/logoBase64';
import type { Delivery, MonthGroup } from '../types/delivery';

export function DeliveriesPage() {
  const [deliveries, setDeliveries] = useState<Delivery[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDeleting, setIsDeleting] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'planned' | 'completed' | 'canceled'>('all');
  const [showStatusFilter, setShowStatusFilter] = useState(false);
  const [expandedDeliveries, setExpandedDeliveries] = useState<Set<string>>(new Set());

  useEffect(() => { fetchDeliveries(); }, []);

  async function fetchDeliveries() {
    try {
      const { data, error } = await supabase
        .from('deliveries')
        .select(`
          id, driver_id, delivery_date, status, created_at,
          driver:drivers(id, full_name, phone),
          customers:delivery_customers(
            id, customer_id, delivery_price, notes, address, order,
            customer:customers(name, phone),
            products:delivery_products(
              id, 
              product_id, 
              quantity,
              dimension_index,
              product:products(
                id,
                name,
                specifications,
                dimensions
              )
            )
          )
        `)
        .order('delivery_date', { ascending: false });

      if (error) throw error;
      setDeliveries(data || []);
    } catch (error) {
      console.error('Error fetching deliveries:', error);
    } finally {
      setIsLoading(false);
    }
  }

  function fixDirection(name: string): string {
    const match = name.match(/^[\x00-\x7F\s\-:\/]+/);
    if (match) {
      const english = match[0];
      const hebrew = name.slice(english.length);
      return `<span dir="ltr" style="unicode-bidi: embed;">${english}</span>${hebrew}`;
    }
    return name;
  }

  function flipLTRStartToEnd(text: string): string {
    const match = text.match(/^(.*?)([\u0590-\u05FF].*)$/); // אנגלית ואז עברית
    if (match) {
      const english = match[1].trim();
      const hebrew = match[2].trim();
      return `${hebrew} (${english})`;
    }
    return text;
  }

  function flipIfStartsWithEnglish(text: string): string {
    const startsWithEnglish = /^[A-Za-z]/.test(text);
    if (startsWithEnglish) {
      return text.split('').reverse().join('');
    }
    return text;
  }

  function fixMixedName(text: string): string {
    const hasHebrew = /[\u0590-\u05FF]/.test(text);
    const hasEnglish = /[A-Za-z]/.test(text);
    if (hasHebrew && hasEnglish) {
      const hebrew = text.replace(/[A-Za-z0-9-:/]/g, '').trim();
      const english = text
        .replace(/[^A-Za-z0-9-:/]/g, '')
        .trim()
        .split('')
        .reverse()
        .join('');
      return `${hebrew}\n${english}`; // עברית למעלה, אנגלית הפוכה כדי שתיראה תקינה ב־RTL
    }
    return text;
  }

  const handlePrintDelivery = async (deliveryId: string) => {
    if (!deliveryId) return alert("לא ניתן לטעון את האספקה — מזהה לא קיים.");
    try {
      const { data: fullDelivery, error } = await supabase
        .from('deliveries')
        .select(`
          id, delivery_date, status,
          driver:drivers(id, full_name, phone),
          customers:delivery_customers(
            id, address, order, delivery_price, notes,
            customer:customers(name, phone),
            products:delivery_products(
              quantity,
              dimension_index,
              product:products(
                name,
                specifications,
                dimensions
              )
            )
          )
        `)
        .eq('id', deliveryId)
        .single();

      if (error || !fullDelivery) return alert('שגיאה בטעינת נתונים מהשרת. נסה שוב.');

      const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
      doc.addFileToVFS('Heebo.ttf', heeboBase64);
      doc.addFont('Heebo.ttf', 'Heebo', 'normal');
      doc.setFont('Heebo', 'normal');
      doc.setR2L(true);
      doc.setFontSize(20);

      const pageWidth = doc.internal.pageSize.getWidth();
      const margin = 20;
      let yPos = 30;

      const title = 'פרטי אספקה';
      const titleX = (pageWidth - doc.getTextWidth(title)) / 2;
      doc.text(title, titleX, yPos);
      yPos += 10;

      const deliveryDate = fullDelivery.delivery_date ? new Date(fullDelivery.delivery_date).toLocaleDateString('he-IL') : 'לא נקבע';
      doc.setFontSize(12);
      const wrapWidth = pageWidth - 2 * margin;
      const infoLines1 = doc.splitTextToSize(`תאריך: ${deliveryDate}`, wrapWidth);
      doc.text(infoLines1, pageWidth - margin, yPos, { align: 'right' });
      yPos += infoLines1.length * 6;

      const infoLines2 = doc.splitTextToSize(`מוביל: ${fullDelivery.driver?.full_name || 'לא ידוע'}`, wrapWidth);
      doc.text(infoLines2, pageWidth - margin, yPos, { align: 'right' });
      yPos += infoLines2.length * 6;

      const infoLines3 = doc.splitTextToSize(`טלפון: ${fullDelivery.driver?.phone || ''}`, wrapWidth);
      doc.text(infoLines3, pageWidth - margin, yPos, { align: 'right' });
      yPos += infoLines3.length * 6;

      doc.setDrawColor(180);
      doc.line(margin, yPos, pageWidth - margin, yPos);
      yPos += 10;

      const sortedCustomers = Array.isArray(fullDelivery.customers)
        ? [...fullDelivery.customers].sort((a, b) => a.order - b.order)
        : [];

      for (const [index, customer] of sortedCustomers.entries()) {
       // הערכה גסה של גובה תחנה לפני שהיא מתחילה
const approxLines = 6 + (customer.notes ? 2 : 0) + (customer.address ? 2 : 0) + (customer.products?.length || 0);
const approxHeight = approxLines * 8 + 20; // כולל לוגו, טקסטים, טבלה וכו'

if (yPos + approxHeight > doc.internal.pageSize.height - 20) {
  doc.addPage();
  yPos = 20;
}


        // הצגת לוגו בצד שמאל לפני תחנה
        doc.addImage(logoBase64, 'PNG', margin, yPos - 2, 30, 20);

        doc.setFontSize(14);
        const lineSpacing = 6;
        const wrapWidth = pageWidth - 2 * margin;
        const customerTitle = `תחנה ${index + 1}: ${customer.customer.name}`;
        const wrappedCustomerTitle = doc.splitTextToSize(customerTitle, wrapWidth);
        doc.text(wrappedCustomerTitle, pageWidth - margin, yPos, { align: 'right' });
        yPos += wrappedCustomerTitle.length * lineSpacing;

        doc.setFontSize(12);

        if (customer.customer.phone) {
          const phoneText = `טלפון: ${customer.customer.phone}`;
          const phoneLines = doc.splitTextToSize(phoneText, wrapWidth - 10);
          doc.text(phoneLines, pageWidth - margin, yPos, { align: 'right' });
          yPos += phoneLines.length * lineSpacing;
        }

        if (customer.address) {
          const addressText = `כתובת: ${customer.address}`;
          const addressLines = doc.splitTextToSize(addressText, wrapWidth - 10);
          doc.text(addressLines, pageWidth - margin, yPos, { align: 'right' });
          yPos += addressLines.length * lineSpacing;
        }

        if (customer.notes) {
          const notesText = `הערות: ${customer.notes}`;
          const notesLines = doc.splitTextToSize(notesText, wrapWidth - 10);
          doc.text(notesLines, pageWidth - margin, yPos, { align: 'right' });
          yPos += notesLines.length * lineSpacing;
        }

        if (customer.products?.length) {
          yPos += 4;
          doc.text('מוצרים:', pageWidth - margin, yPos, { align: 'right' });
          yPos += 4;

          const tableData = customer.products.map((p: any) => {
            const dimensions = p.product.dimensions?.[p.dimension_index || 0] || p.product.specifications;
            const cleanedName = fixMixedName(p.product.name);
            const productLine = `${cleanedName}\n${dimensions.length} × ${dimensions.width} × ${dimensions.height} ס"מ`;
            return [productLine, p.quantity.toString()];
          });
          

          (doc as any).autoTable({
            startY: yPos,
            head: [['שם מוצר', 'כמות']],
            body: tableData,
            margin: { right: margin + 10, left: margin + 10 },
            styles: {
              font: 'Heebo',
              fontStyle: 'normal',
              halign: 'right',
              cellPadding: 2,
              overflow: 'linebreak',
              // Force RTL for all cells
              cellStyles: { direction: 'rtl' }
            },
            headStyles: {
              fillColor: [255, 255, 255],
              textColor: [0, 0, 0],
              fontStyle: 'normal'
            },
            columnStyles: {
              0: { cellWidth: 100 },
              1: { cellWidth: 25 }
            },
            theme: 'grid',
            tableWidth: 'wrap'
          });

          const finalY = (doc as any).lastAutoTable?.finalY;
          yPos = typeof finalY === 'number' ? finalY + 10 : yPos + 10;
        }

        doc.setDrawColor(180);
        doc.line(margin, yPos, pageWidth - margin, yPos);
        yPos += 10;
      }

      const fileName = `אספקה_${deliveryDate.replace(/\//g, '-')}.pdf`;
      doc.save(fileName);
    } catch (error) {
      alert('שגיאה בהפקת PDF.');
      console.error(error);
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'planned': return 'מתוכננת';
      case 'completed': return 'הושלמה';
      case 'canceled': return 'בוטלה';
      default: return status;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'planned': return 'bg-blue-100 text-blue-800';
      case 'completed': return 'bg-green-100 text-green-800';
      case 'canceled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const groupDeliveriesByMonth = (deliveries: Delivery[]): MonthGroup[] => {
    const groups: Record<string, MonthGroup> = {};
    deliveries.forEach(delivery => {
      if (!delivery.delivery_date) return;
      const date = new Date(delivery.delivery_date);
      const key = `${date.getFullYear()}-${date.getMonth()}`;
      if (!groups[key]) {
        groups[key] = {
          month: date.toLocaleString('he-IL', { month: 'long' }),
          year: date.getFullYear(),
          deliveries: []
        };
      }
      groups[key].deliveries.push(delivery);
    });
    return Object.values(groups).sort((a, b) => {
      if (a.year !== b.year) return b.year - a.year;
      return Object.keys(groups).indexOf(b.month) - Object.keys(groups).indexOf(a.month);
    });
  };

  const toggleDeliveryExpansion = (deliveryId: string) => {
    setExpandedDeliveries(prev => {
      const newSet = new Set(prev);
      if (newSet.has(deliveryId)) newSet.delete(deliveryId);
      else newSet.add(deliveryId);
      return newSet;
    });
  };

  async function restoreInventoryForDelivery(deliveryId: string) {
    // שלוף את כל ה-delivery_customers של האספקה
    const { data: customers, error: custErr } = await supabase
      .from('delivery_customers')
      .select('id')
      .eq('delivery_id', deliveryId);

    if (custErr) throw custErr;
    if (!customers || customers.length === 0) return;

    const customerIds = customers.map((c: any) => c.id);

    // שלוף את כל המוצרים של האספקה
    const { data: products, error: prodErr } = await supabase
      .from('delivery_products')
      .select('product_id, warehouse_id, quantity')
      .in('delivery_customer_id', customerIds);

    if (prodErr) throw prodErr;
    if (!products) return;

    // עדכן מלאי לכל מוצר
    for (const p of products) {
      // שלוף את הכמות הנוכחית
      const { data: inv, error: invErr } = await supabase
        .from('warehouse_inventory')
        .select('quantity')
        .eq('product_id', p.product_id)
        .eq('warehouse_id', p.warehouse_id)
        .single();

      if (invErr) continue;

      const newQuantity = (inv?.quantity || 0) + p.quantity;

      await supabase
        .from('warehouse_inventory')
        .update({ quantity: newQuantity })
        .eq('product_id', p.product_id)
        .eq('warehouse_id', p.warehouse_id);
    }
  }

  const handleUpdateStatus = async (deliveryId: string, status: string) => {
    try {
      if (status === 'canceled') {
        await restoreInventoryForDelivery(deliveryId);
      }
      const { error } = await supabase
        .from('deliveries')
        .update({ status })
        .eq('id', deliveryId);
      if (error) throw error;
      fetchDeliveries();
    } catch (error) {
      alert('שגיאה בעדכון סטטוס האספקה');
      console.error(error);
    }
  };

  const handleDelete = async (deliveryId: string) => {
    console.log('handleDelete called for delivery:', deliveryId);
    if (!window.confirm('האם אתה בטוח שברצונך למחוק את האספקה?')) {
      return;
    }

    try {
      // שלוף את הסטטוס של האספקה
      const { data, error: fetchError } = await supabase
        .from('deliveries')
        .select('status')
        .eq('id', deliveryId)
        .single();

      if (fetchError) throw fetchError;

      // החזר מלאי רק אם לא בוטלה כבר
      if (data?.status !== 'canceled') {
        await restoreInventoryForDelivery(deliveryId);
      }

      const { error } = await supabase
        .from('deliveries')
        .delete()
        .eq('id', deliveryId);
      
      if (error) throw error;
      fetchDeliveries();
    } catch (error) {
      alert('שגיאה במחיקת האספקה');
      console.error(error);
    }
  };

  const filteredDeliveries = deliveries.filter(delivery => {
    const searchLower = searchTerm.toLowerCase();
    const driverMatch = delivery.driver?.full_name.toLowerCase().includes(searchLower) || delivery.driver?.phone.includes(searchLower);
    const customerMatch = delivery.customers.some(c =>
      c.customer.name.toLowerCase().includes(searchLower) ||
      c.customer.phone.includes(searchLower) ||
      c.address.toLowerCase().includes(searchLower)
    );
    const productMatch = delivery.customers.some(c =>
      c.products.some(p => p.product.name.toLowerCase().includes(searchLower))
    );
    const statusMatch = statusFilter === 'all' || delivery.status === statusFilter;
    return (driverMatch || customerMatch || productMatch) && statusMatch;
  });

  const groupedDeliveries = groupDeliveriesByMonth(filteredDeliveries);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-500 border-t-transparent" />
      </div>
    );
  }

  return (
    <div>
      <DeliveryHeader onExport={() => setShowExportModal(true)} />
      <DeliveryFilters
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        statusFilter={statusFilter}
        onStatusFilterChange={(status) => {
          setStatusFilter(status);
          setShowStatusFilter(false);
        }}
        showStatusFilter={showStatusFilter}
        onToggleStatusFilter={() => setShowStatusFilter(!showStatusFilter)}
      />
      <DeliveryList
        groupedDeliveries={groupedDeliveries}
        expandedDeliveries={expandedDeliveries}
        onToggleExpand={toggleDeliveryExpansion}
        onUpdateStatus={handleUpdateStatus}
        onPrint={handlePrintDelivery}
        onDelete={handleDelete}
        getStatusText={getStatusText}
        getStatusColor={getStatusColor}
      />
      {showExportModal && <ExportDeliveriesModal onClose={() => setShowExportModal(false)} />}
    </div>
  );
}