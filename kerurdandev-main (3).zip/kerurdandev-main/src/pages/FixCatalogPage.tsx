import React, { useState } from 'react';
import { supabase } from '../lib/supabase';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, AlertCircle, ArrowRight, Loader2 } from 'lucide-react';

export function FixCatalogPage() {
  const navigate = useNavigate();
  const [isFixing, setIsFixing] = useState(false);
  const [result, setResult] = useState<{
    success: boolean;
    message: string;
    details?: {
      before: {
        total: number;
        visible: number;
        hidden: number;
        null: number;
      };
      after: {
        total: number;
        visible: number;
        hidden: number;
        null: number;
      };
    };
  } | null>(null);

  const fixCatalogVisibility = async () => {
    setIsFixing(true);
    setResult(null);
    
    try {
      // First, check current products and their visibility
      const { data: beforeProducts, error: beforeError } = await supabase
        .from('products')
        .select('id, name, catalog_visible');
      
      if (beforeError) {
        throw new Error(`שגיאה בטעינת מוצרים: ${beforeError.message}`);
      }
      
      const beforeStats = {
        total: beforeProducts.length,
        visible: beforeProducts.filter(p => p.catalog_visible === true).length,
        hidden: beforeProducts.filter(p => p.catalog_visible === false).length,
        null: beforeProducts.filter(p => p.catalog_visible === null).length
      };
      
      // Update all products with null visibility to be visible
      const { error: updateNullError } = await supabase
        .from('products')
        .update({ catalog_visible: true })
        .is('catalog_visible', null);
      
      if (updateNullError) {
        throw new Error(`שגיאה בעדכון מוצרים ללא הגדרת נראות: ${updateNullError.message}`);
      }
      
      // Update all products with false visibility to be visible
      const { error: updateFalseError } = await supabase
        .from('products')
        .update({ catalog_visible: true })
        .eq('catalog_visible', false);
      
      if (updateFalseError) {
        throw new Error(`שגיאה בעדכון מוצרים מוסתרים: ${updateFalseError.message}`);
      }
      
      // Check products after update
      const { data: afterProducts, error: afterError } = await supabase
        .from('products')
        .select('id, name, catalog_visible');
      
      if (afterError) {
        throw new Error(`שגיאה בטעינת מוצרים לאחר עדכון: ${afterError.message}`);
      }
      
      const afterStats = {
        total: afterProducts.length,
        visible: afterProducts.filter(p => p.catalog_visible === true).length,
        hidden: afterProducts.filter(p => p.catalog_visible === false).length,
        null: afterProducts.filter(p => p.catalog_visible === null).length
      };
      
      setResult({
        success: true,
        message: 'כל המוצרים הוגדרו כמוצגים בקטלוג בהצלחה!',
        details: {
          before: beforeStats,
          after: afterStats
        }
      });
    } catch (error) {
      console.error('Error fixing catalog visibility:', error);
      setResult({
        success: false,
        message: error instanceof Error ? error.message : 'שגיאה לא ידועה בתיקון נראות הקטלוג'
      });
    } finally {
      setIsFixing(false);
    }
  };

  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <button
          onClick={() => navigate('/products')}
          className="p-2 hover:bg-gray-100 rounded-lg"
        >
          <ArrowRight className="w-6 h-6" />
        </button>
        <h1 className="text-2xl font-bold">תיקון נראות מוצרים בקטלוג</h1>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="space-y-6">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h2 className="text-lg font-semibold text-blue-800 mb-2">מה הכלי הזה עושה?</h2>
            <p className="text-blue-700">
              כלי זה מתקן בעיות נראות בקטלוג המוצרים. הוא מגדיר את כל המוצרים כמוצגים בקטלוג, 
              כך שהלקוחות יוכלו לראות את כל המוצרים בעמוד הקטלוג הציבורי.
            </p>
          </div>

          <div className="flex justify-center">
            <button
              onClick={fixCatalogVisibility}
              disabled={isFixing}
              className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 disabled:opacity-50 flex items-center gap-2 text-lg"
            >
              {isFixing ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  מתקן נראות...
                </>
              ) : (
                'תקן נראות מוצרים בקטלוג'
              )}
            </button>
          </div>

          {result && (
            <div className={`border rounded-lg p-4 mt-6 ${
              result.success ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'
            }`}>
              <div className="flex items-start gap-3">
                {result.success ? (
                  <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-0.5" />
                )}
                <div>
                  <h3 className={`font-semibold text-lg ${
                    result.success ? 'text-green-800' : 'text-red-800'
                  }`}>
                    {result.success ? 'הצלחה!' : 'שגיאה!'}
                  </h3>
                  <p className={result.success ? 'text-green-700' : 'text-red-700'}>
                    {result.message}
                  </p>
                  
                  {result.details && (
                    <div className="mt-4 space-y-4">
                      <div>
                        <h4 className="font-medium mb-2">לפני התיקון:</h4>
                        <ul className="space-y-1 text-sm">
                          <li>סה"כ מוצרים: {result.details.before.total}</li>
                          <li>מוצרים מוצגים: {result.details.before.visible}</li>
                          <li>מוצרים מוסתרים: {result.details.before.hidden}</li>
                          <li>מוצרים ללא הגדרת נראות: {result.details.before.null}</li>
                        </ul>
                      </div>
                      
                      <div>
                        <h4 className="font-medium mb-2">אחרי התיקון:</h4>
                        <ul className="space-y-1 text-sm">
                          <li>סה"כ מוצרים: {result.details.after.total}</li>
                          <li>מוצרים מוצגים: {result.details.after.visible}</li>
                          <li>מוצרים מוסתרים: {result.details.after.hidden}</li>
                          <li>מוצרים ללא הגדרת נראות: {result.details.after.null}</li>
                        </ul>
                      </div>
                    </div>
                  )}
                  
                  {result.success && (
                    <div className="mt-4">
                      <a 
                        href="/catalog" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-800 font-medium"
                      >
                        צפה בקטלוג המוצרים
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                          <polyline points="15 3 21 3 21 9"></polyline>
                          <line x1="10" y1="14" x2="21" y2="3"></line>
                        </svg>
                      </a>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}