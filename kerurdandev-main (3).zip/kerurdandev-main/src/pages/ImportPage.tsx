import React, { useState } from 'react';
import { Download, X, ArrowRight, AlertCircle, ExternalLink } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';

interface WooCommerceProduct {
  id: number;
  name: string;
  description: string;
  images: { src: string }[];
  dimensions: {
    length: string;
    width: string;
    height: string;
  };
  categories: { id: number; name: string }[];
  variations: {
    id: number;
    attributes: {
      name: string;
      option: string;
    }[];
    dimensions: {
      length: string;
      width: string;
      height: string;
    };
  }[];
}

export function ImportPage() {
  const navigate = useNavigate();
  const [isImporting, setIsImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [importLog, setImportLog] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [wooCommerceConfig, setWooCommerceConfig] = useState({
    url: '',
    consumerKey: '',
    consumerSecret: ''
  });

  const addToLog = (message: string, isError = false) => {
    const timestamp = new Date().toLocaleTimeString();
    const formattedMessage = isError 
      ? `[${timestamp}] 🔴 ${message}`
      : `[${timestamp}] ${message}`;
    
    setImportLog(prev => [...prev, formattedMessage]);
    
    // Auto-scroll to bottom
    const logElement = document.getElementById('import-log');
    if (logElement) {
      logElement.scrollTop = logElement.scrollHeight;
    }
  };

  const validateConfig = () => {
    if (!wooCommerceConfig.url || !wooCommerceConfig.consumerKey || !wooCommerceConfig.consumerSecret) {
      setError('נא למלא את כל פרטי החיבור ל-WooCommerce');
      return false;
    }

    // Clean up and validate the URL
    let baseUrl = wooCommerceConfig.url.trim().replace(/\/$/, '');
    
    // Add http:// if no protocol is specified
    if (!baseUrl.startsWith('http://') && !baseUrl.startsWith('https://')) {
      baseUrl = `https://${baseUrl}`;
    }

    // Remove /wp-json/wc/v3 if accidentally included
    baseUrl = baseUrl.replace(/\/wp-json\/wc\/v3\/?$/, '');

    // Validate URL format
    try {
      new URL(baseUrl);
    } catch {
      setError('כתובת האתר אינה תקינה');
      return false;
    }

    return baseUrl;
  };

  const uploadProductImage = async (imageUrl: string, productId: number): Promise<string> => {
    try {
      addToLog(`מעלה תמונת מוצר מ-${imageUrl}...`);
      
      // Create a proxy URL to bypass CORS issues
      const proxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(imageUrl)}`;
      addToLog(`משתמש בפרוקסי להורדת התמונה: ${proxyUrl}`);
      
      const response = await fetch(proxyUrl, {
        method: 'GET',
        headers: {
          'Accept': 'image/*'
        }
      });

      if (!response.ok) {
        throw new Error(`שגיאה בהורדת התמונה מהשרת המקורי: ${response.status} ${response.statusText}`);
      }
      
      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.startsWith('image/')) {
        throw new Error(`הקובץ שהתקבל אינו תמונה (${contentType})`);
      }

      const imageBlob = await response.blob();
      if (imageBlob.size === 0) {
        throw new Error('התמונה ריקה');
      }

      addToLog(`התמונה הורדה בהצלחה. גודל: ${(imageBlob.size / 1024).toFixed(2)}KB, סוג: ${contentType}`);

      if (imageBlob.size > 10 * 1024 * 1024) { // 10MB limit
        throw new Error('התמונה גדולה מדי - הגודל המקסימלי הוא 10MB');
      }

      // Get file extension from content type
      const fileExt = contentType.split('/')[1] || 'jpg';
      const fileName = `woo-${productId}-${Date.now()}.${fileExt}`;
      const filePath = `product-images/${fileName}`;

      addToLog(`מעלה תמונה לסטורג' בנתיב: ${filePath}`);

      const { error: uploadError } = await supabase.storage
        .from('products')
        .upload(filePath, imageBlob, {
          contentType: contentType,
          cacheControl: '3600'
        });

      if (uploadError) {
        if (uploadError.message.includes('duplicate')) {
          throw new Error('קיימת כבר תמונה עם שם זהה');
        }
        throw uploadError;
      }

      const { data: { publicUrl } } = supabase.storage
        .from('products')
        .getPublicUrl(filePath);

      addToLog(`✅ תמונת המוצר הועלתה בהצלחה: ${publicUrl}`);
      return publicUrl;

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'שגיאה לא ידועה';
      console.error('Image upload error:', error);
      addToLog(`שגיאה בהעלאת התמונה: ${errorMessage}`, true);
      return '';
    }
  };

  const handleDeleteAllProducts = async () => {
    if (!window.confirm('האם אתה בטוח שברצונך למחוק את כל המוצרים? פעולה זו אינה הפיכה!')) {
      return;
    }

    try {
      addToLog('מוחק את כל המוצרים...');
      
      // Delete all products
      const { error: deleteError } = await supabase
        .from('products')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000');

      if (deleteError) throw deleteError;

      addToLog('מוחק את כל הקטגוריות...');
      
      // Delete all categories
      const { error: catDeleteError } = await supabase
        .from('categories')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000');

      if (catDeleteError) throw catDeleteError;

      addToLog('✅ כל המוצרים והקטגוריות נמחקו בהצלחה');
    } catch (error) {
      console.error('Error deleting all products:', error);
      addToLog('שגיאה במחיקת המוצרים והקטגוריות', true);
      setError('שגיאה במחיקת המוצרים. אנא נסה שוב.');
    }
  };

  const fetchAllWooCommerceProducts = async (baseUrl: string): Promise<WooCommerceProduct[]> => {
    const authHeader = "Basic " + btoa(`${wooCommerceConfig.consumerKey}:${wooCommerceConfig.consumerSecret}`);
    let allProducts: WooCommerceProduct[] = [];
    let page = 1;
    let hasMore = true;

    while (hasMore) {
      addToLog(`מושך עמוד ${page}...`);
      const url = `${baseUrl}/wp-json/wc/v3/products?per_page=20&page=${page}`;
      
      try {
        const response = await fetch(url, {
          method: "GET",
          headers: {
            "Authorization": authHeader,
            "Content-Type": "application/json",
            "Accept": "application/json"
          }
        });

        if (!response.ok) {
          const errorData = await response.json();
          addToLog(`שגיאה במשיכת עמוד ${page}: ${errorData.message}`, true);
          throw new Error(`API Error: ${errorData.message}`);
        }

        const products = await response.json();
        
        if (!Array.isArray(products)) {
          throw new Error('התגובה מהשרת אינה בפורמט הנכון');
        }

        allProducts = allProducts.concat(products);
        addToLog(`✅ נמשכו ${products.length} מוצרים מעמוד ${page}`);

        if (products.length < 20) {
          hasMore = false;
          addToLog('✅ הגענו לסוף רשימת המוצרים');
        } else {
          page++;
          await new Promise(resolve => setTimeout(resolve, 1000));
        }

      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'שגיאה לא ידועה';
        addToLog(`שגיאה במשיכת עמוד ${page}: ${errorMessage}`, true);
        throw error;
      }
    }

    return allProducts;
  };

  const validateProductImages = (products: WooCommerceProduct[]) => {
    let validImages = 0;
    let missingImages = 0;

    addToLog('בודק תמונות מוצרים...');

    products.forEach(product => {
      if (product.images && product.images.length > 0) {
        validImages++;
        addToLog(`✅ נמצאה תמונה למוצר "${product.name}": ${product.images[0].src}`);
      } else {
        missingImages++;
        addToLog(`⚠️ למוצר "${product.name}" אין תמונה`, true);
      }
    });

    addToLog(`סיכום תמונות: ${validImages} מוצרים עם תמונות, ${missingImages} מוצרים ללא תמונות`);
  };

  const handleWooCommerceImport = async () => {
    setError(null);
    const baseUrl = validateConfig();
    if (!baseUrl) return;

    setIsImporting(true);
    setImportProgress(0);
    setImportLog([]);
    addToLog('מתחיל תהליך ייבוא...');

    try {
      const products = await fetchAllWooCommerceProducts(baseUrl);
      
      validateProductImages(products);

      if (products.length === 0) {
        throw new Error('לא נמצאו מוצרים באתר');
      }

      addToLog(`✅ נמצאו ${products.length} מוצרים בסך הכל`);

      let imported = 0;
      let failed = 0;
      const totalToImport = products.reduce((acc, product) => 
        acc + (product.variations?.length || 1), 0);

      addToLog(`מתחיל לייבא ${totalToImport} מוצרים...`);

      for (const product of products) {
        try {
          addToLog(`מייבא את המוצר "${product.name}"...`);
          
          let image_url = '';
          if (product.images?.[0]?.src) {
            image_url = await uploadProductImage(product.images[0].src, product.id);
          }

          let category_id = null;
          if (product.categories?.[0]) {
            const categoryName = product.categories[0].name;
            addToLog(`מחפש קטגוריה "${categoryName}"...`);
            
            const { data: existingCats, error: findError } = await supabase
              .from('categories')
              .select('id')
              .eq('name', categoryName)
              .maybeSingle();

            if (!findError && existingCats) {
              category_id = existingCats.id;
              addToLog('✅ נמצאה קטגוריה קיימת');
            } else {
              addToLog('יוצר קטגוריה חדשה...');
              const { data: newCat, error: insertError } = await supabase
                .from('categories')
                .insert({ name: categoryName })
                .select('id')
                .single();
              
              if (!insertError && newCat) {
                category_id = newCat.id;
                addToLog('✅ קטגוריה חדשה נוצרה בהצלחה');
              } else {
                addToLog('שגיאה ביצירת קטגוריה - ממשיך ללא קטגוריה', true);
              }
            }
          }

          if (product.variations?.length > 0) {
            addToLog(`מייבא ${product.variations.length} וריאציות...`);
            
            for (const variation of product.variations) {
              const dimensions = {
                length: parseFloat(variation.dimensions.length) || 0,
                width: parseFloat(variation.dimensions.width) || 0,
                height: parseFloat(variation.dimensions.height) || 0
              };

              const variationName = `${product.name} - ${variation.attributes
                .map(attr => attr.option)
                .join(' × ')}`;

              const { error: insertError } = await supabase.from('products').insert({
                name: variationName,
                description: product.description.replace(/<[^>]*>/g, ''),
                image_url,
                specifications: dimensions,
                category_id
              });

              if (insertError) {
                failed++;
                addToLog(`שגיאה בייבוא וריאציה "${variationName}": ${insertError.message}`, true);
                console.error('Error importing variation:', insertError);
              } else {
                imported++;
                setImportProgress(Math.round((imported / totalToImport) * 100));
                addToLog(`✅ וריאציה "${variationName}" יובאה בהצלחה`);
              }
            }
          } else {
            const dimensions = {
              length: parseFloat(product.dimensions.length) || 0,
              width: parseFloat(product.dimensions.width) || 0,
              height: parseFloat(product.dimensions.height) || 0
            };

            const { error: insertError } = await supabase.from('products').insert({
              name: product.name,
              description: product.description.replace(/<[^>]*>/g, ''),
              image_url,
              specifications: dimensions,
              category_id
            });

            if (insertError) {
              failed++;
              addToLog(`שגיאה בייבוא המוצר "${product.name}": ${insertError.message}`, true);
              console.error('Error importing product:', insertError);
            } else {
              imported++;
              setImportProgress(Math.round((imported / totalToImport) * 100));
              addToLog(`✅ המוצר "${product.name}" יובא בהצלחה`);
            }
          }
        } catch (error) {
          failed++;
          console.error(`Error importing product ${product.id}:`, error);
          addToLog(`שגיאה בייבוא המוצר "${product.name}": ${error instanceof Error ? error.message : 'שגיאה לא ידועה'}`, true);
          continue;
        }
      }

      const summary = `הייבוא הושלם! יובאו ${imported} מוצרים בהצלחה${failed > 0 ? `, ${failed} מוצרים נכשלו` : ''}`;
      addToLog(summary);
      
      if (imported > 0) {
        if (window.confirm(`${summary}\n\nהאם ברצונך לעבור לעמוד המוצרים?`)) {
          navigate('/products');
        }
      } else {
        throw new Error('לא הצלחנו לייבא אף מוצר');
      }

    } catch (error) {
      console.error('Error importing products:', error);
      const errorMessage = error instanceof Error ? error.message : 'שגיאה לא ידועה';
      addToLog(`שגיאה בתהליך הייבוא: ${errorMessage}`, true);
      setError(`שגיאה בייבוא המוצרים: ${errorMessage}`);
    } finally {
      setIsImporting(false);
      setImportProgress(0);
    }
  };

  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <button
          onClick={() => navigate('/products')}
          className="p-2 hover:bg-gray-100 rounded-lg"
        >
          <ArrowRight className="w-6 h-6" />
        </button>
        <h1 className="text-2xl font-bold">ייבוא מוצרים מ-WooCommerce</h1>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <div className="text-red-700">{error}</div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-semibold mb-4">הגדרות חיבור</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    כתובת האתר
                  </label>
                  <input
                    type="text"
                    value={wooCommerceConfig.url}
                    onChange={(e) => setWooCommerceConfig(prev => ({ ...prev, url: e.target.value }))}
                    placeholder="your-site.com"
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border"
                    dir="ltr"
                  />
                  <p className="mt-1 text-sm text-gray-500">
                    הכנס את כתובת האתר בלבד, ללא http:// או https://
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Consumer Key
                  </label>
                  <input
                    type="text"
                    value={wooCommerceConfig.consumerKey}
                    onChange={(e) => setWooCommerceConfig(prev => ({ ...prev, consumerKey: e.target.value }))}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border"
                    dir="ltr"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Consumer Secret
                  </label>
                  <input
                    type="password"
                    value={wooCommerceConfig.consumerSecret}
                    onChange={(e) => setWooCommerceConfig(prev => ({ ...prev, consumerSecret: e.target.value }))}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border"
                    dir="ltr"
                  />
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h3 className="font-medium text-blue-800 mb-2">איך להשיג את פרטי החיבור?</h3>
                  <ol className="list-decimal list-inside space-y-2 text-sm text-blue-700">
                    <li>היכנס לממשק הניהול של WordPress</li>
                    <li>עבור ל-WooCommerce {'>'} הגדרות {'>'} מתקדם {'>'} REST API</li>
                    <li>לחץ על "הוסף מפתח" ליצירת מפתחות חדשים</li>
                    <li>בחר "קריאה/כתיבה" בהרשאות</li>
                    <li>העתק את Consumer Key ו-Consumer Secret</li>
                  </ol>
                  <a
                    href="https://woocommerce.com/document/woocommerce-rest-api/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 mt-3 text-sm text-blue-600 hover:text-blue-800"
                  >
                    <span>קרא עוד בתיעוד הרשמי</span>
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </div>

            <div>
              <h2 className="text-lg font-semibold mb-4">פעולות</h2>
              <div className="space-y-4">
                <button
                  onClick={handleDeleteAllProducts}
                  disabled={isImporting}
                  className="w-full bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  <X className="w-5 h-5" />
                  מחק את כל המוצרים הקיימים
                </button>
                <button
                  onClick={handleWooCommerceImport}
                  disabled={isImporting}
                  className="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  <Download className="w-5 h-5" />
                  {isImporting ? 'מייבא מוצרים...' : 'התחל ייבוא'}
                </button>
              </div>
            </div>

            {isImporting && (
              <div>
                <h2 className="text-lg font-semibold mb-4">התקדמות</h2>
                <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-600 transition-all duration-300"
                    style={{ width: `${importProgress}%` }}
                  />
                </div>
                <p className="text-center mt-2 text-sm text-gray-600">
                  מייבא מוצרים... {importProgress}%
                </p>
              </div>
            )}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold mb-4">לוג ייבוא</h2>
          <div 
            id="import-log"
            className="h-[500px] overflow-y-auto bg-gray-50 rounded-lg p-4 font-mono text-sm whitespace-pre-wrap"
            dir="ltr"
          >
            {importLog.length === 0 ? (
              <p className="text-gray-500 text-center" dir="rtl">הלוג יוצג כאן כשתתחיל בייבוא...</p>
            ) : (
              importLog.map((log, index) => (
                <div 
                  key={index} 
                  className={`py-1 ${log.includes('🔴') ? 'text-red-600' : ''}`}
                >
                  {log}
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}