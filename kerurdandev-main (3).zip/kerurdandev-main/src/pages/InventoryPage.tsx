import React, { useState, useEffect } from 'react';
import { Plus, Minus, Search, Package, X, Pencil, Trash2, Building2, Download, GripVertical } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Warehouse, WarehouseInventory, InventoryProduct } from '../types/inventory';

interface Dimension {
  id: string;
  length: number;
  width: number;
  height: number;
  product_code?: string;
}

interface Product extends InventoryProduct {
  dimensions?: Dimension[];
  specifications: {
    length: number;
    width: number;
    height: number;
  };
}

export function InventoryPage() {
  const [selectedWarehouse, setSelectedWarehouse] = useState<string>('');
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [inventory, setInventory] = useState<WarehouseInventory[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [showAddProductModal, setShowAddProductModal] = useState(false);
  const [showDimensionsModal, setShowDimensionsModal] = useState<{
    show: boolean;
    product: Product | null;
  }>({
    show: false,
    product: null
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isDeleting, setIsDeleting] = useState(false);
  const [editingQuantity, setEditingQuantity] = useState<{
    id: string;
    quantity: number;
  } | null>(null);
  const [editingReserved, setEditingReserved] = useState<{
    id: string;
    reserved: number;
  } | null>(null);
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [draggedItem, setDraggedItem] = useState<string | null>(null);

  useEffect(() => {
    fetchWarehouses();
    fetchProducts();
  }, []);

  useEffect(() => {
    if (selectedWarehouse) {
      fetchInventory(selectedWarehouse);
    }
  }, [selectedWarehouse]);

  async function fetchWarehouses() {
    try {
      const { data, error } = await supabase
        .from('warehouses')
        .select('*')
        .order('name');

      if (error) throw error;
      setWarehouses(data || []);
    } catch (error) {
      console.error('Error fetching warehouses:', error);
    } finally {
      setIsLoading(false);
    }
  }

  async function fetchProducts() {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('id, product_code, name, supplier, image_url, specifications, dimensions, created_at')
        .order('name');

      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  }

  async function fetchInventory(warehouseId: string) {
    try {
      const { data, error } = await supabase
        .from('warehouse_inventory')
        .select(`
          *,
          product:products(
            id,
            name,
            product_code,
            supplier,
            image_url,
            specifications,
            dimensions
          )
        `)
        .eq('warehouse_id', warehouseId)
        .order('display_order', { ascending: true });

      if (error) throw error;

      // הסר כפילויות של כמות 0 (אם צריך)
      const filteredData = removeDuplicateZeroQuantity(data || []);

      // בדוק אם יש סדר מותאם אישית
      const hasCustomOrder = filteredData.some(item => item.display_order !== null && item.display_order !== undefined);

      if (!hasCustomOrder) {
        // סידור אוטומטי אם אין סדר מותאם אישית
        const sortedData = sortInventoryByProductAndDimensions(filteredData);
        setInventory(sortedData);
      } else {
        // השתמש בסידור שכבר הגיע מהבסיס נתונים
        setInventory(filteredData);
      }
    } catch (error) {
      console.error('Error fetching inventory:', error);
      setInventory([]);
    }
  }

  const handleUpdateQuantity = async (inventoryId: string, currentQuantity: number, change: number) => {
    const newQuantity = currentQuantity + change;
    if (newQuantity < 0) {
      alert('לא ניתן להוריד כמות מתחת ל-0');
      return;
    }

    try {
      const { error } = await supabase
        .from('warehouse_inventory')
        .update({ quantity: newQuantity })
        .eq('id', inventoryId);

      if (error) throw error;
      
      // Update locally without refetching
      setInventory(prev => prev.map(item => 
        item.id === inventoryId 
          ? { ...item, quantity: newQuantity, available_quantity: newQuantity - (item.reserved_quantity || 0) }
          : item
      ));
    } catch (error) {
      console.error('Error updating quantity:', error);
      alert('שגיאה בעדכון הכמות. אנא נסה שוב.');
    }
  };

  const handleSetQuantity = async (inventoryId: string, newQuantity: number) => {
    if (newQuantity < 0) {
      alert('לא ניתן להגדיר כמות שלילית');
      return;
    }

    try {
      const { error } = await supabase
        .from('warehouse_inventory')
        .update({ quantity: newQuantity })
        .eq('id', inventoryId);

      if (error) throw error;
      
      // Update locally without refetching
      setInventory(prev => prev.map(item => 
        item.id === inventoryId 
          ? { ...item, quantity: newQuantity, available_quantity: newQuantity - (item.reserved_quantity || 0) }
          : item
      ));
      setEditingQuantity(null);
    } catch (error) {
      console.error('Error updating quantity:', error);
      alert('שגיאה בעדכון הכמות. אנא נסה שוב.');
    }
  };

  const handleSetReserved = async (inventoryId: string, newReserved: number) => {
    if (newReserved < 0) {
      alert('לא ניתן להגדיר כמות שלילית');
      return;
    }

    try {
      const { error } = await supabase
        .from('warehouse_inventory')
        .update({ reserved_quantity: newReserved })
        .eq('id', inventoryId);

      if (error) throw error;
      
      // Update locally without refetching
      setInventory(prev => prev.map(item => 
        item.id === inventoryId 
          ? { ...item, reserved_quantity: newReserved, available_quantity: item.quantity - newReserved }
          : item
      ));
      setEditingReserved(null);
    } catch (error) {
      console.error('Error updating reserved quantity:', error);
      alert('שגיאה בעדכון הכמות המוזמנת. אנא נסה שוב.');
    }
  };

  const handleDeleteInventoryItem = async (inventoryId: string) => {
    if (!window.confirm('האם אתה בטוח שברצונך למחוק פריט זה מהמלאי?')) {
      return;
    }

    setIsDeleting(true);
    try {
      const { error } = await supabase
        .from('warehouse_inventory')
        .delete()
        .eq('id', inventoryId);

      if (error) throw error;
      fetchInventory(selectedWarehouse);
    } catch (error) {
      console.error('Error deleting inventory item:', error);
      alert('שגיאה במחיקת הפריט מהמלאי. אנא נסה שוב.');
    } finally {
      setIsDeleting(false);
    }
  };

  const handleAddProduct = (product: Product) => {
    // Check if product has multiple dimensions
    if (product.dimensions && product.dimensions.length > 1) {
      setShowDimensionsModal({
        show: true,
        product
      });
      return;
    }

    // If product has only one dimension or no dimensions, add it directly
    addProductWithDimension(product, 0);
  };

  const addProductWithDimension = async (product: Product, dimensionIndex: number) => {
    try {
      // Check if product with these dimensions already exists in inventory
      const existingProduct = inventory.find(item => {
        const dimensions = product.dimensions?.[dimensionIndex] || product.specifications;
        return (
          item.product_id === product.id &&
          item.product_size?.length === dimensions.length &&
          item.product_size?.width === dimensions.width &&
          item.product_size?.height === dimensions.height
        );
      });

      if (existingProduct) {
        alert('מוצר זה כבר קיים במלאי המחסן');
        setShowDimensionsModal({ show: false, product: null });
        setShowAddProductModal(false);
        return;
      }

      const dimensions = product.dimensions?.[dimensionIndex] || {
        ...product.specifications,
        product_code: product.product_code
      };
      
      const { error } = await supabase
        .from('warehouse_inventory')
        .insert({
          warehouse_id: selectedWarehouse,
          product_id: product.id,
          quantity: 0,
          product_size: dimensions
        });

      if (error) throw error;
      
      fetchInventory(selectedWarehouse);
      setShowDimensionsModal({ show: false, product: null });
      setShowAddProductModal(false);
    } catch (error: any) {
      console.error('Error adding product to inventory:', error);
      if (error.code === '23505') {
        alert('מוצר זה כבר קיים במלאי המחסן');
      } else {
        alert('שגיאה בהוספת המוצר למלאי. אנא נסה שוב.');
      }
    }
  };

  const getProductDimensions = (product: Product): Dimension[] => {
    if (product.dimensions && product.dimensions.length > 0) {
      return product.dimensions;
    }
    return [{
      id: '1',
      length: product.specifications.length,
      width: product.specifications.width,
      height: product.specifications.height,
      product_code: product.product_code || undefined
    }];
  };

  // Check if a product with specific dimensions is already in inventory
  const isProductDimensionInInventory = (product: Product, dimensionIndex: number) => {
    const dimensions = product.dimensions?.[dimensionIndex] || product.specifications;
    return inventory.some(item => 
      item.product_id === product.id && 
      item.product_size?.length === dimensions.length &&
      item.product_size?.width === dimensions.width &&
      item.product_size?.height === dimensions.height
    );
  };

  const downloadInventoryAsCSV = () => {
    if (!selectedWarehouse || inventory.length === 0) {
      alert('אין מלאי להורדה במחסן הנבחר');
      return;
    }

    const selectedWarehouseName = warehouses.find(w => w.id === selectedWarehouse)?.name || '';

    // Prepare CSV headers
    const headers = ['מוצר', 'קוד מוצר', 'ספק', 'מידות', 'כמות במלאי', 'מוזמן', 'יתרה במחסן', 'מחסן'];

         // Prepare CSV rows
     const rows = inventory.map(item => {
       let dimensions = '';
       if (item.product_size) {
         dimensions = `${item.product_size.width}x${item.product_size.height}x${item.product_size.length}`;
       } else if (item.product.specifications) {
         dimensions = `${item.product.specifications.width}x${item.product.specifications.height}x${item.product.specifications.length}`;
       }
      
      return [
        item.product.name,
        item.product.product_code,
        item.product.supplier,
        dimensions,
        item.quantity.toString(),
        item.reserved_quantity.toString(),
        item.available_quantity.toString(),
        selectedWarehouseName
      ];
    });

    // Combine headers and rows
    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\n');

    // Create and trigger download
    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `מלאי_${selectedWarehouseName}_${new Date().toLocaleDateString('he-IL')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleBulkDelete = async () => {
    if (!window.confirm('האם למחוק את כל הפריטים המסומנים?')) return;
    try {
      const { error } = await supabase
        .from('warehouse_inventory')
        .delete()
        .in('id', selectedItems);
      if (error) throw error;
      setSelectedItems([]);
      fetchInventory(selectedWarehouse);
    } catch (error) {
      alert('שגיאה במחיקה. נסה שוב.');
    }
  };

  // Drag and Drop handlers
  const handleDragStart = (e: React.DragEvent, itemId: string) => {
    setDraggedItem(itemId);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = async (e: React.DragEvent, targetItemId: string) => {
    e.preventDefault();
    
    if (!draggedItem || draggedItem === targetItemId) {
      setDraggedItem(null);
      return;
    }

    const draggedIndex = inventory.findIndex(item => item.id === draggedItem);
    const targetIndex = inventory.findIndex(item => item.id === targetItemId);

    if (draggedIndex === -1 || targetIndex === -1) {
      setDraggedItem(null);
      return;
    }

    // Get the product name of the dragged item
    const draggedProductName = inventory[draggedIndex].product.name;
    const targetProductName = inventory[targetIndex].product.name;

    // Find all items with the same product name as the dragged item
    const draggedProductItems: WarehouseInventory[] = [];
    const otherItems: WarehouseInventory[] = [];

    inventory.forEach((item, index) => {
      if (item.product.name === draggedProductName) {
        draggedProductItems.push(item);
      } else {
        otherItems.push(item);
      }
    });

    // Find the target product group
    const targetProductItems: WarehouseInventory[] = [];
    const remainingItems: WarehouseInventory[] = [];

    otherItems.forEach(item => {
      if (item.product.name === targetProductName) {
        targetProductItems.push(item);
      } else {
        remainingItems.push(item);
      }
    });

    // Rebuild the inventory with the dragged product group moved
    const newInventory: WarehouseInventory[] = [];
    let draggedGroupInserted = false;

    for (let i = 0; i < inventory.length; i++) {
      const currentItem = inventory[i];
      
      if (currentItem.product.name === draggedProductName) {
        // Skip dragged items, we'll insert them later
        continue;
      }
      
      if (currentItem.product.name === targetProductName && !draggedGroupInserted) {
        // Insert dragged product group before target product group
        newInventory.push(...draggedProductItems);
        draggedGroupInserted = true;
      }
      
      newInventory.push(currentItem);
    }

    // If we haven't inserted the dragged group yet, add it at the end
    if (!draggedGroupInserted) {
      newInventory.push(...draggedProductItems);
    }

    // Update local state immediately for responsive UI
    setInventory(newInventory);
    setDraggedItem(null);

    // שמור את הסדר החדש בבסיס הנתונים
    try {
      // צור מיפוי של מזהי פריטים לסדר החדש
      const orderMap = newInventory.map((item, index) => ({
        id: item.id,
        display_order: index + 1
      }));

      // עדכן את כל הפריטים עם הסדר החדש
      for (const orderItem of orderMap) {
        await supabase
          .from('warehouse_inventory')
          .update({ display_order: orderItem.display_order })
          .eq('id', orderItem.id);
      }
    } catch (error) {
      console.error('Error saving inventory order:', error);
      alert('שגיאה בשמירת הסדר החדש. הסדר עשוי לא להישמר.');
    }
  };

  // Function to remove duplicate products with quantity 0
  const removeDuplicateZeroQuantity = (inventoryData: WarehouseInventory[]): WarehouseInventory[] => {
    const productGroups = new Map<string, WarehouseInventory[]>();
    
    // Group products by product code (from product_size or product)
    inventoryData.forEach(item => {
      const productCode = item.product_size?.product_code || item.product.product_code;
      const key = productCode || item.product_id; // Fallback to product_id if no product code
      
      if (!productGroups.has(key)) {
        productGroups.set(key, []);
      }
      productGroups.get(key)!.push(item);
    });
    
    // Filter out duplicates with quantity 0
    const filteredInventory: WarehouseInventory[] = [];
    
    productGroups.forEach(group => {
      if (group.length === 1) {
        // Single item, keep it
        filteredInventory.push(group[0]);
      } else {
        // Multiple items with same product code
        const nonZeroItems = group.filter(item => item.quantity > 0);
        const zeroItems = group.filter(item => item.quantity === 0);
        
        if (nonZeroItems.length > 0) {
          // Keep non-zero items, remove zero items
          filteredInventory.push(...nonZeroItems);
        } else {
          // All items are zero, keep the first one
          filteredInventory.push(group[0]);
        }
      }
    });
    
    return filteredInventory;
  };

  // Function to sort inventory by product and dimensions
  const sortInventoryByProductAndDimensions = (inventoryData: WarehouseInventory[]): WarehouseInventory[] => {
    // Group by product name first
    const productGroups = new Map<string, WarehouseInventory[]>();
    
    inventoryData.forEach(item => {
      const productName = item.product.name;
      if (!productGroups.has(productName)) {
        productGroups.set(productName, []);
      }
      productGroups.get(productName)!.push(item);
    });
    
    // Sort products alphabetically and then sort dimensions within each product
    const sortedInventory: WarehouseInventory[] = [];
    
    // Get sorted product names
    const sortedProductNames = Array.from(productGroups.keys()).sort();
    
    sortedProductNames.forEach(productName => {
      const productItems = productGroups.get(productName)!;
      
      // Sort items within the same product by dimensions
      const sortedProductItems = productItems.sort((a, b) => {
        // First, sort by length
        const aLength = a.product_size?.length || a.product.specifications?.length || 0;
        const bLength = b.product_size?.length || b.product.specifications?.length || 0;
        if (aLength !== bLength) return aLength - bLength;
        
        // Then by width
        const aWidth = a.product_size?.width || a.product.specifications?.width || 0;
        const bWidth = b.product_size?.width || b.product.specifications?.width || 0;
        if (aWidth !== bWidth) return aWidth - bWidth;
        
        // Finally by height
        const aHeight = a.product_size?.height || a.product.specifications?.height || 0;
        const bHeight = b.product_size?.height || b.product.specifications?.height || 0;
        return aHeight - bHeight;
      });
      
      sortedInventory.push(...sortedProductItems);
    });
    
    return sortedInventory;
  };

  // Function to clean up duplicates manually
  const handleCleanupDuplicates = () => {
    const originalCount = inventory.length;
    const cleanedInventory = removeDuplicateZeroQuantity(inventory);
    const removedCount = originalCount - cleanedInventory.length;
    
    if (removedCount > 0) {
      setInventory(cleanedInventory);
      
      // Find which products were removed for better feedback
      const removedProducts = inventory.filter(item => {
        const productCode = item.product_size?.product_code || item.product.product_code;
        const hasDuplicate = inventory.filter(otherItem => {
          const otherProductCode = otherItem.product_size?.product_code || otherItem.product.product_code;
          return productCode === otherProductCode && item.quantity === 0 && otherItem.quantity > 0;
        }).length > 0;
        return hasDuplicate;
      });
      
      const removedNames = removedProducts.map(item => item.product.name).join(', ');
      alert(`נוקו ${removedCount} פריטים כפולים עם כמות 0:\n${removedNames}`);
    } else {
      alert('לא נמצאו כפילויות לנקות');
    }
  };

  // Function to sort inventory manually
  const handleSortInventory = async () => {
    const sortedInventory = sortInventoryByProductAndDimensions(inventory);
    setInventory(sortedInventory);
    
    // שמור את הסדר החדש בבסיס הנתונים
    try {
      const orderMap = sortedInventory.map((item, index) => ({
        id: item.id,
        display_order: index + 1
      }));

      for (const orderItem of orderMap) {
        await supabase
          .from('warehouse_inventory')
          .update({ display_order: orderItem.display_order })
          .eq('id', orderItem.id);
      }
      
      alert('המלאי סודר לפי מוצר ומידות ונשמר');
    } catch (error) {
      console.error('Error saving inventory order:', error);
      alert('המלאי סודר אך לא נשמר. נסה שוב.');
    }
  };

  // Function to reset custom order
  const handleResetOrder = async () => {
    try {
      // אפס את display_order לכל הפריטים במחסן הזה
      await supabase
        .from('warehouse_inventory')
        .update({ display_order: null })
        .eq('warehouse_id', selectedWarehouse);

      // טען מחדש את המלאי
      fetchInventory(selectedWarehouse);
      
      alert('הסדר המותאם אישית אופס');
    } catch (error) {
      console.error('Error resetting inventory order:', error);
      fetchInventory(selectedWarehouse);
      alert('שגיאה באיפוס הסדר. נסה שוב.');
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-500 border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Top row: Title, warehouse selector, and action buttons all aligned */}
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-4">
          <h1 className="text-2xl font-bold">ניהול מלאי</h1>
          <Building2 className="w-5 h-5 text-gray-600" />
          <select
            value={selectedWarehouse}
            onChange={(e) => setSelectedWarehouse(e.target.value)}
            className="border rounded-md px-3 py-2 bg-white shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">בחר מחסן</option>
            {warehouses.map((warehouse) => (
              <option key={warehouse.id} value={warehouse.id}>
                {warehouse.name}
              </option>
            ))}
          </select>
        </div>
                 <div className="flex items-center gap-3">
           {selectedWarehouse && (
             <>
                               <button
                  onClick={handleSortInventory}
                  className="flex items-center gap-2 bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600 transition-colors shadow-sm"
                >
                  <GripVertical className="w-4 h-4" />
                  סדר מלאי
                </button>
                <button
                  onClick={handleResetOrder}
                  className="flex items-center gap-2 bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 transition-colors shadow-sm"
                >
                  <X className="w-4 h-4" />
                  אפס סדר
                </button>
               <button
                 onClick={handleCleanupDuplicates}
                 className="flex items-center gap-2 bg-orange-500 text-white px-4 py-2 rounded-md hover:bg-orange-600 transition-colors shadow-sm"
               >
                 <Trash2 className="w-4 h-4" />
                 נקה כפילויות
               </button>
               <button
                 onClick={downloadInventoryAsCSV}
                 className="flex items-center gap-2 bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition-colors shadow-sm"
               >
                 <Download className="w-4 h-4" />
                 הורד מלאי כ־CSV
               </button>
               <button
                 onClick={() => setShowAddProductModal(true)}
                 className="inline-flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
               >
                 <Plus className="w-5 h-5" />
                 הוסף מוצר למלאי
               </button>
             </>
           )}
         </div>
      </div>

      {/* Full-width search bar row */}
      <div className="mb-6">
        <div className="relative w-full">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="חיפוש מוצר..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="border rounded-md pl-10 pr-4 py-2 w-full shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
      </div>

      {!selectedWarehouse ? (
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <Building2 className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">בחר מחסן כדי לצפות במלאי</h3>
          <p className="text-gray-500">
            בחר מחסן מהרשימה למעלה כדי לראות את המוצרים במלאי ולנהל אותם
          </p>
        </div>
      ) : (
        <div>
          {inventory.length === 0 ? (
            <div className="bg-white rounded-lg shadow-md p-8 text-center">
              <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">אין מוצרים במלאי</h3>
              <p className="text-gray-500">
                התחל על ידי הוספת מוצרים למלאי המחסן
              </p>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-2 py-4 text-center w-8">
                        {/* Drag handle column */}
                      </th>
                      <th className="px-4 py-4 text-center">
                        <input
                          type="checkbox"
                          checked={selectedItems.length === inventory.length && inventory.length > 0}
                          onChange={e => {
                            if (e.target.checked) {
                              setSelectedItems(inventory.map(item => item.id));
                            } else {
                              setSelectedItems([]);
                            }
                          }}
                        />
                      </th>
                      <th scope="col" className="px-8 py-4 text-right text-sm font-semibold text-gray-700 uppercase tracking-wider">
                        מוצר
                      </th>
                      <th scope="col" className="px-8 py-4 text-right text-sm font-semibold text-gray-700 uppercase tracking-wider">
                        קוד מוצר
                      </th>
                      <th scope="col" className="px-8 py-4 text-right text-sm font-semibold text-gray-700 uppercase tracking-wider">
                        ספק
                      </th>
                      <th scope="col" className="px-8 py-4 text-right text-sm font-semibold text-gray-700 uppercase tracking-wider">
                        מידות
                      </th>
                      <th scope="col" className="px-8 py-4 text-right text-sm font-semibold text-gray-700 uppercase tracking-wider">
                        כמות במלאי
                      </th>
                      <th scope="col" className="px-8 py-4 text-right text-sm font-semibold text-gray-700 uppercase tracking-wider">
                        מוזמן
                      </th>
                      <th scope="col" className="px-8 py-4 text-right text-sm font-semibold text-gray-700 uppercase tracking-wider">
                        יתרה במחסן
                      </th>
                      <th scope="col" className="px-8 py-4 text-right text-sm font-semibold text-gray-700 uppercase tracking-wider">
                        פעולות
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {inventory
                      .filter(item => {
                        const searchLower = searchTerm.toLowerCase();
                        return (
                          item.product.name.toLowerCase().includes(searchLower) ||
                          (item.product.product_code?.toLowerCase() || '').includes(searchLower) ||
                          (item.product.supplier?.toLowerCase() || '').includes(searchLower)
                        );
                      })
                      .map((item) => (
                                                 <tr 
                           key={item.id} 
                           className={`hover:bg-gray-50 ${item.quantity === 0 ? 'bg-red-50' : ''} ${draggedItem === item.id ? 'opacity-50' : ''} ${
                             draggedItem && inventory.find(dragged => dragged.id === draggedItem)?.product.name === item.product.name ? 'bg-blue-50' : ''
                           }`}
                           draggable
                           onDragStart={(e) => handleDragStart(e, item.id)}
                           onDragOver={handleDragOver}
                           onDrop={(e) => handleDrop(e, item.id)}
                         >
                          <td className="px-2 py-4 text-center">
                            <div className="cursor-grab active:cursor-grabbing text-gray-400 hover:text-gray-600">
                              <GripVertical className="w-4 h-4" />
                            </div>
                          </td>
                          <td className="px-4 py-4 text-center">
                            <input
                              type="checkbox"
                              checked={selectedItems.includes(item.id)}
                              onChange={e => {
                                if (e.target.checked) {
                                  setSelectedItems(prev => [...prev, item.id]);
                                } else {
                                  setSelectedItems(prev => prev.filter(id => id !== item.id));
                                }
                              }}
                            />
                          </td>
                          <td className="px-8 py-4">
                            <div className="flex items-center">
                              {item.product.image_url ? (
                                <img
                                  src={item.product.image_url}
                                  alt={item.product.name}
                                  className="h-10 w-10 rounded object-cover"
                                />
                              ) : (
                                <div className="h-10 w-10 rounded bg-gray-100 flex items-center justify-center">
                                  <Package className="h-5 w-5 text-gray-400" />
                                </div>
                              )}
                              <div className="mr-4">
                                <div className="text-sm font-medium text-gray-900">
                                  {item.product.name}
                                </div>
                              </div>
                            </div>
                          </td>
                          <td className="px-8 py-4 whitespace-nowrap text-sm text-gray-500">
                            {item.product_size?.product_code || item.product.product_code || '-'}
                          </td>
                          <td className="px-8 py-4 whitespace-nowrap text-sm text-gray-500">
                            {item.product.supplier || '-'}
                          </td>
                                                     <td className="px-8 py-4 whitespace-nowrap text-sm text-gray-500">
                             {item.product_size ? (
                               <>
                                 {console.log('Product Size for', item.product.name, ':', item.product_size)}
                                 <span>
                                   {item.product_size.width} × {item.product_size.height} × {item.product_size.length} ס"מ
                                 </span>
                               </>
                             ) : item.product.specifications ? (
                               <>
                                 {console.log('Product Specifications for', item.product.name, ':', item.product.specifications)}
                                 <span>
                                   {item.product.specifications.width} × {item.product.specifications.height} × {item.product.specifications.length} ס"מ
                                 </span>
                               </>
                             ) : '-'}
                           </td>
                          <td className="px-8 py-4 whitespace-nowrap">
                            <div className="flex items-center gap-4">
                              {editingQuantity?.id === item.id ? (
                                <div className="flex items-center gap-2">
                                  <input
                                    type="number"
                                    min="0"
                                    value={editingQuantity.quantity}
                                    onChange={(e) => setEditingQuantity({
                                      ...editingQuantity,
                                      quantity: parseInt(e.target.value) || 0
                                    })}
                                    onKeyDown={(e) => {
                                      if (e.key === 'Enter') {
                                        handleSetQuantity(item.id, editingQuantity.quantity);
                                      } else if (e.key === 'Escape') {
                                        setEditingQuantity(null);
                                      }
                                    }}
                                    className="w-20 px-2 py-1 border rounded text-center"
                                    autoFocus
                                  />
                                  <button
                                    onClick={() => handleSetQuantity(item.id, editingQuantity.quantity)}
                                    className="p-1 text-green-600 hover:bg-green-50 rounded"
                                  >
                                    ✓
                                  </button>
                                  <button
                                    onClick={() => setEditingQuantity(null)}
                                    className="p-1 text-red-600 hover:bg-red-50 rounded"
                                  >
                                    ✕
                                  </button>
                                </div>
                              ) : (
                                <>
                                  <button
                                    onClick={() => setEditingQuantity({ id: item.id, quantity: item.quantity })}
                                    className={`text-lg font-medium hover:text-blue-600 ${item.quantity === 0 ? 'text-red-600' : 'text-gray-900'}`}
                                  >
                                    {item.quantity}
                                  </button>
                                  <div className="flex items-center gap-1">
                                    <button
                                      onClick={() => handleUpdateQuantity(item.id, item.quantity, -1)}
                                      className="p-1 text-red-600 hover:bg-red-50 rounded"
                                    >
                                      <Minus className="w-5 h-5" />
                                    </button>
                                    <button
                                      onClick={() => handleUpdateQuantity(item.id, item.quantity, 1)}
                                      className="p-1 text-green-600 hover:bg-green-50 rounded"
                                    >
                                      <Plus className="w-5 h-5" />
                                    </button>
                                  </div>
                                </>
                              )}
                            </div>
                          </td>
                          <td className="px-8 py-4 whitespace-nowrap">
                            <div className="flex items-center gap-4">
                              {editingReserved?.id === item.id ? (
                                <div className="flex items-center gap-2">
                                  <input
                                    type="number"
                                    min="0"
                                    value={editingReserved.reserved}
                                    onChange={(e) => setEditingReserved({
                                      ...editingReserved,
                                      reserved: parseInt(e.target.value) || 0
                                    })}
                                    onKeyDown={(e) => {
                                      if (e.key === 'Enter') {
                                        handleSetReserved(item.id, editingReserved.reserved);
                                      } else if (e.key === 'Escape') {
                                        setEditingReserved(null);
                                      }
                                    }}
                                    className="w-20 px-2 py-1 border rounded text-center"
                                    autoFocus
                                  />
                                  <button
                                    onClick={() => handleSetReserved(item.id, editingReserved.reserved)}
                                    className="p-1 text-green-600 hover:bg-green-50 rounded"
                                  >
                                    ✓
                                  </button>
                                  <button
                                    onClick={() => setEditingReserved(null)}
                                    className="p-1 text-red-600 hover:bg-red-50 rounded"
                                  >
                                    ✕
                                  </button>
                                </div>
                              ) : (
                                <button
                                  onClick={() => setEditingReserved({ id: item.id, reserved: item.reserved_quantity })}
                                  className="text-lg font-medium text-gray-900 hover:text-blue-600"
                                >
                                  {item.reserved_quantity || 0}
                                </button>
                              )}
                            </div>
                          </td>
                          <td className="px-8 py-4 whitespace-nowrap text-sm">
                            <span className={item.available_quantity === 0 ? 'text-red-600 font-medium' : 'text-gray-500'}>
                              {item.available_quantity || 0}
                            </span>
                          </td>
                          <td className="px-8 py-4 whitespace-nowrap">
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => handleDeleteInventoryItem(item.id)}
                                disabled={isDeleting}
                                className="p-1 text-red-600 hover:bg-red-50 rounded transition-colors"
                                title="מחק מהמלאי"
                              >
                                <Trash2 className="w-5 h-5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
              {/* Bulk delete button */}
              {selectedItems.length > 0 && (
                <div className="mb-4 flex justify-end">
                  <button
                    onClick={handleBulkDelete}
                    className="bg-red-500 text-white px-4 py-2 rounded shadow hover:bg-red-600 transition-colors"
                  >
                    מחק {selectedItems.length} פריטים נבחרים
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Add Product Modal */}
      {showAddProductModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl">
            <div className="p-4 border-b flex justify-between items-center">
              <h2 className="text-lg font-semibold">הוספת מוצר למלאי</h2>
              <button
                onClick={() => setShowAddProductModal(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-4">
              <div className="relative mb-4">
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder="חיפוש מוצר..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="block w-full pr-10 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-h-96 overflow-y-auto">
                {products
                  .filter(product => 
                    product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    (product.product_code?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
                    (product.supplier?.toLowerCase() || '').includes(searchTerm.toLowerCase())
                  )
                  .map(product => (
                    <button
                      key={product.id}
                      onClick={() => handleAddProduct(product)}
                      className="text-right p-4 hover:bg-gray-50 rounded-lg border flex items-start gap-3 transition-colors"
                    >
                      {product.image_url ? (
                        <img
                          src={product.image_url}
                          alt={product.name}
                          className="h-12 w-12 rounded object-cover flex-shrink-0"
                        />
                      ) : (
                        <div className="h-12 w-12 rounded bg-gray-100 flex items-center justify-center flex-shrink-0">
                          <Package className="h-6 w-6 text-gray-400" />
                        </div>
                      )}
                      <div>
                        <div className="font-medium">{product.name}</div>
                        {product.product_code && (
                          <div className="text-sm text-gray-500">קוד: {product.product_code}</div>
                        )}
                        {product.supplier && (
                          <div className="text-sm text-gray-500">ספק: {product.supplier}</div>
                        )}
                        {product.dimensions && product.dimensions.length > 1 && (
                          <div className="mt-2 text-xs text-blue-600">
                            {product.dimensions.length} מידות זמינות
                          </div>
                        )}
                      </div>
                    </button>
                  ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Dimensions Selection Modal */}
      {showDimensionsModal.show && showDimensionsModal.product && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
            <div className="p-4 border-b flex justify-between items-center">
              <h2 className="text-lg font-semibold">בחר מידה למוצר</h2>
              <button
                onClick={() => setShowDimensionsModal({ show: false, product: null })}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-4">
              <h3 className="font-medium text-lg mb-3">{showDimensionsModal.product.name}</h3>
              
              {showDimensionsModal.product && (() => {
                const product = showDimensionsModal.product;
                return (
                  <div className="space-y-3 mt-4">
                    {getProductDimensions(product).map((dimension, index) => {
                      const isInInventory = isProductDimensionInInventory(product, index);
                      return (
                        <button
                          key={dimension.id}
                          className={`w-full p-3 border rounded-lg hover:bg-blue-50 hover:border-blue-300 flex justify-between items-center ${
                            isInInventory ? 'opacity-50 cursor-not-allowed' : ''
                          }`}
                          onClick={() => !isInInventory && addProductWithDimension(product, index)}
                          disabled={isInInventory}
                        >
                          <div>
                            <div className="font-medium">מידה {index + 1}</div>
                            <div className="text-sm text-gray-500">
                              קוד: {dimension.product_code || product.product_code || '-'}
                            </div>
                          </div>
                                                                               <div className="text-gray-600">
                            {(() => {
                              console.log('Inventory Dimension object:', dimension);
                              console.log('Inventory Width:', dimension.width, 'Length:', dimension.length, 'Height:', dimension.height);
                              return null;
                            })()}
                            {dimension.width} × {dimension.length} × {dimension.height} ס"מ
                          </div>
                        </button>
                      );
                    })}
                  </div>
                );
              })()}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}