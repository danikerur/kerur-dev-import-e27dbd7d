import { useEffect, useMemo, useRef, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import type { InventoryRow } from '../types/inventory';
import { fetchInventory, updateInventoryRow, fetchProductsByIds, fetchProductCategoryIds, fetchAllCategories, fetchReservedCounts, fetchReservedDetails, fetchWarehousesList, fetchWarehouseInventoryByWarehouse, upsertWarehouseInventoryQuantity, type Category } from '../lib/db.inventory';
import { useToast, ToastViewport } from '../hooks/useToast';
import { Building2, AlertTriangle, Boxes, ClipboardList, Search, Filter, TrendingUp, TrendingDown, Plus, Download, Trash2 } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { normalizeText, normalizeSize } from '../lib/normalizers';
import type { Warehouse } from '../types/inventory';

type EditableFields = Pick<InventoryRow, 'on_hand' | 'on_order_from_supplier'>;

export default function InventoryTrackingPage() {
  const queryClient = useQueryClient();
  const { helpers: toast, toasts, dismissToast } = useToast();
  const navigate = useNavigate();

  const statusLabels: Record<string, string> = {
    Draft: 'טיוטה',
    Confirmed: 'מאושרת',
    Fulfilled: 'סופקה',
    Cancelled: 'בוטלה',
  };

  // Warehouses selection
  const [selectedWarehouse, setSelectedWarehouse] = useState<string>('');
  const { data: warehouses } = useQuery({
    queryKey: ['warehouses-list'],
    queryFn: fetchWarehousesList,
    staleTime: 300_000,
  });
  useEffect(() => {
    if (!selectedWarehouse && warehouses && warehouses.length > 0) {
      setSelectedWarehouse(warehouses[0].id);
    }
  }, [warehouses, selectedWarehouse]);

  const { data, isLoading, isError, error } = useQuery({
    queryKey: ['inventory-tracking'],
    queryFn: fetchInventory,
    staleTime: 60_000,
  });

  const productIds = useMemo(
    () => Array.from(new Set((data ?? []).map((r) => r.product_id))),
    [data]
  );

  const { data: productImages } = useQuery({
    queryKey: ['inventory-product-images', productIds],
    queryFn: () => fetchProductsByIds(productIds),
    enabled: productIds.length > 0,
    staleTime: 300_000,
  });

  const { data: productCategoryIds } = useQuery({
    queryKey: ['inventory-product-categories', productIds],
    queryFn: () => fetchProductCategoryIds(productIds),
    enabled: productIds.length > 0,
    staleTime: 300_000,
  });

  const { data: allCategories } = useQuery({
    queryKey: ['categories-all'],
    queryFn: () => fetchAllCategories(),
    staleTime: 300_000,
  });

  const { data: reservedMap } = useQuery({
    queryKey: ['inventory-reserved-counts'],
    queryFn: () => fetchReservedCounts(),
    staleTime: 30_000,
    refetchInterval: 30_000,
  });

  // Warehouse inventory for selected warehouse
  const { data: warehouseInventory } = useQuery({
    queryKey: ['warehouse-inventory', selectedWarehouse],
    queryFn: () => fetchWarehouseInventoryByWarehouse(selectedWarehouse),
    enabled: !!selectedWarehouse,
    staleTime: 10_000,
  });
  const selectedWarehouseName = useMemo(() => {
    const wh = (warehouses ?? []).find((w) => w.id === selectedWarehouse);
    return wh?.name ?? '';
  }, [warehouses, selectedWarehouse]);

  // Reserved details modal
  const [reservedPreview, setReservedPreview] = useState<{ name: string; size: string } | null>(null);
  const { data: reservedDetails, isLoading: reservedLoading } = useQuery({
    queryKey: ['reserved-details', reservedPreview?.name, reservedPreview?.size, selectedWarehouse],
    queryFn: () => fetchReservedDetails(reservedPreview!.name, reservedPreview!.size, selectedWarehouse || undefined),
    enabled: !!reservedPreview,
    staleTime: 15_000,
  });
  useEffect(() => {
    if (reservedPreview) {
      try {
        console.log('[inventory] open reserved-details modal', reservedPreview);
      } catch {}
    }
  }, [reservedPreview]);
  useEffect(() => {
    if (reservedPreview && !reservedLoading) {
      try {
        console.log('[inventory] reserved-details query finished', {
          name: reservedPreview.name,
          size: reservedPreview.size,
          count: reservedDetails?.length ?? 0,
          data: (reservedDetails ?? []).slice(0, 5),
        });
        if ((reservedDetails?.length ?? 0) === 0) {
          // הדפסת דיבאג מורחבת כאשר לא נמצאו תוצאות
          const invName = normalizeText(reservedPreview.name);
          const invSize = normalizeSize(reservedPreview.size);
          const invKey = `${invName}__${invSize}`;
          const keys = Object.keys(reservedMap ?? {});
          const sizeMatches = keys.filter((k) => k.endsWith(`__${invName}__${invSize}`));
          console.log('[inventory] reserved-details debug', {
            invName,
            invSize,
            invKey,
            reservedMapSize: keys.length,
            sampleKeys: keys.slice(0, 10),
            sizeMatches: sizeMatches.slice(0, 10),
          });
        }
      } catch {}
    }
  }, [reservedPreview, reservedLoading, reservedDetails]);

  // Realtime sync: ברגע שיש שינוי בסטטוס הזמנה או בפריטים → רענון מיידי של "שמור ללקוחות"
  useEffect(() => {
    const channel = supabase
      .channel('inventory-reserved-sync')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'customer_order' }, () => {
        // סטטוס השתנה → רענן חישוב שמורים + פרטי תיבה אם פתוחה
        queryClient.invalidateQueries({ queryKey: ['inventory-reserved-counts'] });
        if (reservedPreview) {
          queryClient.invalidateQueries({ queryKey: ['reserved-details', reservedPreview.name, reservedPreview.size] });
        }
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'customer_order_items' }, () => {
        queryClient.invalidateQueries({ queryKey: ['inventory-reserved-counts'] });
        if (reservedPreview) {
          queryClient.invalidateQueries({ queryKey: ['reserved-details', reservedPreview.name, reservedPreview.size] });
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [queryClient, reservedPreview]);

  // Global search across all rows (declare before any usage)
  const [searchTerm, setSearchTerm] = useState<string>('');
  // Top controls: status, categories, sorting
  const [statusFilter, setStatusFilter] = useState<'all' | 'in_stock' | 'out_of_stock'>('all');
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>('');
  const [sortKey, setSortKey] = useState<'name' | 'available_desc' | 'on_hand_desc' | 'on_order_desc'>('name');

  // Hiding variants/products locally (inventory-only view) persisted to localStorage
  const [hiddenVariants, setHiddenVariants] = useState<Record<string, true>>(() => {
    try {
      return JSON.parse(localStorage.getItem('inventory_hidden_variants') || '{}') as Record<string, true>;
    } catch {
      return {};
    }
  });
  const [customSizeLabels, setCustomSizeLabels] = useState<Record<string, string>>(() => {
    try {
      return JSON.parse(localStorage.getItem('inventory_custom_size_labels') || '{}') as Record<string, string>;
    } catch {
      return {};
    }
  });
  useEffect(() => {
    localStorage.setItem('inventory_hidden_variants', JSON.stringify(hiddenVariants));
  }, [hiddenVariants]);
  useEffect(() => {
    localStorage.setItem('inventory_custom_size_labels', JSON.stringify(customSizeLabels));
  }, [customSizeLabels]);

  const hideVariant = (variantId: string) => {
    setHiddenVariants((prev) => ({ ...prev, [variantId]: true }));
  };
  const unhideVariant = (variantId: string) => {
    setHiddenVariants((prev) => {
      const { [variantId]: _, ...rest } = prev;
      return rest;
    });
  };

  // Inline edit for size label per variant
  const [editingSizeFor, setEditingSizeFor] = useState<string | null>(null);
  const [editingSizeValue, setEditingSizeValue] = useState<string>('');

  const topParentNameByProductId = useMemo(() => {
    if (!productCategoryIds || !allCategories) return {};
    const byId = new Map<string, Category>();
    for (const c of allCategories) byId.set(c.id, c);
    const result: Record<string, string> = {};
    for (const [pid, catId] of Object.entries(productCategoryIds)) {
      if (!catId) continue;
      const cat = byId.get(catId);
      if (!cat) continue;
      let parent: Category | undefined = cat;
      if (cat.parent_id) {
        parent = byId.get(cat.parent_id) || cat;
      }
      result[pid] = parent?.name ?? '';
    }
    return result;
  }, [productCategoryIds, allCategories]);

  // Build descendants map for categories to allow filtering by parent category
  const descendantsByCategoryId = useMemo(() => {
    if (!allCategories) return new Map<string, Set<string>>();
    const children = new Map<string, string[]>();
    for (const c of allCategories) {
      if (c.parent_id) {
        const list = children.get(c.parent_id) ?? [];
        list.push(c.id);
        children.set(c.parent_id, list);
      }
    }
    const result = new Map<string, Set<string>>();
    const collect = (id: string, acc: Set<string>) => {
      const kids = children.get(id) ?? [];
      for (const k of kids) {
        if (!acc.has(k)) {
          acc.add(k);
          collect(k, acc);
        }
      }
    };
    for (const c of allCategories) {
      const set = new Set<string>();
      collect(c.id, set);
      result.set(c.id, set);
    }
    return result;
  }, [allCategories]);

  const parentAliases: Record<string, string[]> = {
    'מקררים': ['מקרר', 'מקררים', 'מקרר תעשייתי', 'מקררים תעשייתיים'],
    'מקפיאים': ['מקפיא', 'מקפיאים', 'מקפיא תעשייתי', 'מקפיאים תעשייתיים'],
    'מעדניות': ['מעדניה', 'מעדניות'],
    'חלביות': ['חלביה', 'חלביות'],
  };

  function matchesParentFilterName(name: string | undefined, filter: string): boolean {
    if (!filter) return true;
    const n = (name || '').toLowerCase();
    const aliases = parentAliases[filter] ?? [filter];
    return aliases.some(a => n.includes(a.toLowerCase()));
  }

  // Local edit state per variant
  const [edits, setEdits] = useState<Record<string, EditableFields>>({});
  // Build map from product+size to quantity in selected warehouse, then initialize edits
  const warehouseQuantityByVariant = useMemo(() => {
    const map = new Map<string, number>();
    if (!data || !warehouseInventory) return map;
    const byProductAndDims = new Map<string, number>();
    const makeKey = (productId: string, w?: number | null, h?: number | null, l?: number | null) =>
      `${productId}__${w ?? ''}x${h ?? ''}x${l ?? ''}`;
    for (const item of warehouseInventory) {
      const width = item.product_size?.width ?? null;
      const height = item.product_size?.height ?? null;
      const length = item.product_size?.length ?? null;
      const k = makeKey(item.product_id, width, height, length);
      byProductAndDims.set(k, (item as any).quantity ?? 0);
    }
    for (const row of data) {
      const k = makeKey(row.product_id, row.width, row.height, row.length);
      const qty = byProductAndDims.get(k);
      map.set(row.variant_id, qty ?? 0);
    }
    return map;
  }, [data, warehouseInventory]);
  useEffect(() => {
    if (data && data.length > 0) {
      const initial: Record<string, EditableFields> = {};
      for (const row of data) {
        const whQty = warehouseQuantityByVariant.get(row.variant_id) ?? 0;
        initial[row.variant_id] = {
          on_hand: whQty,
          on_order_from_supplier: row.on_order_from_supplier,
        };
      }
      setEdits(initial);
    }
  }, [data, warehouseQuantityByVariant]);

  // Debounce timers per variant/field
  const timersRef = useRef<Record<string, { on_hand?: ReturnType<typeof setTimeout>; on_order_from_supplier?: ReturnType<typeof setTimeout> }>>({});
  const DEBOUNCE_MS = 400;

  const mutationOrderQty = useMutation({
    mutationFn: async (vars: { variant_id: string; patch: Partial<EditableFields> }) => {
      await updateInventoryRow(vars.variant_id, vars.patch);
      return vars;
    },
    onMutate: async ({ variant_id, patch }) => {
      await queryClient.cancelQueries({ queryKey: ['inventory-tracking'] });

      const previous = queryClient.getQueryData<InventoryRow[]>(['inventory-tracking']);
      if (previous) {
        const updated = previous.map((r) =>
          r.variant_id === variant_id ? { ...r, ...patch, available_now: computeAvailableNow({ ...r, ...patch } as InventoryRow) } : r
        );
        queryClient.setQueryData(['inventory-tracking'], updated);
      }
      return { previous };
    },
    onError: (_err, _vars, context) => {
      if (context?.previous) {
        queryClient.setQueryData(['inventory-tracking'], context.previous);
      }
      toast.error('אירעה שגיאה בשמירה');
    },
    onSuccess: () => {
      toast.success('נשמר בהצלחה');
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ['inventory-tracking'] });
    },
  });

  // Mutation for on_hand quantity per warehouse
  const mutationOnHand = useMutation({
    mutationFn: async (vars: { row: InventoryRow; quantity: number }) => {
      if (!selectedWarehouse) throw new Error('לא נבחר מחסן');
      await upsertWarehouseInventoryQuantity(
        selectedWarehouse,
        vars.row.product_id,
        { width: vars.row.width ?? null, height: vars.row.height ?? null, length: vars.row.length ?? null },
        vars.quantity ?? 0
      );
      return vars;
    },
    onError: () => {
      toast.error('אירעה שגיאה בשמירת מלאי המחסן');
    },
    onSuccess: () => {
      toast.success('המלאי למחסן נשמר');
    },
    onSettled: () => {
      // Refresh warehouse inventory so quantities reflect latest
      queryClient.invalidateQueries({ queryKey: ['warehouse-inventory', selectedWarehouse] });
    },
  });

  function computeAvailableNow(row: InventoryRow): number {
    const onHand = row.on_hand ?? 0;
    const onOrder = row.on_order_from_supplier ?? 0;
    const reserved = row.reserved_for_customers ?? 0;
    return onHand + onOrder - reserved;
  }

  function handleChange(variant_id: string, field: keyof EditableFields, value: number) {
    setEdits((prev) => ({
      ...prev,
      [variant_id]: {
        on_hand: prev[variant_id]?.on_hand ?? 0,
        on_order_from_supplier:
          field === 'on_order_from_supplier' ? value : prev[variant_id]?.on_order_from_supplier ?? 0,
      },
    }));

    // Debounce save
    if (timersRef.current[variant_id]?.[field]) {
      clearTimeout(timersRef.current[variant_id]![field]!);
    }
    const t = setTimeout(() => {
      if (field === 'on_order_from_supplier') {
        mutationOrderQty.mutate({ variant_id, patch: { [field]: value } });
      }
    }, DEBOUNCE_MS);
    timersRef.current[variant_id] = {
      ...timersRef.current[variant_id],
      [field]: t,
    };
  }

  function flushImmediate(variant_id: string, field: keyof EditableFields) {
    const value = edits[variant_id]?.[field];
    if (typeof value === 'number' && !Number.isNaN(value)) {
      if (timersRef.current[variant_id]?.[field]) {
        clearTimeout(timersRef.current[variant_id]![field]!);
      }
      if (field === 'on_order_from_supplier') {
        mutationOrderQty.mutate({ variant_id, patch: { [field]: value } });
      }
    }
  }

  // Handle on_hand per-warehouse changes
  function handleChangeOnHand(row: InventoryRow, value: number) {
    const variant_id = row.variant_id;
    setEdits((prev) => ({
      ...prev,
      [variant_id]: {
        on_hand: value,
        on_order_from_supplier: prev[variant_id]?.on_order_from_supplier ?? row.on_order_from_supplier ?? 0,
      },
    }));
    if (timersRef.current[variant_id]?.on_hand) {
      clearTimeout(timersRef.current[variant_id]!.on_hand!);
    }
    const t = setTimeout(() => {
      mutationOnHand.mutate({ row, quantity: value });
    }, DEBOUNCE_MS);
    timersRef.current[variant_id] = {
      ...timersRef.current[variant_id],
      on_hand: t,
    };
  }
  function flushImmediateOnHand(row: InventoryRow) {
    const variant_id = row.variant_id;
    const value = edits[variant_id]?.on_hand;
    if (typeof value === 'number' && !Number.isNaN(value)) {
      if (timersRef.current[variant_id]?.on_hand) {
        clearTimeout(timersRef.current[variant_id]!.on_hand!);
      }
      mutationOnHand.mutate({ row, quantity: value });
    }
  }

  // Delete from current warehouse (set quantity to 0)
  function deleteFromWarehouse(row: InventoryRow) {
    if (!selectedWarehouse) {
      try { toast.error('בחר מחסן קודם'); } catch {}
      return;
    }
    const ok = window.confirm('למחוק את הפריט מהמלאי של המחסן הנבחר? הפעולה תאפס את הכמות למחסן זה.');
    if (!ok) return;
    setEdits((prev) => ({
      ...prev,
      [row.variant_id]: {
        on_hand: 0,
        on_order_from_supplier: prev[row.variant_id]?.on_order_from_supplier ?? row.on_order_from_supplier ?? 0,
      },
    }));
    mutationOnHand.mutate({ row, quantity: 0 });
  }

  // Download CSV for current warehouse - include only rows with on_hand > 0
  function downloadWarehouseCsv() {
    if (!selectedWarehouse) {
      try {
        toast.error('בחר מחסן קודם');
      } catch {}
      return;
    }
    const whName = (warehouses ?? []).find((w) => w.id === selectedWarehouse)?.name || '';
    const headers = ['מוצר', 'מידה', 'יש עכשיו במלאי', 'שמור ללקוחות', 'פנוי עכשיו', 'מחסן'];
    const lines: string[] = [];
    lines.push(headers.join(','));
    const rows = data ?? [];
    for (const r of rows) {
      const edit = edits[r.variant_id] ?? {
        on_hand: r.on_hand,
        on_order_from_supplier: r.on_order_from_supplier,
      };
      const defaultLabel =
        r.size_label
          ? r.size_label
          : [r.width, r.height, r.length].filter(Boolean).length > 0
            ? `${r.width ?? '-'}×${r.height ?? '-'}×${r.length ?? '-'}`
            : '-';
      const invNameNorm = normalizeText(r.product_name);
      const sizeNorm = normalizeSize(defaultLabel);
      const reservedFromOrders = reservedMap?.[`${selectedWarehouse || ''}__${invNameNorm}__${sizeNorm}`] ?? 0;
      const available = (edit.on_hand ?? 0) + (edit.on_order_from_supplier ?? 0) - (reservedFromOrders ?? 0);
      const onHand = Number(edit.on_hand ?? 0);
      if (onHand <= 0) {
        continue;
      }
      const cols = [
        `"${String(r.product_name ?? '').replace(/"/g, '""')}"`,
        `"${String(defaultLabel ?? '').replace(/"/g, '""')}"`,
        String(onHand),
        String(reservedFromOrders ?? 0),
        String(available),
        `"${String(whName).replace(/"/g, '""')}"`,
      ];
      lines.push(cols.join(','));
    }
    const csvContent = lines.join('\n');
    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    const fileSafeWh = whName || 'מחסן';
    link.setAttribute('download', `מלאי_${fileSafeWh}_${new Date().toLocaleDateString('he-IL')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  const groups = useMemo(() => {
    const map = new Map<string, InventoryRow[]>();
    const rows = (data ?? []);

    const filtered = !searchTerm
      ? rows
      : rows.filter((r) => {
          const q = searchTerm.trim().toLowerCase();
          const inProduct = r.product_name?.toLowerCase().includes(q);
          const inSize = (r.size_label ?? '').toLowerCase().includes(q);
          const dims = [r.width, r.height, r.length]
            .filter((v) => v !== null && v !== undefined)
            .map((v) => String(v))
            .join('x')
            .toLowerCase();
          const inDims = dims.includes(q);
          return inProduct || inSize || inDims;
        });

    // Category filtering (all levels)
    const selectedSet =
      selectedCategoryId && descendantsByCategoryId
        ? new Set<string>([selectedCategoryId, ...(Array.from(descendantsByCategoryId.get(selectedCategoryId) ?? []) as string[])])
        : null;
    const filteredByCategory = selectedSet
      ? filtered.filter((r) => {
          const catId = productCategoryIds?.[r.product_id] ?? null;
          return !!catId && selectedSet.has(catId);
        })
      : filtered;

    // Status filter by availability for selected warehouse
    const filteredByStatus = filteredByCategory.filter((r) => {
      if (statusFilter === 'all') return true;
      const defaultLabel =
        r.size_label
          ? r.size_label
          : [r.width, r.height, r.length].filter(Boolean).length > 0
            ? `${r.width ?? '-'}×${r.height ?? '-'}×${r.length ?? '-'}`
            : '-';
      const invNameNorm = normalizeText(r.product_name);
      const sizeNorm = normalizeSize(defaultLabel);
      const reservedFromOrders = reservedMap?.[`${selectedWarehouse || ''}__${invNameNorm}__${sizeNorm}`] ?? 0;
      const edit = edits[r.variant_id] ?? { on_hand: r.on_hand, on_order_from_supplier: r.on_order_from_supplier };
      const available = (edit.on_hand ?? 0) + (edit.on_order_from_supplier ?? 0) - (reservedFromOrders ?? 0);
      return statusFilter === 'in_stock' ? available > 0 : available < 0;
    });

    const filteredHidden = filteredByStatus.filter((r) => !hiddenVariants[r.variant_id]);

    filteredHidden.forEach((row) => {
      if (!map.has(row.product_name)) map.set(row.product_name, []);
      map.get(row.product_name)!.push(row);
    });
    // sort by product name and then size label
    const sorted = Array.from(map.entries())
      .sort(([a], [b]) => a.localeCompare(b, 'he'))
      .map(([product, rows]) => {
        const rowsSorted = [...rows].sort((r1, r2) => {
          const s1 = r1.size_label ?? '';
          const s2 = r2.size_label ?? '';
          return s1.localeCompare(s2, 'he');
        });
        return [product, rowsSorted] as [string, InventoryRow[]];
      });
    return sorted;
  }, [data, searchTerm, selectedCategoryId, descendantsByCategoryId, productCategoryIds, statusFilter, edits, reservedMap, selectedWarehouse, hiddenVariants, topParentNameByProductId]);

  // Flattened rows for table rendering (product name + row)
  const flatRows = useMemo(
    () =>
      groups.flatMap(([name, rows]) => {
        const filtered = rows.filter((r) => {
          // הסתר שורות עם 0 במלאי במחסן הנבחר. כאשר יתווסף בהמשך עם כמות > 0 — יופיע.
          if (!selectedWarehouse) return true;
          const qty = Number(edits[r.variant_id]?.on_hand ?? 0);
          return qty > 0;
        });
        return filtered.map((r) => ({ productName: name, row: r }));
      }),
    [groups, edits, selectedWarehouse]
  );

  // Add product CTA modals
  const [isAddChoiceOpen, setIsAddChoiceOpen] = useState(false);
  const [isAddExistingOpen, setIsAddExistingOpen] = useState(false);
  const [existingSearch, setExistingSearch] = useState('');
  const [selectedProductIdForExisting, setSelectedProductIdForExisting] = useState<string>('');
  const [selectedSizeForExisting, setSelectedSizeForExisting] = useState<{ width: number | null; height: number | null; length: number | null } | null>(null);
  const [existingQty, setExistingQty] = useState<number>(1);

  const allProductsForPicker = useMemo(() => {
    const map = new Map<string, { id: string; name: string; img?: string | null }>();
    for (const r of data ?? []) {
      if (!map.has(r.product_id)) {
        map.set(r.product_id, {
          id: r.product_id,
          name: r.product_name,
          img: productImages?.[r.product_id] ?? null,
        });
      }
    }
    const arr = Array.from(map.values());
    const term = existingSearch.trim().toLowerCase();
    return term ? arr.filter((p) => p.name.toLowerCase().includes(term)) : arr;
  }, [data, productImages, existingSearch]);

  const sizeOptionsForSelectedProduct = useMemo(() => {
    if (!selectedProductIdForExisting) return [];
    const options: { label: string; size: { width: number | null; height: number | null; length: number | null } }[] = [];
    const seen = new Set<string>();
    for (const r of data ?? []) {
      if (r.product_id !== selectedProductIdForExisting) continue;
      const label =
        r.size_label
          ? r.size_label
          : [r.width, r.height, r.length].filter(Boolean).length > 0
            ? `${r.width ?? '-'}×${r.height ?? '-'}×${r.length ?? '-'}`
            : '-';
      const key = `${r.width ?? ''}x${r.height ?? ''}x${r.length ?? ''}`;
      if (seen.has(key)) continue;
      seen.add(key);
      options.push({
        label,
        size: { width: r.width ?? null, height: r.height ?? null, length: r.length ?? null },
      });
    }
    return options;
  }, [data, selectedProductIdForExisting]);

  const addExistingMutation = useMutation({
    mutationFn: async (vars: { warehouseId: string; productId: string; size: { width: number | null; height: number | null; length: number | null }; quantity: number }) => {
      await upsertWarehouseInventoryQuantity(vars.warehouseId, vars.productId, vars.size, vars.quantity);
    },
    onSuccess: () => {
      toast.success('המוצר נוסף למלאי המחסן');
      queryClient.invalidateQueries({ queryKey: ['warehouse-inventory', selectedWarehouse] });
    },
    onError: (e: unknown) => {
      toast.error(e instanceof Error ? e.message : 'שגיאה בהוספת מוצר למחסן');
    },
  });

  return (
    <div className="container mx-auto px-4 py-8" dir="rtl">
      <ToastViewport toasts={toasts} onDismiss={dismissToast} />

      {/* Top header without white background */}
      <div className="mb-4 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between" dir="rtl">
        <div className="flex flex-col text-right">
          <h1 className="text-2xl font-bold">מלאי ומעקב הזמנות</h1>
          {selectedWarehouse && (
            <div className="mt-1 text-sm text-gray-600">
              מחסן נוכחי: <span className="font-medium">{selectedWarehouseName}</span>
            </div>
          )}
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 rounded-xl border px-3 py-2 shadow-sm bg-white">
            <Building2 className="h-4 w-4 text-gray-500" />
            <label className="text-sm text-gray-600">בחר מחסן:</label>
            <select
              className="rounded-md border border-gray-200 bg-white px-2 py-1.5 text-right text-sm hover:border-blue-300 focus:border-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-200"
              value={selectedWarehouse}
              onChange={(e) => setSelectedWarehouse(e.target.value)}
            >
              <option value="" disabled>בחר מחסן...</option>
              {(warehouses ?? []).map((w: Warehouse) => (
                <option key={w.id} value={w.id}>{w.name}</option>
              ))}
            </select>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsAddChoiceOpen(true)}
              className="inline-flex items-center gap-2 rounded-full bg-blue-600 px-5 py-2 text-sm font-bold text-white shadow-md shadow-blue-200 transition hover:bg-blue-700"
              title="הוסף מוצר חדש"
            >
              הוסף מוצר חדש
              <Plus className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={downloadWarehouseCsv}
              className="inline-flex items-center gap-2 rounded-full bg-white px-5 py-2 text-sm font-semibold text-slate-700 border border-gray-200 hover:bg-gray-50 transition shadow-sm disabled:cursor-not-allowed disabled:opacity-50"
              disabled={!selectedWarehouse || (data?.length ?? 0) === 0}
              title="ייצוא דוח CSV של המלאי למחסן הנבחר"
            >
              ייצוא דוח
              <Download className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* KPI cards on white cards */}
      <div className="mb-4">
        <Kpis
          selectedWarehouse={selectedWarehouse}
          reservedMap={reservedMap}
          data={data}
          edits={edits}
          warehouseInventory={warehouseInventory}
        />
      </div>

      {/* Add-choice modal */}
      {isAddChoiceOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4" dir="rtl">
          <div className="w-full max-w-md rounded-xl bg-white shadow-lg">
            <div className="flex items-center justify-between border-b px-4 py-3">
              <div className="text-right font-semibold">הוספת מוצר</div>
              <button onClick={() => setIsAddChoiceOpen(false)} className="text-gray-600 hover:text-gray-800" aria-label="סגור">✕</button>
            </div>
            <div className="p-4 space-y-3">
              <button
                type="button"
                className="w-full rounded-lg bg-blue-600 px-4 py-3 text-white font-bold hover:bg-blue-700"
                onClick={() => {
                  setIsAddChoiceOpen(false);
                  navigate('/products/add');
                }}
              >
                הוספת מוצר חדש למערכת
              </button>
              <button
                type="button"
                className="w-full rounded-lg border border-gray-300 bg-white px-4 py-3 text-gray-800 hover:bg-gray-50"
                onClick={() => {
                  if (!selectedWarehouse) {
                    try { toast.error('בחר מחסן קודם'); } catch {}
                    return;
                  }
                  setIsAddChoiceOpen(false);
                  setIsAddExistingOpen(true);
                }}
              >
                הוספת מוצר קיים למלאי
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add-existing-to-warehouse modal */}
      {isAddExistingOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4" dir="rtl">
          <div className="w-full max-w-2xl rounded-xl bg-white shadow-lg">
            <div className="flex items-center justify-between border-b px-4 py-3">
              <div className="text-right">
                <div className="text-sm text-gray-500">הוספת מוצר קיים למחסן</div>
                <div className="font-semibold">{selectedWarehouseName ? `מחסן: ${selectedWarehouseName}` : ''}</div>
              </div>
              <button onClick={() => setIsAddExistingOpen(false)} className="text-gray-600 hover:text-gray-800" aria-label="סגור">✕</button>
            </div>
            <div className="p-4 space-y-4">
              <div className="flex flex-col md:flex-row gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <input
                    type="text"
                    value={existingSearch}
                    onChange={(e) => setExistingSearch(e.target.value)}
                    placeholder="חיפוש מוצר לפי שם..."
                    className="w-full rounded-lg border border-gray-300 bg-white pl-9 pr-3 py-2 text-right text-sm placeholder:text-gray-400 focus:border-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-200"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="border rounded-lg overflow-hidden">
                  <div className="border-b bg-gray-50 px-3 py-2 text-sm font-medium">מוצרים</div>
                  <div className="max-h-72 overflow-y-auto">
                    {allProductsForPicker.map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => {
                          setSelectedProductIdForExisting(p.id);
                          setSelectedSizeForExisting(null);
                        }}
                        className={`w-full flex items-center gap-3 px-3 py-2 text-right hover:bg-gray-50 ${selectedProductIdForExisting === p.id ? 'bg-blue-50' : ''}`}
                      >
                        {p.img ? <img src={p.img} alt={p.name} className="h-8 w-8 rounded object-cover" /> : <div className="h-8 w-8 rounded bg-gray-100" />}
                        <div className="flex-1">{p.name}</div>
                      </button>
                    ))}
                    {allProductsForPicker.length === 0 && (
                      <div className="px-3 py-6 text-center text-gray-500 text-sm">לא נמצאו מוצרים</div>
                    )}
                  </div>
                </div>
                <div className="border rounded-lg overflow-hidden">
                  <div className="border-b bg-gray-50 px-3 py-2 text-sm font-medium">מידות וזמינות</div>
                  <div className="p-3 space-y-3">
                    {!selectedProductIdForExisting ? (
                      <div className="text-sm text-gray-500">בחר מוצר משמאל כדי לבחור מידה</div>
                    ) : sizeOptionsForSelectedProduct.length === 0 ? (
                      <div className="text-sm text-gray-500">לא נמצאו מידות למוצר זה</div>
                    ) : (
                      <>
                        <div className="space-y-2">
                          {sizeOptionsForSelectedProduct.map((opt, idx) => {
                            const key = `${opt.size.width ?? ''}x${opt.size.height ?? ''}x${opt.size.length ?? ''}`;
                            const selected =
                              selectedSizeForExisting &&
                              selectedSizeForExisting.width === opt.size.width &&
                              selectedSizeForExisting.height === opt.size.height &&
                              selectedSizeForExisting.length === opt.size.length;
                            return (
                              <label key={key} className={`flex items-center justify-between gap-3 rounded border px-3 py-2 ${selected ? 'border-blue-400 bg-blue-50' : 'border-gray-200 hover:bg-gray-50'}`}>
                                <input
                                  type="radio"
                                  name="size"
                                  checked={!!selected}
                                  onChange={() => setSelectedSizeForExisting(opt.size)}
                                />
                                <span className="flex-1 text-right text-sm">{opt.label}</span>
                              </label>
                            );
                          })}
                        </div>
                        <div className="flex items-center gap-2">
                          <label className="text-sm text-gray-600">כמות:</label>
                          <input
                            type="number"
                            min={0}
                            value={existingQty}
                            onChange={(e) => setExistingQty(Number(e.target.value || 0))}
                            className="w-28 rounded border px-2 py-1 text-right"
                          />
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
            <div className="flex justify-end gap-2 border-t px-4 py-3">
              <button
                type="button"
                className="rounded-lg border border-gray-300 px-4 py-2 text-sm text-gray-700 hover:bg-gray-50"
                onClick={() => setIsAddExistingOpen(false)}
              >
                ביטול
              </button>
              <button
                type="button"
                className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={
                  !selectedWarehouse ||
                  !selectedProductIdForExisting ||
                  !selectedSizeForExisting ||
                  existingQty <= 0 ||
                  addExistingMutation.isPending
                }
                onClick={() => {
                  if (!selectedWarehouse || !selectedProductIdForExisting || !selectedSizeForExisting) return;
                  addExistingMutation.mutate({
                    warehouseId: selectedWarehouse,
                    productId: selectedProductIdForExisting,
                    size: selectedSizeForExisting,
                    quantity: existingQty,
                  }, {
                    onSuccess: () => {
                      setIsAddExistingOpen(false);
                      setExistingSearch('');
                      setSelectedProductIdForExisting('');
                      setSelectedSizeForExisting(null);
                      setExistingQty(1);
                    },
                  });
                }}
              >
                הוסף למלאי
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Controls bar on white background; rest stays gray */}
      <div className="mb-6 flex flex-col md:flex-row gap-4 bg-white p-3 rounded-xl border border-gray-200 shadow-sm">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder='חיפוש לפי שם מוצר, מק"ט או קטגוריה...'
            className="w-full bg-gray-50 border-none rounded-lg pl-9 pr-3 py-2.5 text-right text-sm placeholder:text-gray-500 focus:ring-2 focus:ring-blue-600 text-gray-900"
            dir="rtl"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0">
          <button
            type="button"
            className="flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-600 border border-blue-100 rounded-lg whitespace-nowrap text-sm font-bold"
            title="אפשרויות סינון"
          >
            <Filter className="h-4 w-4" />
            סינון
          </button>
          <select
            className="bg-gray-50 border-none text-gray-700 rounded-lg px-4 py-2 pr-8 text-sm cursor-pointer focus:ring-0 hover:bg-gray-100 transition-colors"
            value={selectedCategoryId}
            onChange={(e) => setSelectedCategoryId(e.target.value)}
          >
            <option value="">כל הקטגוריות</option>
            {(allCategories ?? []).map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
          <select
            className="bg-gray-50 border-none text-gray-700 rounded-lg px-4 py-2 pr-8 text-sm cursor-pointer focus:ring-0 hover:bg-gray-100 transition-colors"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
          >
            <option value="all">כל הסטטוסים</option>
            <option value="in_stock">במלאי</option>
            <option value="out_of_stock">חסר</option>
          </select>
          <select
            className="bg-gray-50 border-none text-gray-700 rounded-lg px-4 py-2 pr-8 text-sm cursor-pointer focus:ring-0 hover:bg-gray-100 transition-colors"
            value={sortKey}
            onChange={(e) => setSortKey(e.target.value as any)}
          >
            <option value="name">סינון</option>
            <option value="available_desc">פנוי עכשיו (גבוה קודם)</option>
            <option value="on_hand_desc">יש עכשיו במלאי (גבוה קודם)</option>
            <option value="on_order_desc">הוזמן מהספק (גבוה קודם)</option>
          </select>
        </div>
      </div>

      {reservedPreview && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center px-4" dir="rtl">
          <div className="w-full max-w-2xl rounded-xl bg-white shadow-lg">
            <div className="flex items-center justify-between border-b px-4 py-3">
              <div className="text-right">
                <div className="text-sm text-gray-500">שמור ללקוחות עבור</div>
                <div className="font-semibold">{reservedPreview.name} — {reservedPreview.size}</div>
              </div>
              <button
                type="button"
                onClick={() => setReservedPreview(null)}
                className="text-gray-600 hover:text-gray-800"
                aria-label="סגור"
              >
                ✕
              </button>
            </div>
            <div className="p-4">
              {reservedLoading ? (
                <div className="py-8 text-center text-gray-600">טוען פרטים...</div>
              ) : !reservedDetails || reservedDetails.length === 0 ? (
                <div className="py-8 text-center text-gray-600">לא נמצאו פריטים שמורים</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full text-right">
                    <thead className="bg-gray-50 text-gray-700">
                      <tr>
                        <th className="px-3 py-2 text-sm font-medium">מס׳ הזמנה</th>
                        <th className="px-3 py-2 text-sm font-medium">לקוח</th>
                        <th className="px-3 py-2 text-sm font-medium">סטטוס</th>
                        <th className="px-3 py-2 text-sm font-medium">כמות</th>
                        <th className="px-3 py-2 text-sm font-medium">תאריך יצירה</th>
                        <th className="px-3 py-2 text-sm font-medium">תאריך יעד</th>
                        <th className="px-3 py-2 text-sm font-medium">סכום כולל</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {reservedDetails!.map((d) => (
                        <tr key={`${d.order_id}-${d.product_name}-${d.size}`}>
                          <td className="px-3 py-2 font-mono text-sm">#{d.order_id.slice(0, 8).toUpperCase()}</td>
                          <td className="px-3 py-2 text-sm">{d.customer_name ?? '—'}</td>
                          <td className="px-3 py-2 text-sm">{statusLabels[d.status] ?? d.status}</td>
                          <td className="px-3 py-2 text-sm">{d.qty}</td>
                          <td className="px-3 py-2 text-sm">{d.created_at ? new Date(d.created_at).toLocaleDateString('he-IL') : '—'}</td>
                          <td className="px-3 py-2 text-sm">{d.expected_delivery_date ? new Date(d.expected_delivery_date).toLocaleDateString('he-IL') : '—'}</td>
                          <td className="px-3 py-2 text-sm">{typeof d.total_amount === 'number' ? d.total_amount.toLocaleString('he-IL') : '—'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
            <div className="flex justify-end border-t px-4 py-3">
              <button
                type="button"
                onClick={() => setReservedPreview(null)}
                className="rounded-lg border border-gray-300 px-4 py-2 text-sm text-gray-700 hover:bg-gray-50"
              >
                סגור
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Filters + search now live inside the header card above */}

      {isLoading && (
        <div className="flex items-center justify-center py-16 text-gray-600">טוען נתונים...</div>
      )}

      {isError && (
        <div className="rounded-md border border-red-300 bg-red-50 p-4 text-right text-red-800">
          שגיאה בטעינת הנתונים
          <div className="mt-2 text-xs opacity-70">{(error as Error)?.message}</div>
        </div>
      )}

      {!isLoading && !isError && groups.length === 0 && (
        <div className="rounded-md border bg-white p-6 text-center text-gray-600">אין נתונים להצגה</div>
      )}

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="min-w-full text-right border-collapse">
            <thead className="bg-gray-50 text-gray-700">
              <tr>
                <th className="px-4 py-2 font-medium">תמונה</th>
                <th className="px-4 py-2 font-medium">מוצר</th>
                <th className="px-4 py-2 font-medium">יש עכשיו במלאי</th>
                <th className="px-4 py-2 font-medium">הוזמן מהספק</th>
                <th className="px-4 py-2 font-medium">שמור ללקוחות</th>
                <th className="px-4 py-2 font-medium">פנוי עכשיו</th>
                <th className="px-4 py-2 font-medium">סטטוס</th>
                <th className="px-4 py-2 font-medium">פעולות</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {flatRows
                .sort((a, b) => {
                  if (sortKey === 'name') return a.productName.localeCompare(b.productName, 'he');
                  const getVals = (x: typeof a) => {
                    const r = x.row;
                    const edit = edits[r.variant_id] ?? {
                      on_hand: r.on_hand,
                      on_order_from_supplier: r.on_order_from_supplier,
                    };
                    const defaultLabel =
                      r.size_label
                        ? r.size_label
                        : [r.width, r.height, r.length].filter(Boolean).length > 0
                          ? `${r.width ?? '-'}×${r.height ?? '-'}×${r.length ?? '-'}`
                          : '-';
                    const invNameNorm = normalizeText(r.product_name);
                    const sizeNorm = normalizeSize(defaultLabel);
                    const reservedFromOrders = reservedMap?.[`${selectedWarehouse || ''}__${invNameNorm}__${sizeNorm}`] ?? 0;
                    const available = (edit.on_hand ?? 0) + (edit.on_order_from_supplier ?? 0) - (reservedFromOrders ?? 0);
                    return {
                      available,
                      on_hand: edit.on_hand ?? 0,
                      on_order_from_supplier: edit.on_order_from_supplier ?? 0,
                    };
                  };
                  const av = getVals(a);
                  const bv = getVals(b);
                  if (sortKey === 'available_desc') return bv.available - av.available;
                  if (sortKey === 'on_hand_desc') return (bv.on_hand) - (av.on_hand);
                  if (sortKey === 'on_order_desc') return (bv.on_order_from_supplier) - (av.on_order_from_supplier);
                  return 0;
                })
                .map(({ productName, row: r }) => {
                      const edit = edits[r.variant_id] ?? {
                        on_hand: r.on_hand,
                        on_order_from_supplier: r.on_order_from_supplier,
                      };
                      const pid = r.product_id;
                      const rowImg = pid ? productImages?.[pid] : undefined;
                      const defaultLabel = r.size_label
                        ? r.size_label
                        : [r.width, r.height, r.length].filter(Boolean).length > 0
                          ? `${r.width ?? '-'} × ${r.height ?? '-'} × ${r.length ?? '-'}`
                          : '-';
                      const displayLabel = customSizeLabels[r.variant_id] ?? defaultLabel;

                      const invNameNorm = normalizeText(r.product_name);
                      const sizeNorm = normalizeSize(defaultLabel);
                      // חישוב שמורים לפי המחסן הנבחר בלבד
                      const reservedFromOrders = reservedMap?.[`${selectedWarehouse || ''}__${invNameNorm}__${sizeNorm}`] ?? 0;
                      const available = (edit.on_hand ?? 0) + (edit.on_order_from_supplier ?? 0) - (reservedFromOrders ?? 0);
                      const availableClass =
                        available < 0
                          ? 'text-red-600 font-semibold'
                          : available === 0
                          ? 'text-orange-500 font-semibold'
                          : 'text-green-600 font-semibold';
                      const statusBadge =
                        available < 0
                          ? <span className="rounded-full bg-red-50 px-2 py-0.5 text-xs font-medium text-red-700 border border-red-200">חסר</span>
                          : <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-xs font-medium text-emerald-700 border border-emerald-200">במלאי</span>;

                      return (
                        <tr key={r.variant_id} className="hover:bg-gray-50">
                          <td className="px-4 py-3">
                            {rowImg ? (
                              <img
                                src={rowImg}
                                alt={productName}
                                className="h-10 w-10 rounded object-cover"
                              />
                            ) : (
                              <div className="h-10 w-10 rounded bg-gray-100" />
                            )}
                          </td>
                          <td className="px-4 py-3 text-sm text-gray-900 font-medium text-left">
                            <div className="flex flex-col items-start">
                              <span className="text-left">{productName}</span>
                              <div className="mt-1 text-xs text-gray-700 text-left">
                                {editingSizeFor === r.variant_id ? (
                                  <div className="flex items-center gap-2">
                                    <input
                                      type="text"
                                      className="w-40 rounded border px-2 py-1 text-right"
                                      value={editingSizeValue}
                                      onChange={(e) => setEditingSizeValue(e.target.value)}
                                      onKeyDown={(e) => {
                                        if (e.key === 'Enter') {
                                          setCustomSizeLabels((prev) => ({ ...prev, [r.variant_id]: editingSizeValue.trim() }));
                                          setEditingSizeFor(null);
                                        } else if (e.key === 'Escape') {
                                          setEditingSizeFor(null);
                                        }
                                      }}
                                    />
                                    <button
                                      type="button"
                                      className="text-green-600 text-xs"
                                      onClick={() => {
                                        setCustomSizeLabels((prev) => ({ ...prev, [r.variant_id]: editingSizeValue.trim() }));
                                        setEditingSizeFor(null);
                                      }}
                                    >
                                      שמור
                                    </button>
                                    <button
                                      type="button"
                                      className="text-gray-600 text-xs"
                                      onClick={() => setEditingSizeFor(null)}
                                    >
                                      בטל
                                    </button>
                                  </div>
                                ) : (
                                  <div className="flex items-center gap-2 justify-start">
                                    <span title="המידה כאן היא לנראות בלבד בעמוד המלאי">{displayLabel}</span>
                                    {customSizeLabels[r.variant_id] !== undefined && (
                                      <span className="text-[10px] rounded-full border px-2 py-0.5 text-gray-600 border-gray-300">
                                        תצוגה בלבד
                                      </span>
                                    )}
                                    <button
                                      type="button"
                                      className="text-gray-500 hover:text-blue-600 text-[11px] underline"
                                      onClick={() => {
                                        setEditingSizeFor(r.variant_id);
                                        setEditingSizeValue(displayLabel);
                                      }}
                                      title="ערוך מידה לתצוגה"
                                    >
                                      ערוך
                                    </button>
                                    {customSizeLabels[r.variant_id] !== undefined && (
                                      <button
                                        type="button"
                                        className="text-gray-500 hover:text-blue-600 text-[11px] underline"
                                        onClick={() => {
                                          setCustomSizeLabels((prev) => {
                                            const next = { ...prev };
                                            delete next[r.variant_id];
                                            return next;
                                          });
                                        }}
                                        title="איפוס תצוגת מידה לברירת מחדל"
                                      >
                                        אפס
                                      </button>
                                    )}
                                  </div>
                                )}
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-3">
                            <input
                              type="number"
                              inputMode="numeric"
                              className="w-28 rounded border px-2 py-1 text-right"
                              placeholder="הכנס כמות..."
                              value={Number.isFinite(edit.on_hand) ? edit.on_hand : 0}
                              onChange={(e) => handleChangeOnHand(r, Number(e.target.value || 0))}
                              onBlur={() => flushImmediateOnHand(r)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  e.currentTarget.blur();
                                }
                              }}
                            />
                          </td>
                          <td className="px-4 py-3">
                            <input
                              type="number"
                              inputMode="numeric"
                              className="w-28 rounded border px-2 py-1 text-right"
                              placeholder="הכנס כמות..."
                              value={
                                Number.isFinite(edit.on_order_from_supplier) ? edit.on_order_from_supplier : 0
                              }
                              onChange={(e) =>
                                handleChange(
                                  r.variant_id,
                                  'on_order_from_supplier',
                                  Number(e.target.value || 0)
                                )
                              }
                              onBlur={() => flushImmediate(r.variant_id, 'on_order_from_supplier')}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  e.currentTarget.blur();
                                }
                              }}
                            />
                          </td>
                          <td className="px-4 py-3 text-gray-700">
                            {reservedFromOrders > 0 ? (
                              <button
                                type="button"
                                className="underline text-blue-700 hover:text-blue-800"
                                onClick={() => setReservedPreview({ name: r.product_name, size: defaultLabel })}
                                title="ראה פרטי שמור ללקוחות"
                              >
                                {reservedFromOrders}
                              </button>
                            ) : (
                              <span>{reservedFromOrders ?? 0}</span>
                            )}
                          </td>
                          <td className={`px-4 py-3 ${availableClass}`}>{available}</td>
                          <td className="px-4 py-3">
                            {statusBadge}
                          </td>
                          <td className="px-4 py-3 text-sm">
                            <button
                              type="button"
                              onClick={() => deleteFromWarehouse(r)}
                              className="text-red-600 hover:text-red-700 p-1.5 rounded-lg hover:bg-red-50 transition-colors"
                              title="מחק מהמלאי במחסן הנוכחי (יאפס כמות)"
                              aria-label="מחק מהמלאי"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </td>
                        </tr>
                      );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// Modal for reserved details is appended at bottom of the component render

// KPI cards component
function Kpis({
  selectedWarehouse,
  reservedMap,
  data,
  edits,
  warehouseInventory,
}: {
  selectedWarehouse: string;
  reservedMap?: Record<string, number>;
  data?: InventoryRow[];
  edits: Record<string, { on_hand?: number | undefined; on_order_from_supplier?: number | undefined }>;
  warehouseInventory?: { quantity: number }[] | undefined;
}) {
  const totalOnHand = useMemo(() => {
    return (warehouseInventory ?? []).reduce((sum, r) => sum + (Number((r as any).quantity) || 0), 0);
  }, [warehouseInventory]);

  const totalReserved = useMemo(() => {
    if (!reservedMap || !selectedWarehouse) return 0;
    const prefix = `${selectedWarehouse}__`;
    let total = 0;
    for (const [k, v] of Object.entries(reservedMap)) {
      if (k.startsWith(prefix)) total += Number(v) || 0;
    }
    return total;
  }, [reservedMap, selectedWarehouse]);

  const alertsCount = useMemo(() => {
    if (!data) return 0;
    let count = 0;
    for (const r of data) {
      const edit = edits[r.variant_id] ?? {
        on_hand: r.on_hand,
        on_order_from_supplier: r.on_order_from_supplier,
      };
      const onHandInSelectedWarehouse = Number(edit.on_hand ?? 0);
      const defaultLabel =
        r.size_label
          ? r.size_label
          : [r.width, r.height, r.length].filter(Boolean).length > 0
            ? `${r.width ?? '-'}×${r.height ?? '-'}×${r.length ?? '-'}`
            : '-';
      const invNameNorm = normalizeText(r.product_name);
      const sizeNorm = normalizeSize(defaultLabel);
      const reservedFromOrders = reservedMap?.[`${selectedWarehouse || ''}__${invNameNorm}__${sizeNorm}`] ?? 0;
      const available = (edit.on_hand ?? 0) + (edit.on_order_from_supplier ?? 0) - (reservedFromOrders ?? 0);
      // Count only items that actually exist in this warehouse (>0 on_hand) and are low-stock (<2 available)
      if (onHandInSelectedWarehouse > 0 && available < 2) count++;
    }
    return count;
  }, [data, edits, reservedMap, selectedWarehouse]);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex flex-col gap-4 relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-32 h-32 bg-blue-50 rounded-full -mr-10 -mt-10 transition-transform group-hover:scale-110" />
        <div className="flex justify-between items-start z-10">
          <div className="text-right">
            <p className="text-gray-500 text-sm font-medium">סך פריטים במלאי</p>
            <h3 className="text-4xl font-bold mt-1 text-slate-900">{totalOnHand.toLocaleString('he-IL')}</h3>
          </div>
          <div className="bg-blue-50 p-2 rounded-lg text-blue-600">
            <Boxes className="h-6 w-6" />
          </div>
        </div>
        <div className="flex items-center gap-2 text-sm z-10 justify-end">
          <span className="flex items-center text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded-md">
            <TrendingUp className="h-4 w-4 mr-1" />
            12%
          </span>
          <span className="text-gray-400">מהחודש שעבר</span>
        </div>
      </div>
      <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex flex-col gap-4 relative overflow-hidden group">
        <div className="flex justify-between items-start z-10">
          <div className="text-right">
            <p className="text-gray-500 text-sm font-medium">הזמנות פתוחות לטיפול</p>
            <h3 className="text-4xl font-bold mt-1 text-slate-900">{totalReserved}</h3>
          </div>
          <div className="bg-indigo-50 p-2 rounded-lg text-indigo-500">
            <ClipboardList className="h-6 w-6" />
          </div>
        </div>
        <div className="flex items-center gap-2 text-sm z-10 justify-end">
          <span className="flex items-center text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded-md">
            <TrendingUp className="h-4 w-4 mr-1" />
            5%
          </span>
          <span className="text-gray-400">מהשבוע האחרון</span>
        </div>
      </div>
      <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex flex-col gap-4 relative overflow-hidden group">
        <div className="flex justify-between items-start z-10">
          <div className="text-right">
            <p className="text-gray-500 text-sm font-medium">התראות מלאי נמוך</p>
            <h3 className="text-4xl font-bold mt-1 text-slate-900">{alertsCount}</h3>
          </div>
          <div className="bg-orange-50 p-2 rounded-lg text-orange-500">
            <AlertTriangle className="h-6 w-6" />
          </div>
        </div>
        <div className="flex items-center gap-2 text-sm z-10 justify-end">
          <span className="flex items-center text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded-md">
            <TrendingDown className="h-4 w-4 mr-1" />
            -2%
          </span>
          <span className="text-gray-400">שיפור מהחודש שעבר</span>
        </div>
      </div>
    </div>
  );
}
