import React, { useEffect, useMemo, useState } from 'react';
import { supabase } from '../lib/supabase';
import AddLeadModal from '../components/AddLeadModal';
import EditLeadModal from '../components/EditLeadModal';
import { Pencil, Trash2, MessageCircle } from 'lucide-react';
import { PlusCircle } from 'lucide-react';

type Lead = {
  id: string;
  created_at: string;
  customer_name: string | null;
  business_name: string | null;
  city: string | null;
  phone: string | null;
  inquiry_date: string | null; // ISO date string
  status: string | null;
  call_summary: string | null;
  is_new?: boolean | null;
  created_via?: string | null;
};

const statusOptions = ['חדש', 'בתהליך', 'הושלם', 'לא רלוונטי'];

export default function LeadsPage() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [editingLead, setEditingLead] = useState<Lead | null>(null);

  const loadLeads = async () => {
    setLoading(true);
    setError(null);
    const { data, error } = await (supabase as any)
      .from('leads')
      .select('*')
      .order('created_at', { ascending: false })
      .order('id', { ascending: false });
    if (error) {
      setError(error.message);
    } else {
      setLeads((data as unknown as Lead[]) || []);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadLeads();
    // Mark page viewed to reset sidebar badge
    localStorage.setItem('leads_last_viewed_at', String(Date.now()));
    const channel = supabase
      .channel('leads-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'leads' }, () => {
        loadLeads();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const filteredLeads = useMemo(() => {
    const term = search.trim().toLowerCase();
    return leads.filter((l) => {
      const textMatch = !term
        || [l.customer_name, l.business_name, l.city, l.phone, l.call_summary]
          .filter(Boolean)
          .some((v) => String(v).toLowerCase().includes(term));
      const statusMatch = !statusFilter || (l.status || '') === statusFilter;
      return textMatch && statusMatch;
    });
  }, [leads, search, statusFilter]);

  // Compute unseen ids based on last view timestamp (for row badges)
  const lastViewedAt = Number(localStorage.getItem('leads_last_viewed_at') || '0');
  const unseenIdSet = useMemo(() => {
    // Prefer is_new flag from DB when available; fallback to timestamp logic
    const ids = new Set<string>();
    for (const l of leads) {
      if (typeof l.is_new === 'boolean') {
        if (l.is_new) ids.add(l.id);
      } else {
        const created = l.created_at ? new Date(l.created_at).getTime() : 0;
        if (lastViewedAt && created > lastViewedAt) ids.add(l.id);
      }
    }
    return ids;
  }, [leads, lastViewedAt]);

  const updateLead = async (id: string, patch: Partial<Lead>) => {
    const prev = leads;
    setLeads((curr) => curr.map((l) => (l.id === id ? { ...l, ...patch } : l)));
    const { error } = await (supabase as any).from('leads').update(patch).eq('id', id);
    if (error) {
      setLeads(prev);
      alert('שמירה נכשלה: ' + error.message);
    }
  };

  const openAdd = () => setShowAddModal(true);
  const onAdded = () => loadLeads();
  const openEdit = (lead: Lead) => setEditingLead(lead);
  const closeEdit = () => setEditingLead(null);
  const onEdited = () => loadLeads();
  const removeLead = async (id: string) => {
    if (!confirm('למחוק את הליד הזה?')) return;
    const previous = leads;
    setLeads((curr) => curr.filter((l) => l.id !== id));
    const { error } = await (supabase as any).from('leads').delete().eq('id', id);
    if (error) {
      // Rollback UI and report
      setLeads(previous);
      alert('מחיקה נכשלה: ' + error.message);
      return;
    }
    // Safety refresh in case realtime is off
    // loadLeads();
  };

  const openWhatsApp = (phone: string | null) => {
    if (!phone || !phone.trim()) {
      alert('אין מספר טלפון לליד זה');
      return;
    }

    // Format phone number (remove all non-numeric characters)
    const cleanPhone = phone.replace(/\D/g, '');
    
    // If starts with 0, remove it and add 972, otherwise add 972 if not already present
    let phoneWithCountryCode: string;
    if (cleanPhone.startsWith('972')) {
      phoneWithCountryCode = cleanPhone;
    } else if (cleanPhone.startsWith('0')) {
      phoneWithCountryCode = '972' + cleanPhone.substring(1);
    } else {
      phoneWithCountryCode = '972' + cleanPhone;
    }

    // Pre-filled message
    const message = 'היי זה אדיר מקירור דן, ראינו שהשארת לנו פנייה בקשר למקררים/מקפיאים ולא הצלחנו לתפוס אותך, נשמח שתחזור אלינו בזמנך הפנוי';
    
    // Use web.whatsapp.com for better compatibility with desktop
    const whatsappUrl = `https://web.whatsapp.com/send?phone=${phoneWithCountryCode}&text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">לידים</h1>

      <div className="flex flex-col gap-2 md:flex-row md:items-center md:gap-2">
        <input
          className="border rounded-md px-3 py-2 w-full md:flex-1 md:w-auto"
          placeholder="חיפוש לפי שם, עסק, עיר, טלפון או סיכום"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select
          className="border rounded-md px-3 py-2 w-full md:w-48 md:shrink-0"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option value="">כל הסטטוסים</option>
          {statusOptions.map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
        <button
          className="bg-blue-600 text-white rounded-md px-4 py-2 md:shrink-0"
          onClick={loadLeads}
        >
          רענן
        </button>
        <button
          type="button"
          onClick={openAdd}
          className="bg-green-600 text-white rounded-md px-4 py-2 md:shrink-0"
        >
          הוסף ליד
        </button>
      </div>

      {loading ? (
        <div>טוען...</div>
      ) : error ? (
        <div className="text-red-600">שגיאה: {error}</div>
      ) : (
        <div className="max-h-[70vh] overflow-auto rounded-xl bg-white shadow-sm ring-1 ring-gray-200">
          <table className="min-w-full text-right text-sm">
            <thead className="bg-gray-100 sticky top-0 z-10">
              <tr className="text-gray-700">
                <th className="px-4 py-3 font-medium">שם לקוח</th>
                <th className="px-4 py-3 font-medium">שם עסק</th>
                <th className="px-4 py-3 font-medium">עיר מגורים</th>
                <th className="px-4 py-3 font-medium">מספר פלאפון</th>
                <th className="px-4 py-3 font-medium">תאריך פנייה</th>
                <th className="px-4 py-3 font-medium">סטטוס</th>
                <th className="px-4 py-3 font-medium">סיכום שיחה</th>
                <th className="px-4 py-3 font-medium">פעולות</th>
              </tr>
            </thead>
            <tbody>
              {filteredLeads.map((lead) => (
                <tr key={lead.id} className="border-t odd:bg-white even:bg-gray-50 hover:bg-blue-50/40 transition-colors">
                  <td className="px-4 py-3 whitespace-nowrap">{lead.customer_name || ''}</td>
                  <td className="px-4 py-3 whitespace-nowrap">{lead.business_name || ''}</td>
                  <td className="px-4 py-3 whitespace-nowrap">{lead.city || ''}</td>
                  <td className="px-4 py-3 whitespace-nowrap" dir="ltr">{lead.phone || ''}</td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    {lead.inquiry_date ? new Date(lead.inquiry_date).toLocaleDateString('he-IL') : ''}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <select
                      className="border rounded-md px-2 py-1 text-sm bg-white"
                      value={lead.status || ''}
                      onChange={(e) => updateLead(lead.id, { status: e.target.value })}
                    >
                      <option value=""></option>
                      {statusOptions.map((s) => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-3 align-top">
                    <textarea
                      className="border rounded-md px-2 py-1 w-72 md:w-96 min-h-[44px] text-sm bg-white"
                      value={lead.call_summary || ''}
                      onChange={(e) => updateLead(lead.id, { call_summary: e.target.value })}
                      placeholder="סיכום שיחה"
                    />
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      {unseenIdSet.has(lead.id) && (
                        <span className="inline-block w-2.5 h-2.5 rounded-full bg-red-600" title="חדש" />
                      )}
                      <button
                        type="button"
                        aria-label="וואטסאפ"
                        className="p-2 rounded hover:bg-green-50 text-green-600"
                        onClick={() => openWhatsApp(lead.phone)}
                        title="וואטסאפ"
                      >
                        <MessageCircle className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        aria-label="עריכה"
                        className="p-2 rounded hover:bg-blue-50 text-blue-600"
                        onClick={async () => {
                          // Mark as seen when clicking edit on a new row
                          if (unseenIdSet.has(lead.id) || lead.is_new) {
                            await (supabase as any).from('leads').update({ is_new: false }).eq('id', lead.id);
                          }
                          openEdit(lead);
                        }}
                        title="עריכה"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        aria-label="מחיקה"
                        className="p-2 rounded hover:bg-red-50 text-red-600"
                        onClick={() => removeLead(lead.id)}
                        title="מחיקה"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {/* Inline new lead row */}
              <InlineNewLeadRow onCreated={onAdded} />
              {filteredLeads.length === 0 && (
                <tr>
                  <td className="px-4 py-6 text-center text-gray-500" colSpan={8}>
                    אין נתונים
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
      {showAddModal && (
        <AddLeadModal onClose={() => setShowAddModal(false)} onAdded={onAdded} />
      )}
      {editingLead && (
        <EditLeadModal lead={editingLead} onClose={() => setEditingLead(null)} onEdited={onAdded} />
      )}
    </div>
  );
}

function InlineNewLeadRow({ onCreated }: { onCreated: () => void }) {
  const today = new Date().toISOString().slice(0, 10);
  const [form, setForm] = useState({
    customer_name: '',
    business_name: '',
    city: '',
    phone: '',
    inquiry_date: today,
    status: 'חדש',
    call_summary: '',
  });
  const [saving, setSaving] = useState(false);
  const save = async () => {
    if (!form.customer_name && !form.business_name) return;
    if (!form.phone) return;
    setSaving(true);
    const { error } = await (supabase as any)
      .from('leads')
      .insert({
        customer_name: form.customer_name || null,
        business_name: form.business_name || null,
        city: form.city || null,
        phone: form.phone || null,
        inquiry_date: form.inquiry_date,
        status: form.status,
        call_summary: form.call_summary || null,
      });
    setSaving(false);
    if (!error) {
      setForm({
        customer_name: '',
        business_name: '',
        city: '',
        phone: '',
        inquiry_date: today,
        status: 'חדש',
        call_summary: '',
      });
      onCreated();
    } else {
      alert('שגיאה בשמירה: ' + error.message);
    }
  };

  return (
    <tr className="border-t bg-gray-50">
      <td className="px-4 py-2"><input className="border rounded-md px-2 py-1 w-40" placeholder="שם לקוח" value={form.customer_name} onChange={(e) => setForm((v) => ({ ...v, customer_name: e.target.value }))} /></td>
      <td className="px-4 py-2"><input className="border rounded-md px-2 py-1 w-40" placeholder="שם עסק" value={form.business_name} onChange={(e) => setForm((v) => ({ ...v, business_name: e.target.value }))} /></td>
      <td className="px-4 py-2"><input className="border rounded-md px-2 py-1 w-32" placeholder="עיר" value={form.city} onChange={(e) => setForm((v) => ({ ...v, city: e.target.value }))} /></td>
      <td className="px-4 py-2"><input className="border rounded-md px-2 py-1 w-36" placeholder="פלאפון" value={form.phone} onChange={(e) => setForm((v) => ({ ...v, phone: e.target.value }))} /></td>
      <td className="px-4 py-2"><input type="date" className="border rounded-md px-2 py-1" value={form.inquiry_date} onChange={(e) => setForm((v) => ({ ...v, inquiry_date: e.target.value }))} /></td>
      <td className="px-4 py-2">
        <select className="border rounded-md px-2 py-1" value={form.status} onChange={(e) => setForm((v) => ({ ...v, status: e.target.value }))}>
          {statusOptions.map((s) => (<option key={s} value={s}>{s}</option>))}
        </select>
      </td>
      <td className="px-4 py-2"><input className="border rounded-md px-2 py-1 w-72" placeholder="סיכום" value={form.call_summary} onChange={(e) => setForm((v) => ({ ...v, call_summary: e.target.value }))} /></td>
      <td className="px-4 py-2 whitespace-nowrap">
        <button type="button" title="הוסף" className="p-2 rounded bg-green-600 text-white disabled:opacity-50" onClick={save} disabled={saving}>
          <PlusCircle className="w-4 h-4" />
        </button>
      </td>
    </tr>
  );
}


