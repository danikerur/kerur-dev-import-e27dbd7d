import { headerBase64 } from '../assets/headerBase64';
import { footerBase64 } from '../assets/footerBase64';
import { middleGraphicBase64 } from '../assets/middleGraphicBase64';
import html2pdf from 'html2pdf.js';
import { useState } from 'react';

interface CustomerDetails {
  name: string;
  phone: string;
  email: string;
  address: string;
}

interface QuoteItem {
  product?: {
    name: string;
    image_url?: string;
  };
  dimension?: {
    name: string;
    length: number;
    depth?: number;
    width?: number;
    height: number;
  };
  text?: string;
  quantity: number;
  price: number;
  total: number;
}

const QuickQuotePage = () => {
  const [customerDetails, setCustomerDetails] = useState<CustomerDetails>({
    name: '',
    phone: '',
    email: '',
    address: ''
  });

  const [quoteItems, setQuoteItems] = useState<QuoteItem[]>([]);
  const [subtotal, setSubtotal] = useState(0);
  const [vat, setVat] = useState(0);
  const [total, setTotal] = useState(0);

  const generatePDF = async () => {
    const element = document.getElementById('quote-pdf');
    if (!element) return;

    // Show the element temporarily for PDF generation
    element.style.display = 'block';
    element.style.position = 'absolute';
    element.style.left = '-9999px';

    const opt = {
      margin: 0,
      filename: 'הצעת_מחיר.pdf',
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { 
        scale: 2,
        useCORS: true,
        logging: true,
        letterRendering: true
      },
      jsPDF: { 
        unit: 'mm', 
        format: 'a4', 
        orientation: 'portrait',
        compress: true
      },
      pagebreak: { mode: ['avoid-all', 'css', 'legacy'] }
    };

    try {
      await html2pdf().set(opt).from(element).save();
    } catch (error) {
      console.error('Error generating PDF:', error);
    } finally {
      // Hide the element after PDF generation
      element.style.display = 'none';
      element.style.position = 'static';
      element.style.left = 'auto';
    }
  };

  return (
    <div className="p-4 max-w-7xl mx-auto">
      {/* ... existing code ... */}

      {/* Hidden div for PDF generation */}
      <div
        id="quote-pdf"
        style={{
          display: 'none',
          fontFamily: "'Heebo', sans-serif",
          direction: 'rtl',
          background: '#fff',
          position: 'relative',
          width: '210mm',
          minHeight: '297mm',
          paddingTop: '0', // אין צורך ברווח ל-header
          paddingBottom: '90px', // Space for footer
          boxSizing: 'border-box',
        }}
      >
        {/* Header graphic - img רגיל בראש הדף */}
        <img
          src={middleGraphicBase64}
          alt="Header Graphic"
          style={{
            width: '100%',
            height: '80px',
            objectFit: 'cover',
            marginBottom: '16px',
            display: 'block',
          }}
        />

        {/* Quote content */}
        <div className="p-8">
          <h1 className="text-3xl font-bold mb-8 text-center">הצעת מחיר</h1>
          
          {/* Customer details */}
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4">פרטי לקוח</h2>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="font-medium">שם:</p>
                <p>{customerDetails.name}</p>
              </div>
              <div>
                <p className="font-medium">טלפון:</p>
                <p>{customerDetails.phone}</p>
              </div>
              <div>
                <p className="font-medium">אימייל:</p>
                <p>{customerDetails.email}</p>
              </div>
              <div>
                <p className="font-medium">כתובת:</p>
                <p>{customerDetails.address}</p>
              </div>
            </div>
          </div>

          {/* Products table */}
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4">פרטי הזמנה</h2>
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border p-2">מוצר</th>
                  <th className="border p-2">מידה</th>
                  <th className="border p-2">כמות</th>
                  <th className="border p-2">מחיר ליחידה</th>
                  <th className="border p-2">סה"כ</th>
                </tr>
              </thead>
              <tbody>
                {quoteItems.map((item, index) => (
                  <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="border p-2">
                      <div className="flex items-center gap-2">
                        {item.product?.image_url ? (
                          <img
                            src={item.product.image_url}
                            alt={item.product.name || 'תמונת מוצר'}
                            className="w-12 h-12 object-cover rounded"
                            style={{ border: '1px solid #eee', background: '#fff' }}
                            onError={e => { e.currentTarget.style.display = 'none'; }}
                          />
                        ) : (
                          <span className="text-xs text-gray-400">ללא תמונת מוצר</span>
                        )}
                        <span>{item.product?.name || item.text}</span>
                      </div>
                    </td>
                                         <td className="border p-2">
                      {(() => {
                        if (item.dimension) {
                          console.log('QuickQuote Dimension object:', item.dimension);
                          console.log('QuickQuote Height:', item.dimension.height, 'Length:', item.dimension.length, 'Width:', item.dimension.width);
                        }
                        return null;
                      })()}
                      {item.dimension ? `${item.dimension.height}×${item.dimension.length}×${item.dimension.width}` : '-'}
                    </td>
                    <td className="border p-2">{item.quantity}</td>
                    <td className="border p-2">₪{item.price.toFixed(2)}</td>
                    <td className="border p-2">₪{item.total.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-gray-100 font-bold">
                  <td colSpan={4} className="border p-2 text-left">סה"כ לפני מע"מ:</td>
                  <td className="border p-2">₪{subtotal.toFixed(2)}</td>
                </tr>
                <tr className="bg-gray-100 font-bold">
                  <td colSpan={4} className="border p-2 text-left">מע"מ (18%):</td>
                  <td className="border p-2">₪{vat.toFixed(2)}</td>
                </tr>
                <tr className="bg-gray-100 font-bold text-lg">
                  <td colSpan={4} className="border p-2 text-left">סה"כ לתשלום:</td>
                  <td className="border p-2">₪{total.toFixed(2)}</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        {/* Footer graphic */}
        <img
          src={footerBase64}
          alt="Footer"
          style={{
            position: 'absolute',
            bottom: 0,
            right: 0,
            width: '100%',
            height: '80px',
            objectFit: 'cover',
            zIndex: 1,
            pointerEvents: 'none',
            userSelect: 'none',
          }}
        />
      </div>
    </div>
  );
};

export default QuickQuotePage; 