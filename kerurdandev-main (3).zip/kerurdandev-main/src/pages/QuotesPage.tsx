import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Edit, Trash2, Download } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface QuoteRow {
  id: string;
  client_name: string;
  client_phone: string;
  client_address: string;
  created_at: string;
  total: number;
  pdf_url?: string;
  quote_number?: string;
}

export function QuotesPage() {
  const [quotes, setQuotes] = useState<QuoteRow[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const [selectedQuotes, setSelectedQuotes] = useState<string[]>([]);
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');

  useEffect(() => {
    fetchQuotes();
  }, []);

  async function fetchQuotes() {
    setLoading(true);
    const { data, error } = await supabase
      .from('quick_quotes')
      .select('id, client_name, client_phone, client_address, created_at, pdf_url, quote_number')
      .order('created_at', { ascending: false });
    if (!error && data) {
      // For each quote, fetch the sum of total_price from quick_quote_products
      const quotesWithTotal = await Promise.all(
        data.map(async (q: any) => {
          const { data: products, error: prodError } = await supabase
            .from('quick_quote_products')
            .select('total_price')
            .eq('quote_id', q.id);
          let total = 0;
          if (!prodError && products) {
            total = products.reduce((sum: number, p: any) => sum + (Number(p.total_price) || 0), 0);
          }
          return { ...q, total };
        })
      );
      setQuotes(quotesWithTotal as QuoteRow[]);
    }
    setLoading(false);
  }

  const handleDownload = async (url?: string, filename?: string) => {
    if (!url) {
      alert('לא נמצא קובץ PDF להצעה זו');
      return;
    }
    try {
      const response = await fetch(url);
      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = filename || 'quote.pdf';
      a.click();
      window.URL.revokeObjectURL(blobUrl);
    } catch (err) {
      console.error('שגיאה בהורדת הקובץ:', err);
      alert('לא ניתן להוריד את הקובץ');
    }
  };

  const handleDeleteQuote = async (quoteId: string) => {
    if (!window.confirm('האם למחוק הצעה זו?')) return;
    const { error } = await supabase
      .from('quick_quotes')
      .delete()
      .eq('id', quoteId);
    if (error) {
      console.error('שגיאה במחיקת הצעת מחיר:', error);
      alert('לא הצלחנו למחוק את הצעת המחיר');
    } else {
      setQuotes(prev => prev.filter(q => q.id !== quoteId));
    }
  };

  const handleEdit = (id: string) => {
    navigate(`/quick-quote?id=${id}`);
  };

  const handleBulkDelete = async () => {
    if (!window.confirm(`האם למחוק ${selectedQuotes.length} הצעות?`)) return;
    const { error } = await supabase
      .from('quick_quotes')
      .delete()
      .in('id', selectedQuotes);
    if (error) {
      alert('שגיאה במחיקה: ' + error.message);
      return;
    }
    setQuotes(prev => prev.filter(q => !selectedQuotes.includes(q.id)));
    setSelectedQuotes([]);
  };

  const filteredQuotes = quotes.filter(q => {
    const matchesText =
      q.client_name?.toLowerCase().includes(search.toLowerCase()) ||
      q.client_phone?.toLowerCase().includes(search.toLowerCase()) ||
      q.client_address?.toLowerCase().includes(search.toLowerCase());

    const quoteDate = new Date(q.created_at);
    const from = fromDate ? new Date(fromDate) : null;
    const to = toDate ? new Date(toDate) : null;

    const matchesFrom = from ? quoteDate >= from : true;
    const matchesTo = to ? quoteDate <= to : true;

    return matchesText && matchesFrom && matchesTo;
  });

  return (
    <div className="max-w-5xl w-full mx-auto bg-white rounded-2xl shadow-lg p-8 mt-8">
      <h1 className="text-3xl font-bold mb-8 text-right">היסטוריית הצעות מחיר</h1>
      <div className="mb-6 w-full flex flex-col md:flex-row gap-4 items-center md:items-end">
        <div className="flex flex-col w-full md:flex-1">
          <label className="mb-1 text-sm text-gray-600 text-right invisible md:visible">.</label>
          <input
            type="text"
            placeholder="חפש לפי שם לקוח, טלפון או כתובת..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full px-4 py-2 rounded-lg border border-gray-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-100 text-right bg-white"
          />
        </div>
        <div className="flex flex-col w-full md:w-1/4">
          <label className="mb-1 text-sm text-gray-600 text-right">תאריך התחלה</label>
          <input
            type="date"
            value={fromDate}
            onChange={e => setFromDate(e.target.value)}
            className="px-2 py-2 rounded-lg border border-gray-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-100 text-right bg-white"
            placeholder="מתאריך"
          />
        </div>
        <div className="flex flex-col w-full md:w-1/4">
          <label className="mb-1 text-sm text-gray-600 text-right">תאריך סיום</label>
          <input
            type="date"
            value={toDate}
            onChange={e => setToDate(e.target.value)}
            className="px-2 py-2 rounded-lg border border-gray-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-100 text-right bg-white"
            placeholder="עד תאריך"
          />
        </div>
      </div>
      {selectedQuotes.length > 0 && (
        <button
          onClick={handleBulkDelete}
          className="bg-red-500 text-white px-4 py-2 rounded mb-4"
        >
          מחק {selectedQuotes.length} הצעות נבחרות
        </button>
      )}
      <div className="overflow-x-auto">
        <table className="w-full text-right border-separate border-spacing-y-2">
          <thead>
            <tr className="bg-gray-100 text-gray-700 text-lg">
              <th className="p-3 font-semibold">
                <input
                  type="checkbox"
                  checked={selectedQuotes.length === filteredQuotes.length && filteredQuotes.length > 0}
                  onChange={e => {
                    if (e.target.checked) {
                      setSelectedQuotes(filteredQuotes.map(q => q.id));
                    } else {
                      setSelectedQuotes([]);
                    }
                  }}
                />
              </th>
              <th className="p-3 font-semibold">שם לקוח</th>
              <th className="p-3 font-semibold">טלפון</th>
              <th className="p-3 font-semibold">כתובת</th>
              <th className="p-3 font-semibold">תאריך</th>
              <th className="p-3 font-semibold">סה"כ עסקה</th>
              <th className="p-3 font-semibold">פעולות</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={7} className="text-center py-8">טוען...</td></tr>
            ) : filteredQuotes.length === 0 ? (
              <tr><td colSpan={7} className="text-center py-8 text-gray-400">לא נמצאו הצעות מחיר</td></tr>
            ) : filteredQuotes.map((q) => (
              <tr key={q.id} className="border-b last:border-b-0 hover:bg-gray-50">
                <td className="p-3">
                  <input
                    type="checkbox"
                    checked={selectedQuotes.includes(q.id)}
                    onChange={e => {
                      if (e.target.checked) {
                        setSelectedQuotes(prev => [...prev, q.id]);
                      } else {
                        setSelectedQuotes(prev => prev.filter(id => id !== q.id));
                      }
                    }}
                  />
                </td>
                <td className="p-3">{q.client_name}</td>
                <td className="p-3">{q.client_phone}</td>
                <td className="p-3">{q.client_address}</td>
                <td className="p-3">{new Date(q.created_at).toLocaleDateString('he-IL')}</td>
                <td className="p-3">₪{q.total.toLocaleString()}</td>
                <td className="p-3">
                  <div className="flex gap-3 justify-center">
                    <button
                      onClick={() => handleDownload(q.pdf_url, `quote-${q.quote_number || q.id}.pdf`)}
                      title="הורד PDF"
                      className="text-blue-600 hover:text-blue-800"
                    >
                      <Download className="w-5 h-5" />
                    </button>
                    <button onClick={() => handleEdit(q.id)} title="ערוך" className="text-gray-600 hover:text-gray-800"><Edit className="w-5 h-5" /></button>
                    <button onClick={() => handleDeleteQuote(q.id)} title="מחק" className="text-red-600 hover:text-red-800"><Trash2 className="w-5 h-5" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default QuotesPage; 