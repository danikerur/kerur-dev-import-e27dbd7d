import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { exportOrderToPDF } from '../lib/exportUtils';
import { Eye, FileDown, Trash2, Truck } from 'lucide-react';

interface SupplierOrder {
  id: string;
  order_number: number;
  created_at: string;
  supplier_id: string;
  supplier_name: string;
  items_count: number;
}

export default function SupplierOrdersPage() {
  const [orders, setOrders] = useState<SupplierOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedOrder, setSelectedOrder] = useState<SupplierOrder | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [modalItems, setModalItems] = useState<any[]>([]);
  const [modalLoading, setModalLoading] = useState(false);
  const [modalError, setModalError] = useState<string | null>(null);
  const [modalVersions, setModalVersions] = useState<any[]>([]);
  const [selectedVersion, setSelectedVersion] = useState<any>(null);
  const [editItems, setEditItems] = useState<any[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [products, setProducts] = useState<any[]>([]);
  const [productSearch, setProductSearch] = useState('');
  const [saving, setSaving] = useState(false);
  const [modalProductSearch, setModalProductSearch] = useState('');
  const [modalProductList, setModalProductList] = useState<any[]>([]);
  const [selectedProductToAdd, setSelectedProductToAdd] = useState<any>(null);
  const [selectedSizeToAdd, setSelectedSizeToAdd] = useState<any>(null);
  const [orderSearch, setOrderSearch] = useState('');
  const [showShipmentModal, setShowShipmentModal] = useState(false);
  const [shipmentOrder, setShipmentOrder] = useState<SupplierOrder | null>(null);
  const [estimatedArrivalDays, setEstimatedArrivalDays] = useState(35);
  const [creatingShipment, setCreatingShipment] = useState(false);
  const [selectedOrderIds, setSelectedOrderIds] = useState<string[]>([]);
  const [addDimensionRow, setAddDimensionRow] = useState<{ productId: string, dimensionId: string | null, quantity: number } | null>(null);

  useEffect(() => {
    fetchOrders();
  }, []);

  async function fetchOrders() {
    setLoading(true);
    setError(null);
    try {
      // Fetch all orders with supplier name
      const { data, error } = await supabase
        .from('supplier_orders')
        .select(`id, order_number, created_at, supplier_id, suppliers(name)`)
        .order('created_at', { ascending: false });
      if (error) throw error;
      // For each order, fetch its LATEST version's items and sum quantities
      const ordersWithCounts = await Promise.all((data || []).map(async (row: any) => {
        // 1. Fetch latest version for this order
        const { data: versions, error: vErr } = await supabase
          .from('supplier_order_versions')
          .select('id')
          .eq('order_id', row.id)
          .order('created_at', { ascending: false })
          .limit(1);
        let items_count = 0;
        if (!vErr && versions && versions.length > 0) {
          const latestVersionId = versions[0].id;
          // 2. Fetch items for latest version
          const { data: items, error: itemsError } = await supabase
            .from('supplier_order_items')
            .select('quantity')
            .eq('version_id', latestVersionId);
          if (!itemsError && items) {
            items_count = items.reduce((sum: number, item: any) => sum + (item.quantity || 0), 0);
          }
        } else {
          // If no version exists, count items with version_id null (new order)
          const { data: items, error: itemsError } = await supabase
            .from('supplier_order_items')
            .select('quantity')
            .eq('order_id', row.id)
            .is('version_id', null);
          if (!itemsError && items) {
            items_count = items.reduce((sum: number, item: any) => sum + (item.quantity || 0), 0);
          }
        }
        return {
          id: row.id,
          order_number: row.order_number,
          created_at: row.created_at,
          supplier_id: row.supplier_id,
          supplier_name: row.suppliers?.name || '',
          items_count,
        };
      }));
      setOrders(ordersWithCounts);
    } catch (err: any) {
      setError(err.message || 'שגיאה בטעינת ההזמנות');
    } finally {
      setLoading(false);
    }
  }

  async function handleDelete(orderId: string) {
    if (!window.confirm('האם למחוק את ההזמנה וכל הפריטים שלה?')) return;
    try {
      const { error } = await supabase
        .from('supplier_orders')
        .delete()
        .eq('id', orderId);
      if (error) throw error;
      setOrders(orders.filter(o => o.id !== orderId));
    } catch (err) {
      alert('שגיאה במחיקת ההזמנה');
    }
  }

  async function handleDownloadPDF(order: SupplierOrder) {
    // Fetch items for this order
    const { data: items, error } = await supabase
      .from('supplier_order_items')
      .select('selected_dimension, quantity')
      .eq('order_id', order.id);
    if (error) {
      alert('שגיאה בטעינת פריטי ההזמנה');
      return;
    }
    const orderData = (items || []).map((item: any) => {
      const dim = item.selected_dimension;
      let modelName = dim?.model || '';
      if (dim?.model && dim?.name) {
        modelName = `${dim.model} - ${dim.name}`;
      } else if (dim?.name && !dim?.model) {
        modelName = dim.name;
      }
      const width = dim?.width ?? '';
      const length = dim?.length ?? '';
      const height = dim?.height ?? '';
      return {
        modelName,
        dimensions: `${width}x${length}x${height}`,
        quantity: item.quantity
      };
    });
    exportOrderToPDF(orderData, order.supplier_name, order.order_number);
  }

  async function fetchProducts(supplierId: string) {
    const { data, error } = await supabase
      .from('products')
      .select('id, name, product_code, dimensions')
      .eq('supplier_id', supplierId);
    if (!error) setProducts(data || []);
  }

  async function fetchProductsForSupplier(supplierId: string) {
    const { data, error } = await supabase
      .from('products')
      .select('id, name, product_code, image_url, dimensions')
      .eq('supplier_id', supplierId);
    if (!error) setModalProductList(data || []);
  }

  async function openOrderModal(order: SupplierOrder) {
    setSelectedOrder(order);
    setShowEditModal(true);
    setModalLoading(true);
    setModalError(null);
    setModalItems([]);
    setModalVersions([]);
    setSelectedVersion(null);
    setEditItems([]);
    setIsEditing(false);
    setModalProductSearch('');
    setModalProductList([]);
    setSelectedProductToAdd(null);
    setSelectedSizeToAdd(null);
    await fetchProductsForSupplier(order.supplier_id);
    try {
      // Get all versions for this order
      let { data: versions, error: vErr } = await supabase
        .from('supplier_order_versions')
        .select('*')
        .eq('order_id', order.id)
        .order('created_at', { ascending: false });
      if (vErr) throw vErr;
      // If no version exists, create one and assign all items to it
      if (!versions || versions.length === 0) {
        // Create version
        const { data: newVersion, error: newVerErr } = await supabase
          .from('supplier_order_versions')
          .insert({ order_id: order.id })
          .select()
          .single();
        if (newVerErr) throw newVerErr;
        // Assign all items to this version (if any exist without version_id)
        const { data: itemsNoVersion, error: itemsErr } = await supabase
          .from('supplier_order_items')
          .select('id')
          .eq('order_id', order.id)
          .is('version_id', null);
        if (itemsErr) throw itemsErr;
        if (itemsNoVersion && itemsNoVersion.length > 0) {
          const ids = itemsNoVersion.map((i: any) => i.id);
          await supabase
            .from('supplier_order_items')
            .update({ version_id: newVersion.id })
            .in('id', ids);
        }
        // Now reload versions
        const { data: versions2, error: vErr2 } = await supabase
          .from('supplier_order_versions')
          .select('*')
          .eq('order_id', order.id)
          .order('created_at', { ascending: false });
        if (vErr2) throw vErr2;
        versions = versions2;
      }
      setModalVersions(versions || []);
      const latestVersion = (versions && versions[0]) || null;
      setSelectedVersion(latestVersion);
      if (latestVersion) {
        // Get items for latest version
        const { data: items, error } = await supabase
          .from('supplier_order_items')
          .select('id, product_id, selected_dimension, quantity')
          .eq('version_id', latestVersion.id);
        if (error) throw error;
        setModalItems(items || []);
        setEditItems(items ? JSON.parse(JSON.stringify(items)) : []);
      } else {
        setModalItems([]);
        setEditItems([]);
      }
    } catch (err: any) {
      setModalError(err.message || 'שגיאה בטעינת פריטי ההזמנה');
    } finally {
      setModalLoading(false);
    }
  }

  async function loadVersionItems(version: any) {
    setModalLoading(true);
    setSelectedVersion(version);
    try {
      const { data: items, error } = await supabase
        .from('supplier_order_items')
        .select('id, product_id, selected_dimension, quantity')
        .eq('version_id', version.id);
      if (error) throw error;
      setModalItems(items || []);
      setEditItems(items ? JSON.parse(JSON.stringify(items)) : []);
      setIsEditing(false);
    } catch (err: any) {
      setModalError(err.message || 'שגיאה בטעינת פריטים');
    } finally {
      setModalLoading(false);
    }
  }

  function handleEditQuantity(idx: number, quantity: number) {
    setEditItems(items => items.map((item, i) => i === idx ? { ...item, quantity } : item));
  }

  function handleRemoveItem(idx: number) {
    setEditItems(items => items.filter((_, i) => i !== idx));
  }

  function handleAddItem(product: any) {
    // Use first dimension as default
    const dim = (product.dimensions && product.dimensions[0]) || {};
    setEditItems(items => [...items, {
      id: undefined,
      product_id: product.id,
      selected_dimension: dim,
      quantity: 1
    }]);
  }

  async function handleSaveNewVersion() {
    if (!selectedOrder) return;
    setSaving(true);
    setModalError(null);
    try {
      // 1. Create new version
      const { data: version, error: vErr } = await supabase
        .from('supplier_order_versions')
        .insert({ order_id: selectedOrder.id })
        .select()
        .single();
      if (vErr) throw vErr;
      // 2. Delete all items for this version (should be empty, but for safety)
      await supabase
        .from('supplier_order_items')
        .delete()
        .eq('version_id', version.id);
      // 3. Insert all items with new version_id
      const itemsToInsert = editItems.map(item => ({
        order_id: selectedOrder.id,
        version_id: version.id,
        product_id: item.product_id,
        selected_dimension: item.selected_dimension,
        quantity: item.quantity
      }));
      if (itemsToInsert.length > 0) {
        const { error: iErr } = await supabase
          .from('supplier_order_items')
          .insert(itemsToInsert);
        if (iErr) throw iErr;
      }
      // 4. Refresh modal
      await openOrderModal(selectedOrder);
      setIsEditing(false);
    } catch (err: any) {
      setModalError(err.message || 'שגיאה בשמירת גרסה חדשה');
    } finally {
      setSaving(false);
    }
  }

  async function handleExportPDFForVersion(version: any) {
    if (!selectedOrder || !version) return;
    try {
      const { data: items, error } = await supabase
        .from('supplier_order_items')
        .select('selected_dimension, quantity')
        .eq('version_id', version.id);
      if (error) {
        alert('שגיאה בטעינת פריטי ההזמנה');
        return;
      }
      const orderData = (items || []).map((item: any) => {
        const dim = item.selected_dimension;
        let modelName = dim?.model || '';
        if (dim?.model && dim?.name) {
          modelName = `${dim.model} - ${dim.name}`;
        } else if (dim?.name && !dim?.model) {
          modelName = dim.name;
        }
        const width = dim?.width ?? '';
        const length = dim?.length ?? '';
        const height = dim?.height ?? '';
        return {
          modelName,
          dimensions: `${width}x${length}x${height}`,
          quantity: item.quantity
        };
      });
      exportOrderToPDF(orderData, selectedOrder.supplier_name, selectedOrder.order_number);
    } catch (err) {
      alert('שגיאה ביצוא PDF');
    }
  }

  async function handleBulkDelete() {
    if (selectedOrderIds.length === 0) return;
    if (!window.confirm('האם למחוק את כל ההזמנות שנבחרו?')) return;
    try {
      const { error } = await supabase
        .from('supplier_orders')
        .delete()
        .in('id', selectedOrderIds);
      if (error) throw error;
      setOrders(orders.filter(o => !selectedOrderIds.includes(o.id)));
      setSelectedOrderIds([]);
    } catch (err) {
      alert('שגיאה במחיקת ההזמנות');
    }
  }

  async function handleCreateShipment() {
    if (!shipmentOrder) return;
    setCreatingShipment(true);
    try {
      // Create shipment
      const { data: shipment, error: shipmentErr } = await supabase
        .from('supplier_shipments')
        .insert({
          order_id: shipmentOrder.id,
          estimated_arrival_days: estimatedArrivalDays,
        })
        .select()
        .single();
      if (shipmentErr) throw shipmentErr;
      
      // Create initial status
      const { error: statusErr } = await supabase
        .from('supplier_shipment_statuses')
        .insert({
          shipment_id: shipment.id,
          title: 'הזמנה נוצרה',
          status: 'done',
          completed_at: new Date().toISOString(),
          source: 'auto'
        });
      if (statusErr) throw statusErr;
      
      setShowShipmentModal(false);
      setShipmentOrder(null);
      alert('המשלוח נוצר בהצלחה!');
    } catch (err: any) {
      alert('שגיאה ביצירת משלוח: ' + (err.message || err));
    } finally {
      setCreatingShipment(false);
    }
  }

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">הזמנות מספקים</h1>
      <input
        type="text"
        placeholder="חפש לפי מספר הזמנה או שם ספק..."
        value={orderSearch}
        onChange={e => setOrderSearch(e.target.value)}
        className="mb-4 px-3 py-2 border rounded w-full"
        dir="rtl"
      />
      {selectedOrderIds.length > 0 && (
        <button
          className="mb-4 bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded font-bold"
          onClick={handleBulkDelete}
        >
          מחק הזמנות שנבחרו ({selectedOrderIds.length})
        </button>
      )}
      {loading ? (
        <div>טוען הזמנות...</div>
      ) : error ? (
        <div className="text-red-500">{error}</div>
      ) : (
        <div className="bg-white rounded-lg shadow overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-center">
                  <input
                    type="checkbox"
                    checked={selectedOrderIds.length === orders.length && orders.length > 0}
                    onChange={e => {
                      if (e.target.checked) {
                        setSelectedOrderIds(orders.map(o => o.id));
                      } else {
                        setSelectedOrderIds([]);
                      }
                    }}
                  />
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">מספר הזמנה</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">תאריך</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">ספק</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">מספר פריטים</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">פעולות</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {orders
                .filter(order => {
                  const search = orderSearch.trim().toLowerCase();
                  if (!search) return true;
                  const supplierName = order.supplier_name?.toLowerCase() || '';
                  const orderNumber = String(order.order_number);
                  return supplierName.includes(search) || orderNumber.includes(search);
                })
                .map(order => (
                  <tr key={order.id}>
                    <td className="px-4 py-4 text-center">
                      <input
                        type="checkbox"
                        checked={selectedOrderIds.includes(order.id)}
                        onChange={e => {
                          if (e.target.checked) {
                            setSelectedOrderIds(ids => [...ids, order.id]);
                          } else {
                            setSelectedOrderIds(ids => ids.filter(id => id !== order.id));
                          }
                        }}
                      />
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">{order.order_number}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{new Date(order.created_at).toLocaleDateString()}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{order.supplier_name}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{order.items_count}</td>
                    <td className="px-6 py-4 whitespace-nowrap flex gap-2">
                      <button
                        title="צפייה / עריכה"
                        className="text-blue-500 hover:bg-blue-50 p-2 rounded-full transition"
                        onClick={() => openOrderModal(order)}
                      >
                        <Eye className="w-5 h-5" />
                      </button>
                      <button
                        title="הורד PDF"
                        className="text-green-600 hover:bg-green-50 p-2 rounded-full transition"
                        onClick={() => handleDownloadPDF(order)}
                      >
                        <FileDown className="w-5 h-5" />
                      </button>
                      <button
                        title="מחק"
                        className="text-red-500 hover:bg-red-50 p-2 rounded-full transition"
                        onClick={() => handleDelete(order.id)}
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                      <button
                        title="ייצוא לקונטיינר"
                        className="text-orange-500 hover:bg-orange-50 p-2 rounded-full transition"
                        onClick={() => { setShipmentOrder(order); setEstimatedArrivalDays(35); setShowShipmentModal(true); }}
                      >
                        <Truck className="w-5 h-5" />
                      </button>
                    </td>
                  </tr>
                ))}
              {orders.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-4 text-center text-gray-400">אין הזמנות</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
      {showEditModal && selectedOrder && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">הזמנה #{selectedOrder.order_number}</h2>
              <div>
                <span className="font-semibold">גרסאות:</span>
                {modalVersions.map((v, idx) => (
                  <button
                    key={v.id}
                    className={`mx-1 px-2 py-1 rounded text-xs ${selectedVersion && v.id === selectedVersion.id ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}
                    onClick={() => loadVersionItems(v)}
                  >
                    {new Date(v.created_at).toLocaleString('he-IL', { dateStyle: 'short', timeStyle: 'short' })}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex gap-2 mb-4">
              <button
                className="bg-green-500 text-white px-4 py-2 rounded"
                onClick={() => handleExportPDFForVersion(selectedVersion)}
              >
                ייצא PDF לגרסה זו
              </button>
            </div>
            {modalLoading ? (
              <div>טוען פריטים...</div>
            ) : modalError ? (
              <div className="text-red-500">{modalError}</div>
            ) : (
              <>
                <table className="min-w-full divide-y divide-gray-200 mb-4">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">תמונה</th>
                      <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">דגם</th>
                      <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">מידות</th>
                      <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">כמות</th>
                      {isEditing && <th></th>}
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {editItems.map((item, idx) => {
                      const dim = item.selected_dimension;
                      let modelName = dim?.model || '';
                      if (dim?.model && dim?.name) {
                        modelName = `${dim.model} - ${dim.name}`;
                      } else if (dim?.name && !dim?.model) {
                        modelName = dim.name;
                      }
                      const width = dim?.width ?? '';
                      const length = dim?.length ?? '';
                      const height = dim?.height ?? '';
                      const product = modalProductList.find(p => p.id === item.product_id);
                      return (
                        <>
                        <tr key={idx}>
                          <td className="px-4 py-2 whitespace-nowrap">
                            {product?.image_url ? (
                              <img src={product.image_url} alt={modelName} className="w-14 h-14 object-contain rounded bg-white border" />
                            ) : (
                              <div className="w-14 h-14 flex items-center justify-center text-gray-300 bg-gray-50 border rounded">—</div>
                            )}
                          </td>
                          <td className="px-4 py-2 whitespace-nowrap">{modelName}</td>
                          <td className="px-4 py-2 whitespace-nowrap">{width}x{length}x{height}</td>
                          <td className="px-4 py-2 whitespace-nowrap">
                            {isEditing ? (
                              <input
                                type="number"
                                min="1"
                                value={item.quantity}
                                onChange={e => handleEditQuantity(idx, parseInt(e.target.value) || 1)}
                                className="w-16 px-2 py-1 border rounded"
                              />
                            ) : (
                              item.quantity
                            )}
                          </td>
                          {isEditing && (
                            <td>
                              <button className="text-red-500" onClick={() => handleRemoveItem(idx)}>
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          )}
                        </tr>
                        {/* Add extra dimension row UI */}
                        {isEditing && (
                          <tr>
                            <td colSpan={5} className="px-4 pb-2">
                              <button
                                className="text-blue-600 underline text-sm mt-1"
                                onClick={() => setAddDimensionRow({ productId: item.product_id, dimensionId: null, quantity: 1 })}
                              >
                                הוסף מידה נוספת
                              </button>
                              {addDimensionRow && addDimensionRow.productId === item.product_id && (
                                <div className="flex items-center gap-2 mt-2">
                                  <select
                                    className="border rounded px-2 py-1"
                                    value={addDimensionRow.dimensionId || ''}
                                    onChange={e => setAddDimensionRow(row => row ? { ...row, dimensionId: e.target.value } : null)}
                                  >
                                    <option value="">בחר מידה</option>
                                    {product?.dimensions?.map((size: any) => (
                                      <option key={size.id} value={size.id}>
                                        {size.name ? size.name + ' - ' : ''}
                                        {size.width ?? 0}x{size.length ?? 0}x{size.height ?? 0}
                                      </option>
                                    ))}
                                  </select>
                                  <input
                                    type="number"
                                    min="1"
                                    value={addDimensionRow.quantity}
                                    onChange={e => setAddDimensionRow(row => row ? { ...row, quantity: parseInt(e.target.value) || 1 } : null)}
                                    className="w-16 px-2 py-1 border rounded"
                                  />
                                  <button
                                    className="bg-blue-500 text-white px-3 py-1 rounded"
                                    disabled={!addDimensionRow.dimensionId}
                                    onClick={() => {
                                      if (!addDimensionRow || !addDimensionRow.dimensionId) return;
                                      const size = product?.dimensions?.find((s: any) => s.id === addDimensionRow.dimensionId);
                                      if (!size) return;
                                      setEditItems(items => [
                                        ...items,
                                        {
                                          id: undefined,
                                          product_id: item.product_id,
                                          selected_dimension: size,
                                          quantity: addDimensionRow.quantity
                                        }
                                      ]);
                                      setAddDimensionRow(null);
                                    }}
                                  >
                                    הוסף
                                  </button>
                                  <button
                                    className="text-gray-500 px-2"
                                    onClick={() => setAddDimensionRow(null)}
                                  >
                                    בטל
                                  </button>
                                </div>
                              )}
                            </td>
                          </tr>
                        )}
                        </>
                      );
                    })}
                  </tbody>
                </table>
                {isEditing && (
                  <div className="mb-4">
                    <input
                      type="text"
                      placeholder="חפש מוצר..."
                      value={modalProductSearch}
                      onChange={e => setModalProductSearch(e.target.value)}
                      className="w-full px-3 py-2 border rounded mb-2"
                    />
                    <div className="max-h-48 overflow-y-auto space-y-2">
                      {modalProductList.filter(product => {
                        const search = modalProductSearch.trim().toLowerCase();
                        if (!search) return true;
                        const name = product.name?.toLowerCase() || '';
                        const code = product.product_code?.toLowerCase() || '';
                        return name.includes(search) || code.includes(search);
                      }).map(product => (
                        <div key={product.id} className="flex items-center gap-4 bg-gray-50 rounded-lg p-2">
                          <img
                            src={product.image_url || '/no-image.png'}
                            alt={product.name}
                            className="w-12 h-12 object-contain rounded bg-white border"
                          />
                          <div className="flex-1">
                            <div className="font-semibold">{product.name}</div>
                            <div className="text-xs text-gray-500">{product.product_code}</div>
                          </div>
                          {product.dimensions && product.dimensions.length > 0 ? (
                            <select
                              className="px-2 py-1 border rounded text-sm"
                              value={selectedProductToAdd?.id === product.id ? (selectedSizeToAdd?.id || '') : ''}
                              onChange={e => {
                                setSelectedProductToAdd(product);
                                const size = product.dimensions.find((s: any) => s.id === e.target.value);
                                setSelectedSizeToAdd(size);
                              }}
                            >
                              <option value="">בחר מידה</option>
                              {product.dimensions.map((size: any) => (
                                <option key={size.id} value={size.id}>
                                  {size.name ? size.name + ' - ' : ''}
                                  {size.width ?? 0}x{size.length ?? 0}x{size.height ?? 0}
                                </option>
                              ))}
                            </select>
                          ) : null}
                          <button
                            className="ml-2 bg-blue-500 text-white px-3 py-1 rounded disabled:opacity-50"
                            disabled={
                              !selectedProductToAdd || selectedProductToAdd.id !== product.id || !selectedSizeToAdd
                            }
                            onClick={() => {
                              if (!selectedProductToAdd || !selectedSizeToAdd) return;
                              setEditItems(items => [
                                ...items,
                                {
                                  id: undefined,
                                  product_id: selectedProductToAdd.id,
                                  selected_dimension: selectedSizeToAdd,
                                  quantity: 1
                                }
                              ]);
                              setSelectedSizeToAdd(null);
                            }}
                          >
                            הוסף
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                <div className="flex gap-2 mt-4">
                  {isEditing ? (
                    <>
                      <button
                        className="bg-blue-500 text-white px-4 py-2 rounded"
                        onClick={handleSaveNewVersion}
                        disabled={saving}
                      >
                        שמור כגרסה חדשה
                      </button>
                      <button
                        className="bg-gray-200 px-4 py-2 rounded"
                        onClick={() => { setIsEditing(false); setEditItems(modalItems); }}
                      >
                        בטל
                      </button>
                    </>
                  ) : (
                    <button
                      className="bg-blue-500 text-white px-4 py-2 rounded"
                      onClick={() => { setIsEditing(true); setEditItems(modalItems); }}
                    >
                      ערוך
                    </button>
                  )}
                  <button
                    className="bg-gray-200 px-4 py-2 rounded ml-auto"
                    onClick={() => setShowEditModal(false)}
                  >
                    סגור
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
      {showShipmentModal && shipmentOrder && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">ייצוא הזמנה לקונטיינר</h2>
            <div className="mb-4">האם להוציא משלוח להזמנה #{shipmentOrder.order_number} ({shipmentOrder.supplier_name})?</div>
            <div className="mb-4">
              <label className="block mb-1 font-semibold">מספר ימים להגעה צפויה</label>
              <input
                type="number"
                min="1"
                value={estimatedArrivalDays}
                onChange={e => setEstimatedArrivalDays(Number(e.target.value) || 1)}
                className="border rounded px-3 py-2 w-full"
              />
            </div>
            <div className="flex gap-2 mt-4">
              <button
                className="bg-orange-500 text-white px-4 py-2 rounded"
                onClick={handleCreateShipment}
                disabled={creatingShipment}
              >
                ייצא לקונטיינר
              </button>
              <button
                className="bg-gray-200 px-4 py-2 rounded ml-auto"
                onClick={() => setShowShipmentModal(false)}
                disabled={creatingShipment}
              >
                ביטול
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
} 