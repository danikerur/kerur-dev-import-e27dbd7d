import { useEffect, useState, useRef, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { Eye, Trash2 } from 'lucide-react';
import type { Warehouse } from '../types/inventory';

interface ShipmentRow {
  id: string;
  order_id: string;
  order_number: number;
  supplier_name: string;
  created_at: string;
  estimated_arrival_days: number;
  current_status: string;
  status: string;
  supplier_tracking_number?: string | null;
  estimated_arrival_date?: string | null;
}

interface ShipmentStatus {
  id: string;
  step_number: number;
  title: string;
  status: string;
  completed_at: string | null;
  description: string | null;
  source?: 'manual' | 'auto';
  created_at?: string;
  updated_at?: string;
}

const N8N_WEBHOOK_URL = 'https://lumoraofc.app.n8n.cloud/webhook/newkerur';

export default function SupplierShipmentsPage() {
  const [shipments, setShipments] = useState<ShipmentRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showTimelineModal, setShowTimelineModal] = useState(false);
  const [timelineStatuses, setTimelineStatuses] = useState<ShipmentStatus[]>([]);
  const [timelineLoading, setTimelineLoading] = useState(false);
  const [selectedShipment, setSelectedShipment] = useState<ShipmentRow | null>(null);
  const [savingStep, setSavingStep] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [countdown, setCountdown] = useState<{days: number, hours: number, minutes: number, seconds: number} | null>(null);
  const countdownInterval = useRef<NodeJS.Timeout | null>(null);
  const [showIntakeModal, setShowIntakeModal] = useState(false);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [selectedWarehouseId, setSelectedWarehouseId] = useState<string>('');
  const [intakeLoading, setIntakeLoading] = useState(false);
  const [intakeError, setIntakeError] = useState<string | null>(null);
  const [shipmentToIntake, setShipmentToIntake] = useState<ShipmentRow | null>(null);
  const [timelineProducts, setTimelineProducts] = useState<any[]>([]);
  const [showProductsList, setShowProductsList] = useState(false);
  const [newStatusTitle, setNewStatusTitle] = useState('');
  const [addingStatus, setAddingStatus] = useState(false);
  const [syncingShipmentId, setSyncingShipmentId] = useState<string | null>(null);

  useEffect(() => {
    fetchShipments();
  }, []);

  useEffect(() => {
    if (showTimelineModal && selectedShipment) {
      // Calculate target date
      const created = new Date(selectedShipment.created_at);
      const arrival = new Date(created);
      arrival.setDate(arrival.getDate() + selectedShipment.estimated_arrival_days);

      function updateCountdown() {
        const now = new Date();
        const diff = arrival.getTime() - now.getTime();
        if (diff <= 0) {
          setCountdown({ days: 0, hours: 0, minutes: 0, seconds: 0 });
          return;
        }
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
        const minutes = Math.floor((diff / (1000 * 60)) % 60);
        const seconds = Math.floor((diff / 1000) % 60);
        setCountdown({ days, hours, minutes, seconds });
      }
      updateCountdown();
      countdownInterval.current = setInterval(updateCountdown, 1000);
      return () => {
        if (countdownInterval.current) clearInterval(countdownInterval.current);
      };
    } else {
      setCountdown(null);
      if (countdownInterval.current) clearInterval(countdownInterval.current);
    }
  }, [showTimelineModal, selectedShipment]);

  // Fetch warehouses on mount
  useEffect(() => {
    if (showIntakeModal) {
      fetchWarehouses();
    }
  }, [showIntakeModal]);

  async function fetchShipments() {
    setLoading(true);
    setError(null);
    try {
      // Fetch shipments with order and supplier info
      const { data, error } = await supabase
        .from('supplier_shipments')
        .select(`id, order_id, created_at, estimated_arrival_days, status, supplier_tracking_number, estimated_arrival_date, supplier_orders(order_number, supplier_id, suppliers(name))`)
        .neq('id', '00000000-0000-0000-0000-000000000000') // force fresh fetch
        .order('created_at', { ascending: false });
      if (error) throw error;
      // For each shipment, fetch latest status
      const rows = await Promise.all((data || []).map(async (row: any) => {
        // Fetch all statuses for this shipment
        if (!row.id) {
          console.warn('shipment_id is null or undefined!', row);
          return {
            id: row.id,
            order_id: row.order_id,
            order_number: row.supplier_orders?.order_number || '',
            supplier_name: row.supplier_orders?.suppliers?.name || '',
            created_at: row.created_at,
            estimated_arrival_days: row.estimated_arrival_days,
            current_status: 'לא התחיל',
            status: row.status,
            supplier_tracking_number: row.supplier_tracking_number || '',
            estimated_arrival_date: row.estimated_arrival_date || '',
          };
        }
        const { data: statuses, error: statusErr } = await supabase
          .from('supplier_shipment_statuses')
          .select('*')
          .eq('shipment_id', row.id)
          .order('updated_at', { ascending: false });
        console.log('statuses for shipment', row.id, statuses);
        let current_status = 'לא התחיל';
        if (!statusErr && statuses && statuses.length > 0) {
          // מיין לפי updated_at יורד וקח את הראשון
          const sorted = [...statuses].sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime());
          const last = sorted[0];
          if (last.status === 'done') {
            current_status = `${last.title} (בוצע)`;
          } else {
            current_status = `${last.title} (ממתין)`;
          }
        }
        console.log('current_status for shipment', row.id, current_status);
        return {
          id: row.id,
          order_id: row.order_id,
          order_number: row.supplier_orders?.order_number || '',
          supplier_name: row.supplier_orders?.suppliers?.name || '',
          created_at: row.created_at,
          estimated_arrival_days: row.estimated_arrival_days,
          current_status,
          status: row.status,
          supplier_tracking_number: row.supplier_tracking_number || '',
          estimated_arrival_date: row.estimated_arrival_date || '',
        };
      }));
      setShipments(rows);
    } catch (err: any) {
      setError(err.message || 'שגיאה בטעינת המשלוחים');
    } finally {
      setLoading(false);
    }
  }

  async function fetchWarehouses() {
    try {
      const { data, error } = await supabase
        .from('warehouses')
        .select('*')
        .order('name');
      if (error) throw error;
      setWarehouses(data || []);
    } catch (error) {
      setWarehouses([]);
    }
  }

  function getEstimatedArrivalDate(created_at: string, days: number, estimated_arrival_date?: string | null) {
    if (estimated_arrival_date) {
      return new Date(estimated_arrival_date).toLocaleDateString();
    }
    const d = new Date(created_at);
    d.setDate(d.getDate() + days);
    return d.toLocaleDateString();
  }

  async function openTimelineModal(shipment: ShipmentRow) {
    if (!shipment || !shipment.id) {
      alert('לא נבחר משלוח (timeline)');
      return;
    }
    console.log('DEBUG shipment:', shipment);
    console.log('DEBUG shipment.id:', shipment.id, typeof shipment.id, JSON.stringify(shipment.id));
    if (!shipment.id) {
      console.warn('shipment_id is null or undefined!', shipment);
      setTimelineStatuses([]);
      setTimelineProducts([]);
      setTimelineLoading(false);
      return;
    }
    setSelectedShipment(shipment);
    setShowTimelineModal(true);
    setTimelineLoading(true);
    setTimelineProducts([]);
    try {
      // Fetch statuses ordered by updated_at descending
      const { data, error } = await supabase
        .from('supplier_shipment_statuses')
        .select('*')
        .eq('shipment_id', shipment.id)
        .order('updated_at', { ascending: false });
      console.log('DEBUG statuses from DB:', data);
      if (error) throw error;
      // Sort statuses by updated_at, handling null values
      const sorted = [...(data || [])].sort((a, b) => {
        const dateA = a.updated_at ? new Date(a.updated_at).getTime() : 0;
        const dateB = b.updated_at ? new Date(b.updated_at).getTime() : 0;
        return dateB - dateA;
      });
      console.log('DEBUG sorted statuses:', sorted);
      setTimelineStatuses(sorted);
      // Fetch products in this shipment (by order_id)
      const { data: products } = await supabase
        .from('supplier_order_items')
        .select('quantity, selected_dimension, product:products(id, name, image_url, product_code)')
        .eq('order_id', shipment.order_id);
      setTimelineProducts(products || []);
    } catch (err) {
      setTimelineStatuses([]);
      setTimelineProducts([]);
    } finally {
      setTimelineLoading(false);
    }
  }

  async function handleStepDone(status: ShipmentStatus) {
    setSavingStep(status.id);
    try {
      const now = new Date().toISOString();
      const { error } = await supabase
        .from('supplier_shipment_statuses')
        .update({ status: 'done', completed_at: now })
        .eq('id', status.id);
      if (error) throw error;
      // Update main shipment status as well
      if (selectedShipment) {
        await supabase
          .from('supplier_shipments')
          .update({ status: status.title })
          .eq('id', selectedShipment.id);
      }
      // Refresh statuses
      if (selectedShipment) await openTimelineModal(selectedShipment);
      await fetchShipments();
    } catch (err) {
      const errorMsg = (err as any)?.message || err;
      alert('שגיאה בעדכון סטטוס: ' + errorMsg);
    } finally {
      setSavingStep(null);
    }
  }

  async function handleStepDescription(status: ShipmentStatus, description: string) {
    setSavingStep(status.id);
    try {
      const { error } = await supabase
        .from('supplier_shipment_statuses')
        .update({ description })
        .eq('id', status.id);
      if (error) throw error;
      // Refresh statuses
      if (selectedShipment) await openTimelineModal(selectedShipment);
    } catch (err) {
      alert('שגיאה בעדכון הערה');
    } finally {
      setSavingStep(null);
    }
  }

  // Intake logic
  async function handleIntake() {
    if (!shipmentToIntake || !selectedWarehouseId) return;
    setIntakeLoading(true);
    setIntakeError(null);
    try {
      // 1. Get the real order UUID from supplier_orders by order_number
      const { data: orderRow, error: orderRowError } = await supabase
        .from('supplier_orders')
        .select('id')
        .eq('order_number', shipmentToIntake.order_number)
        .single();
      if (orderRowError || !orderRow) throw orderRowError || new Error('לא נמצא מזהה הזמנה');
      const orderId = orderRow.id;
      // 2. Get latest version's created_at for this order
      const { data: latestVersion, error: versionError } = await supabase
        .from('supplier_order_items')
        .select('created_at')
        .eq('order_id', orderId)
        .order('created_at', { ascending: false })
        .limit(1)
        .single();
      if (versionError || !latestVersion) throw versionError || new Error('לא נמצאה גרסה אחרונה');
      // 3. Fetch only items from the latest version
      const { data: orderItems, error: orderItemsError } = await supabase
        .from('supplier_order_items')
        .select('product_id, quantity')
        .eq('order_id', orderId)
        .eq('created_at', latestVersion.created_at);
      if (orderItemsError) throw orderItemsError;
      // 4. Check if already intaken (prevent double intake)
      const { data: intakeStatus, error: intakeStatusError } = await supabase
        .from('supplier_shipment_statuses')
        .select('id, status')
        .eq('shipment_id', shipmentToIntake.id)
        .eq('title', 'קליטה')
        .single();
      if (intakeStatus && intakeStatus.status === 'done') {
        setIntakeError('הקונטיינר כבר נקלט. לא ניתן לקלוט שוב.');
        setIntakeLoading(false);
        return;
      }
      for (const item of orderItems) {
        // Check if product already exists in warehouse inventory
        const { data: existing, error: invErr } = await supabase
          .from('warehouse_inventory')
          .select('id, quantity')
          .eq('warehouse_id', selectedWarehouseId)
          .eq('product_id', item.product_id)
          .single();
        if (existing) {
          // Update quantity
          await supabase
            .from('warehouse_inventory')
            .update({ quantity: existing.quantity + item.quantity })
            .eq('id', existing.id);
        } else {
          // Insert new record
          await supabase
            .from('warehouse_inventory')
            .insert({
              warehouse_id: selectedWarehouseId,
              product_id: item.product_id,
              quantity: item.quantity
            });
        }
      }
      // 5. Update or insert shipment status to 'נקלט'
      if (intakeStatus) {
        await supabase
          .from('supplier_shipment_statuses')
          .update({ status: 'done', completed_at: new Date().toISOString() })
          .eq('id', intakeStatus.id);
      } else {
        await supabase
          .from('supplier_shipment_statuses')
          .insert({
            shipment_id: shipmentToIntake.id,
            title: 'קליטה',
            status: 'done',
            completed_at: new Date().toISOString(),
            step_number: 99 // or last step
          });
      }
      setShowIntakeModal(false);
      setShipmentToIntake(null);
      setSelectedWarehouseId('');
      await fetchShipments();
      await supabase
        .from('supplier_shipments')
        .update({ status: 'received' })
        .eq('id', shipmentToIntake.id);
      alert('הקונטיינר נקלט בהצלחה!');
    } catch (err: any) {
      setIntakeError(err.message || 'שגיאה בקליטת קונטיינר');
    } finally {
      setIntakeLoading(false);
    }
  }

  async function handleAddStatus() {
    if (!selectedShipment) {
      alert('לא נבחר משלוח');
      return;
    }
    if (!newStatusTitle?.trim()) {
      alert('נא להזין סטטוס');
      return;
    }
    setAddingStatus(true);
    try {
      // שלב 1: שלוף shipment_id
      let shipmentId = selectedShipment.id;
      if (!shipmentId && selectedShipment.order_id) {
        const { data: shipmentRow } = await supabase
          .from('supplier_shipments')
          .select('id')
          .eq('order_id', selectedShipment.order_id)
          .single();
        shipmentId = shipmentRow?.id;
      }
      if (!shipmentId && selectedShipment.supplier_tracking_number) {
        const { data: shipmentRow } = await supabase
          .from('supplier_shipments')
          .select('id')
          .eq('supplier_tracking_number', selectedShipment.supplier_tracking_number)
          .single();
        shipmentId = shipmentRow?.id;
      }
      if (!shipmentId) {
        alert('לא נמצא מזהה משלוח');
        setAddingStatus(false);
        return;
      }
      // שלב 2: הוסף סטטוס חדש עם shipment_id
      const { error } = await supabase
        .from('supplier_shipment_statuses')
        .insert({
          shipment_id: shipmentId,
          title: newStatusTitle.trim(),
          status: 'pending',
          source: 'manual',
          step_number: null,
          created_at: new Date().toISOString()
        });
      if (error) throw error;
      // שלב 3: עדכן את הסטטוס הראשי בטבלת המשלוחים
      if (selectedShipment) {
        await supabase
          .from('supplier_shipments')
          .update({ status: newStatusTitle.trim() })
          .eq('id', selectedShipment.id);
      }
      setNewStatusTitle('');
      if (selectedShipment) await openTimelineModal(selectedShipment);
      await fetchShipments();
    } catch (err) {
      const errorMsg = (err as any)?.message || err;
      alert('שגיאה בהוספת סטטוס חדש: ' + errorMsg);
    } finally {
      setAddingStatus(false);
    }
  }

  const handleSyncStatus = useCallback(async (shipment: ShipmentRow) => {
    if (!shipment.supplier_tracking_number) return;
    setSyncingShipmentId(shipment.id);
    try {
      const response = await fetch(N8N_WEBHOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tracking_number: shipment.supplier_tracking_number })
      });
      if (response.ok) {
        alert('הסנכרון בוצע בהצלחה!');
      } else {
        alert('אירעה שגיאה בסנכרון (קוד: ' + response.status + ')');
      }
    } catch (err) {
      alert('שגיאה בסנכרון סטטוסים מהמייל');
    } finally {
      setSyncingShipmentId(null);
    }
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">קונטיינרים (משלוחים מספקים)</h1>
      <input
        type="text"
        placeholder="חפש לפי מספר הזמנה, שם ספק או סטטוס..."
        value={search}
        onChange={e => setSearch(e.target.value)}
        className="mb-4 px-3 py-2 border rounded w-full max-w-full"
        dir="rtl"
      />
      {loading ? (
        <div>טוען משלוחים...</div>
      ) : error ? (
        <div className="text-red-500">{error}</div>
      ) : (
        <div className="bg-white rounded-lg shadow overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">מספר הזמנה</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">ספק</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">מספר מעקב מהספק</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">תאריך יציאה</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">תאריך הגעה צפוי</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">סטטוס נוכחי</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">פעולות</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {shipments
                .filter(shipment => {
                  const q = search.trim().toLowerCase();
                  if (!q) return true;
                  return (
                    String(shipment.order_number).includes(q) ||
                    (shipment.supplier_name || '').toLowerCase().includes(q) ||
                    (shipment.current_status || '').toLowerCase().includes(q) ||
                    (shipment.supplier_tracking_number || '').toLowerCase().includes(q)
                  );
                })
                .map(shipment => (
                  <tr
                    key={shipment.id}
                    className={shipment.status === 'received' ? 'bg-green-50' : ''}
                  >
                    <td className="px-6 py-4 whitespace-nowrap">{shipment.order_number}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{shipment.supplier_name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-left font-mono text-sm text-gray-700">{shipment.supplier_tracking_number || '-'}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{new Date(shipment.created_at).toLocaleDateString()}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{getEstimatedArrivalDate(shipment.created_at, shipment.estimated_arrival_days, shipment.estimated_arrival_date)}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
  {shipment.status || shipment.current_status || 'לא התחיל'}
</td>

                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex gap-3 items-center">
                        <button
                          className="text-blue-500 hover:bg-blue-50 p-2 rounded-full transition"
                          title="צפייה / ניהול"
                          onClick={() => openTimelineModal(shipment)}
                        >
                          <Eye className="w-5 h-5" />
                        </button>
                        <button
                          style={{ display: shipment.supplier_tracking_number ? undefined : 'none' }}
                          className="text-blue-600 hover:bg-blue-50 p-2 rounded-full transition flex items-center gap-1"
                          title="סנכרן עדכון מהמייל"
                          disabled={!!syncingShipmentId}
                          onClick={() => handleSyncStatus(shipment)}
                        >
                          {syncingShipmentId === shipment.id ? (
                            <svg className="animate-spin h-5 w-5 text-blue-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"></path>
                            </svg>
                          ) : (
                            <span role="img" aria-label="sync">🔄</span>
                          )}
                          <span className="text-xs">סנכרן עדכון מהמייל</span>
                        </button>
                        <button
                          className="text-red-500 hover:bg-red-50 p-2 rounded-full transition"
                          title="מחק קונטיינר"
                          onClick={async () => {
                            if (window.confirm('האם למחוק קונטיינר זה?')) {
                              const { error } = await supabase
                                .from('supplier_shipments')
                                .delete()
                                .eq('id', shipment.id);
                              if (error) {
                                alert('שגיאה במחיקת הקונטיינר');
                              } else {
                                setShipments(shipments.filter(s => s.id !== shipment.id));
                              }
                            }
                          }}
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                        {shipment.status === 'received' ? (
                          <button
                            className="bg-green-500 text-white px-3 py-1 rounded-full text-sm font-bold cursor-not-allowed flex items-center gap-1"
                            disabled
                            title="הקונטיינר כבר נקלט"
                          >
                            <span className="text-lg">✓</span> קונטיינר נקלט
                          </button>
                        ) : (
                          <button
                            className={`bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded-full text-sm font-bold`}
                            title="קליטת קונטיינר"
                            onClick={() => {
                              setShipmentToIntake(shipment);
                              setShowIntakeModal(true);
                            }}
                          >
                            קליטת קונטיינר
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              {shipments.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-6 py-4 text-center text-gray-400">אין משלוחים</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
      {showTimelineModal && selectedShipment && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-4xl">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">ציר זמן משלוח להזמנה #{selectedShipment.order_number}</h2>
              <div className="text-gray-500 text-sm">
                {countdown ? (
                  countdown.days === 0 && countdown.hours === 0 && countdown.minutes === 0 && countdown.seconds === 0 ? (
                    'המשלוח אמור היה להגיע'
                  ) : (
                    <>הגעה משוערת בעוד {countdown.days} ימים {String(countdown.hours).padStart(2, '0')}:{String(countdown.minutes).padStart(2, '0')}:{String(countdown.seconds).padStart(2, '0')}</>
                  )
                ) : null}
              </div>
            </div>
            {timelineLoading ? (
              <div>טוען שלבים...</div>
            ) : (
              <div className="flex flex-col items-center w-full">
                <div className="w-full max-w-2xl mb-8">
                  <div className="flex flex-col md:flex-row md:items-center gap-4 mb-4">
                    <div className="flex-1">
                      <label className="block text-sm font-semibold mb-1">מספר מעקב מהספק (PO)</label>
                      <input
                        type="text"
                        className="border rounded px-3 py-2 w-full font-mono text-sm"
                        value={selectedShipment.supplier_tracking_number || ''}
                        onChange={async (e) => {
                          const value = e.target.value;
                          setSelectedShipment(s => s ? { ...s, supplier_tracking_number: value } : s);
                          await supabase
                            .from('supplier_shipments')
                            .update({ supplier_tracking_number: value })
                            .eq('id', selectedShipment.id);
                          fetchShipments();
                        }}
                        placeholder="הזן מספר מעקב מהספק (PO) במידת הצורך..."
                      />
                    </div>
                  </div>
                  {/* הוספת סטטוס חדש */}
                  <div className="flex gap-2 items-end mb-6">
                    <div className="flex-1">
                      <label className="block text-sm font-semibold mb-1">הוסף סטטוס חדש</label>
                      <input
                        type="text"
                        className="border rounded px-3 py-2 w-full"
                        value={newStatusTitle}
                        onChange={e => setNewStatusTitle(e.target.value)}
                        placeholder="הזן כותרת לסטטוס חדש..."
                      />
                    </div>
                    <button
                      className="bg-blue-500 text-white px-4 py-2 rounded disabled:opacity-50"
                      onClick={handleAddStatus}
                      disabled={!newStatusTitle.trim() || addingStatus}
                    >
                      {addingStatus ? 'מוסיף...' : 'הוסף סטטוס'}
                    </button>
                  </div>
                </div>
                {/* היסטוריית סטטוסים בלבד */}
                <div className="mt-8 w-full max-w-2xl mx-auto">
                  <h3 className="font-bold text-lg mb-2">היסטוריית סטטוסים</h3>
                  <div className="flex flex-col gap-3 max-h-72 overflow-y-auto border rounded-lg p-4 bg-gray-50">
                    {timelineStatuses.length === 0 && (
                      <div className="text-gray-400 text-center">אין סטטוסים להצגה</div>
                    )}
                    {timelineStatuses.map((status, idx) => {
                      console.log('DEBUG rendering status:', status);
                      return (
                        <div key={status.id} className="flex flex-col border-b pb-2 last:border-b-0 last:pb-0">
                          <div className="flex flex-row items-center gap-2">
                            <div className="font-semibold text-gray-800">{status.title}</div>
                            <div className="text-xs text-gray-500 ml-2">
                              {status.source === 'manual' ? 'ידני' : 'אוטומטי'}
                            </div>
                          </div>
                          <div className="text-xs text-gray-400 mt-1">
                            {status.updated_at 
                              ? `עודכן: ${new Date(status.updated_at).toLocaleString('he-IL')}`
                              : 'לא ידוע'}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
                <div className="flex justify-end mt-8">
                  <button className="bg-gray-200 px-4 py-2 rounded" onClick={() => setShowTimelineModal(false)}>סגור</button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
      {showIntakeModal && shipmentToIntake && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">קליטת קונטיינר להזמנה #{shipmentToIntake.order_number}</h2>
            <div className="mb-4">
              <label className="block mb-1 font-semibold">בחר מחסן לקליטה</label>
              <select
                className="border rounded px-3 py-2 w-full"
                value={selectedWarehouseId}
                onChange={e => setSelectedWarehouseId(e.target.value)}
              >
                <option value="">בחר מחסן...</option>
                {warehouses.map(w => (
                  <option key={w.id} value={w.id}>{w.name}</option>
                ))}
              </select>
            </div>
            {intakeError && <div className="text-red-500 mb-2">{intakeError}</div>}
            <div className="flex gap-2 justify-end mt-6">
              <button
                className="bg-gray-200 px-4 py-2 rounded"
                onClick={() => { setShowIntakeModal(false); setShipmentToIntake(null); setSelectedWarehouseId(''); }}
                disabled={intakeLoading}
              >
                ביטול
              </button>
              <button
                className="bg-green-600 text-white px-4 py-2 rounded font-bold"
                onClick={handleIntake}
                disabled={!selectedWarehouseId || intakeLoading}
              >
                {intakeLoading ? 'קולט...' : 'קלוט קונטיינר'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
} 