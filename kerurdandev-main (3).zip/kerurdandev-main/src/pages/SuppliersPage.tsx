import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Search, Edit2, Trash2, AlertCircle, X } from 'lucide-react';
import { exportOrderToPDF, exportOrderToCSV } from '../lib/exportUtils';
import isEqual from 'lodash.isequal';

interface Supplier {
  id: number;
  name: string;
  phone: string;
  email: string;
  country: string;
  created_at?: string;
}

interface Product {
  id: string;
  name: string;
  image_url: string;
  product_code: string;
  category_id: string;
  category_name?: string;
  sizes?: {
    id: string;
    name?: string;
    model?: string;
    width: number;
    length: number;
    height: number;
  }[];
}

export default function SuppliersPage() {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [filteredSuppliers, setFilteredSuppliers] = useState<Supplier[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [selectedSupplier, setSelectedSupplier] = useState<Supplier | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    country: ''
  });
  const [selectedSupplierForProducts, setSelectedSupplierForProducts] = useState<Supplier | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [supplierProducts, setSupplierProducts] = useState<Product[]>([]);
  const [isProductsLoading, setIsProductsLoading] = useState(false);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [orderItems, setOrderItems] = useState<{
    productId: string;
    quantity: number;
    sizeId?: string;
    dimensions?: string;
    selectedDimension?: {
      model?: string;
      name?: string;
      width: number;
      length: number;
      height: number;
    };
  }[]>([]);
  const [orderProductSearch, setOrderProductSearch] = useState('');
  const [orderId, setOrderId] = useState<string | null>(null);
  const [orderNumber, setOrderNumber] = useState<number | null>(null);
  const [addSizeRow, setAddSizeRow] = useState<{ productId: string, sizeId: string | null, quantity: number } | null>(null);

  const fetchSuppliers = async () => {
    try {
      const { data, error } = await supabase
        .from('suppliers')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setSuppliers(data || []);
      setFilteredSuppliers(data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSuppliers();
  }, []);

  useEffect(() => {
    const filtered = suppliers.filter(supplier => {
      const searchLower = searchQuery.toLowerCase();
      return (
        supplier.name.toLowerCase().includes(searchLower) ||
        supplier.phone.toLowerCase().includes(searchLower) ||
        supplier.email.toLowerCase().includes(searchLower) ||
        supplier.country.toLowerCase().includes(searchLower)
      );
    });
    setFilteredSuppliers(filtered);
  }, [searchQuery, suppliers]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (isEditMode && selectedSupplier) {
        const { error } = await supabase
          .from('suppliers')
          .update(formData)
          .eq('id', selectedSupplier.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('suppliers')
          .insert([formData]);

        if (error) throw error;
      }

      // Reset form and close modal
      setFormData({
        name: '',
        phone: '',
        email: '',
        country: ''
      });
      setIsModalOpen(false);
      setIsEditMode(false);
      setSelectedSupplier(null);
      
      // Refresh the table
      fetchSuppliers();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  const handleEdit = (supplier: Supplier) => {
    setSelectedSupplier(supplier);
    setFormData({
      name: supplier.name,
      phone: supplier.phone,
      email: supplier.email,
      country: supplier.country
    });
    setIsEditMode(true);
    setIsModalOpen(true);
  };

  const handleDelete = async () => {
    if (!selectedSupplier) return;

    try {
      const { error } = await supabase
        .from('suppliers')
        .delete()
        .eq('id', selectedSupplier.id);

      if (error) throw error;

      setShowDeleteConfirm(false);
      setSelectedSupplier(null);
      fetchSuppliers();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  const openDeleteConfirm = (supplier: Supplier) => {
    setSelectedSupplier(supplier);
    setShowDeleteConfirm(true);
  };

  const handleSupplierRowClick = async (supplier: Supplier) => {
    setSelectedSupplierForProducts(supplier);
    setIsDrawerOpen(true);
    setIsProductsLoading(true);
    try {
      const { data, error } = await supabase
        .from('products')
        .select(`
          id, 
          name, 
          image_url, 
          product_code, 
          category_id, 
          categories(name),
          dimensions
        `)
        .eq('supplier_id', supplier.id);
      if (error) throw error;
      // Map category name and dimensions
      const productsWithCategory = (data || []).map((p: any) => ({
        ...p,
        category_name: p.categories?.name || '',
        sizes: p.dimensions || []
      }));
      setSupplierProducts(productsWithCategory);
    } catch (err) {
      setSupplierProducts([]);
    } finally {
      setIsProductsLoading(false);
    }
  };

  const closeDrawer = () => {
    setIsDrawerOpen(false);
    setSelectedSupplierForProducts(null);
    setSupplierProducts([]);
  };

  const openOrderModal = async () => {
    if (!selectedSupplierForProducts) return;
    try {
      // Create the new order WITHOUT order_number (let DB sequence generate it)
      const { data: order, error } = await supabase
        .from('supplier_orders')
        .insert([
          {
            supplier_id: selectedSupplierForProducts.id
            // order_number is omitted, DB will generate
          }
        ])
        .select()
        .single();
      if (error) throw error;
      setOrderId(order.id);
      setOrderNumber(order.order_number);
      setIsOrderModalOpen(true);
    } catch (err) {
      console.error('שגיאה ביצירת הזמנה חדשה', err);
      alert('שגיאה ביצירת הזמנה חדשה');
    }
  };

  // Helper to merge duplicate items (same productId + selectedDimension)
  function mergeOrderItems(items: any[]): any[] {
    const merged: any[] = [];
    for (const item of items) {
      const existing = merged.find((m: any) => m.productId === item.productId && isEqual(m.selectedDimension, item.selectedDimension));
      if (existing) {
        existing.quantity += item.quantity;
      } else {
        merged.push({ ...item });
      }
    }
    return merged;
  }

  // Helper to save order items before export (store selected_dimension as JSON, no size_id)
  async function saveOrderAndExport(exportFn: (orderData: any, supplierName: string, orderNumber: number | null) => void) {
    if (!orderId || !selectedSupplierForProducts) {
      alert('שגיאה: לא נמצאה הזמנה פעילה');
      return;
    }
    try {
      // Merge duplicate items
      const mergedItems = mergeOrderItems(orderItems);
      // Add order items
      const orderItemsData = mergedItems.map(item => ({
        order_id: orderId,
        product_id: item.productId,
        quantity: item.quantity,
        selected_dimension: item.selectedDimension || null
      }));
      if (orderItemsData.length > 0) {
        const { error: itemsError } = await supabase
          .from('supplier_order_items')
          .insert(orderItemsData);
        if (itemsError) {
          console.error('שגיאה בשמירת פריטי הזמנה:', itemsError);
          alert('שגיאה בשמירת פריטי הזמנה');
          return;
        }
      }
      // Prepare orderData for export (use only selected_dimension)
      const orderData = mergedItems.map(item => {
        const dim = item.selectedDimension;
        let modelName = dim?.model || '';
        if (dim?.model && dim?.name) {
          modelName = `${dim.model} - ${dim.name}`;
        } else if (dim?.name && !dim?.model) {
          modelName = dim.name;
        }
        const width = dim?.width ?? '';
        const length = dim?.length ?? '';
        const height = dim?.height ?? '';
        return {
          modelName,
          dimensions: `${width}x${length}x${height}`,
          quantity: item.quantity
        };
      });
      exportFn(orderData, selectedSupplierForProducts.name, orderNumber);
    } catch (err) {
      console.error('שגיאה בשמירת ההזמנה:', err);
      alert('שגיאה בשמירת ההזמנה');
    }
  }

  if (loading) return <div className="p-4">Loading suppliers...</div>;
  if (error) return <div className="p-4 text-red-500">Error: {error}</div>;

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">ניהול ספקים</h1>
        <button
          onClick={() => {
            setIsEditMode(false);
            setSelectedSupplier(null);
            setFormData({
              name: '',
              phone: '',
              email: '',
              country: ''
            });
            setIsModalOpen(true);
          }}
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition-colors"
        >
          הוסף ספק
        </button>
      </div>

      {/* Search Input */}
      <div className="mb-6">
        <div className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="חיפוש לפי שם, טלפון, אימייל או מדינה..."
            className="w-full px-4 py-2 pr-12 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            dir="rtl"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
        </div>
      </div>

      {/* Suppliers Table */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">שם</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">טלפון</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">אימייל</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">מדינה</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">פעולות</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredSuppliers.map((supplier) => (
              <tr
                key={supplier.id}
                className="cursor-pointer hover:bg-blue-50 transition"
                onClick={() => handleSupplierRowClick(supplier)}
              >
                <td className="px-6 py-4 whitespace-nowrap">{supplier.name}</td>
                <td className="px-6 py-4 whitespace-nowrap">{supplier.phone}</td>
                <td className="px-6 py-4 whitespace-nowrap">{supplier.email}</td>
                <td className="px-6 py-4 whitespace-nowrap">{supplier.country}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex gap-2 justify-end">
                    <button
                      className="text-blue-500 hover:text-blue-700 mr-2"
                      onClick={e => { e.stopPropagation(); handleEdit(supplier); }}
                    >
                      <Edit2 className="inline w-4 h-4" />
                    </button>
                    <button
                      className="text-red-500 hover:text-red-700"
                      onClick={e => { e.stopPropagation(); openDeleteConfirm(supplier); }}
                    >
                      <Trash2 className="inline w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {filteredSuppliers.length === 0 && (
              <tr>
                <td colSpan={5} className="px-6 py-4 text-center text-gray-500">
                  לא נמצאו תוצאות
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Add/Edit Supplier Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">
              {isEditMode ? 'עריכת ספק' : 'הוספת ספק חדש'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">שם</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">טלפון</label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">אימייל</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">מדינה</label>
                <input
                  type="text"
                  name="country"
                  value={formData.country}
                  onChange={handleInputChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>
              <div className="flex justify-end space-x-3 mt-6">
                <button
                  type="button"
                  onClick={() => {
                    setIsModalOpen(false);
                    setIsEditMode(false);
                    setSelectedSupplier(null);
                  }}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                >
                  ביטול
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
                >
                  שמור
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg w-full max-w-md">
            <div className="flex items-center gap-3 mb-4">
              <AlertCircle className="w-6 h-6 text-red-500" />
              <h2 className="text-xl font-bold">אישור מחיקה</h2>
            </div>
            <p className="mb-6">
              האם אתה בטוח שברצונך למחוק את הספק "{selectedSupplier?.name}"?
            </p>
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => {
                  setShowDeleteConfirm(false);
                  setSelectedSupplier(null);
                }}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
              >
                ביטול
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600"
              >
                מחק
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Drawer for supplier products */}
      {isDrawerOpen && (
        <>
          {/* Overlay */}
          <div
            className="fixed inset-0 bg-black bg-opacity-40 z-40"
            onClick={closeDrawer}
          />
          {/* Drawer */}
          <div className="fixed top-0 right-0 h-full w-full sm:w-[480px] bg-white shadow-2xl z-50 flex flex-col transition-transform duration-300">
            <div className="flex items-center justify-between p-4 border-b">
              <h2 className="text-xl font-bold">מוצרים של {selectedSupplierForProducts?.name}</h2>
              <button onClick={closeDrawer} className="p-2 hover:bg-gray-100 rounded-full">
                <X className="w-6 h-6" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4">
              {isProductsLoading ? (
                <div className="text-center text-gray-500 py-10">טוען מוצרים...</div>
              ) : supplierProducts.length === 0 ? (
                <div className="text-center text-gray-400 py-10">אין מוצרים לספק זה</div>
              ) : (
                <>
                  <button
                    onClick={openOrderModal}
                    className="w-full mb-4 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
                  >
                    התחל הזמנה
                  </button>
                  <ul className="space-y-4">
                    {supplierProducts.map(product => (
                      <li key={product.id} className="flex items-center gap-4 bg-gray-50 rounded-lg p-3 shadow-sm">
                        <img
                          src={product.image_url || '/no-image.png'}
                          alt={product.name}
                          className="w-16 h-16 object-contain rounded bg-white border"
                        />
                        <div className="flex-1">
                          <div className="font-semibold text-lg">{product.name}</div>
                          <div className="text-sm text-gray-500">קוד: {product.product_code}</div>
                          {product.category_name && (
                            <div className="text-xs text-gray-400">קטגוריה: {product.category_name}</div>
                          )}
                        </div>
                      </li>
                    ))}
                  </ul>
                </>
              )}
            </div>
          </div>
        </>
      )}

      {/* Order Modal */}
      {isOrderModalOpen && selectedSupplierForProducts && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg w-full max-w-4xl max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between p-4 border-b">
              <h2 className="text-xl font-bold">הזמנה חדשה - {selectedSupplierForProducts.name}</h2>
              <button onClick={() => setIsOrderModalOpen(false)} className="p-2 hover:bg-gray-100 rounded-full">
                <X className="w-6 h-6" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Products List */}
                <div className="space-y-4">
                  <h3 className="font-semibold text-lg mb-2">מוצרים</h3>
                  <input
                    type="text"
                    value={orderProductSearch}
                    onChange={e => setOrderProductSearch(e.target.value)}
                    placeholder="חפש מוצר לפי שם, דגם או קוד..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-md mb-2"
                  />
                  {(supplierProducts.filter(product => {
                    const search = orderProductSearch.trim().toLowerCase();
                    if (!search) return true;
                    const name = product.name?.toLowerCase() || '';
                    const code = product.product_code?.toLowerCase() || '';
                    const hasModel = product.sizes && product.sizes.some(s => (s.model || '').toLowerCase().includes(search));
                    return name.includes(search) || code.includes(search) || hasModel;
                  })).map(product => (
                    <div key={product.id} className="flex flex-col gap-4 bg-gray-50 rounded-lg p-3">
                      <div className="flex items-center gap-4">
                        <img
                          src={product.image_url || '/no-image.png'}
                          alt={product.name}
                          className="w-16 h-16 object-contain rounded bg-white border"
                        />
                        <div className="flex-1">
                          <div className="font-semibold">{product.name}</div>
                          <div className="text-sm text-gray-500">קוד: {product.product_code}</div>
                        </div>
                      </div>
                      {/* Size Selection */}
                      <div className="space-y-2">
                        <label className="block text-sm font-medium text-gray-700">בחר מידה:</label>
                        <select
                          className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
                          onChange={(e) => {
                            const sizeId = e.target.value;
                            const size = product.sizes?.find(s => s.id === sizeId);
                            if (size) {
                              setOrderItems(prev => {
                                const existing = prev.find(item => item.productId === product.id && item.sizeId === sizeId);
                                if (existing) {
                                  return prev.map(item =>
                                    item.productId === product.id && item.sizeId === sizeId
                                      ? { ...item, selectedDimension: size }
                                      : item
                                  );
                                }
                                return [...prev, {
                                  productId: product.id,
                                  quantity: 0,
                                  sizeId,
                                  selectedDimension: size
                                }];
                              });
                            }
                          }}
                          value={orderItems.find(item => item.productId === product.id)?.sizeId || ''}
                        >
                          <option value="">בחר מידה</option>
                          {product.sizes?.map(size => (
                            <option key={size.id} value={size.id}>
                              {size.name ? size.name + ' - ' : ''}
                              {size.width ?? 0}x{size.length ?? 0}x{size.height ?? 0} (אורךxעומקxגובה)
                            </option>
                          ))}
                        </select>
                      </div>
                      {/* Quantity Input */}
                      <div className="flex items-center gap-2">
                        <label className="text-sm font-medium text-gray-700">כמות:</label>
                        <input
                          type="number"
                          min="0"
                          value={orderItems.find(item => item.productId === product.id)?.quantity || 0}
                          onChange={(e) => {
                            const quantity = parseInt(e.target.value) || 0;
                            setOrderItems(prev => {
                              const existing = prev.find(item => item.productId === product.id);
                              if (existing) {
                                return prev.map(item =>
                                  item.productId === product.id ? { ...item, quantity } : item
                                );
                              }
                              return [...prev, {
                                productId: product.id,
                                quantity,
                                sizeId: product.sizes?.[0]?.id,
                                selectedDimension: product.sizes?.[0] ? product.sizes[0] : undefined
                              }];
                            });
                          }}
                          className="w-20 px-2 py-1 border rounded"
                        />
                        <button
                          onClick={() => {
                            setOrderItems(prev => prev.filter(item => item.productId !== product.id));
                          }}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      {/* Add extra size row UI */}
                      <button
                        className="text-blue-600 underline text-xs mt-1 self-start"
                        onClick={() => setAddSizeRow({ productId: product.id, sizeId: null, quantity: 1 })}
                      >
                        הוסף מידה נוספת
                      </button>
                      {addSizeRow && addSizeRow.productId === product.id && (
                        <div className="flex items-center gap-2 mt-2">
                          <select
                            className="border rounded px-2 py-1"
                            value={addSizeRow.sizeId || ''}
                            onChange={e => setAddSizeRow(row => row ? { ...row, sizeId: e.target.value } : null)}
                          >
                            <option value="">בחר מידה</option>
                            {product.sizes?.map(size => (
                              <option key={size.id} value={size.id}>
                                {size.name ? size.name + ' - ' : ''}
                                {size.width ?? 0}x{size.length ?? 0}x{size.height ?? 0} (אורךxעומקxגובה)
                              </option>
                            ))}
                          </select>
                          <input
                            type="number"
                            min="1"
                            value={addSizeRow.quantity}
                            onChange={e => setAddSizeRow(row => row ? { ...row, quantity: parseInt(e.target.value) || 1 } : null)}
                            className="w-16 px-2 py-1 border rounded"
                          />
                          <button
                            className="bg-blue-500 text-white px-3 py-1 rounded"
                            disabled={!addSizeRow.sizeId}
                            onClick={() => {
                              if (!addSizeRow || !addSizeRow.sizeId) return;
                              const size = product.sizes?.find((s: any) => s.id === addSizeRow.sizeId);
                              if (!size) return;
                              setOrderItems(items => [
                                ...items,
                                {
                                  productId: product.id,
                                  quantity: addSizeRow.quantity,
                                  sizeId: addSizeRow.sizeId as string,
                                  selectedDimension: size
                                }
                              ]);
                              setAddSizeRow(null);
                            }}
                          >
                            הוסף
                          </button>
                          <button
                            className="text-gray-500 px-2"
                            onClick={() => setAddSizeRow(null)}
                          >
                            בטל
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {/* Order Summary */}
                <div className="bg-gray-50 rounded-lg p-4 sticky top-4 max-h-[80vh] overflow-y-auto">
                  <h3 className="font-semibold text-lg mb-4">סיכום הזמנה</h3>
                  {orderItems.length === 0 ? (
                    <p className="text-gray-500">אין מוצרים בהזמנה</p>
                  ) : (
                    <>
                      <div className="space-y-2 mb-4">
                        {orderItems.map(item => {
                          const dim = item.selectedDimension;
                          return (
                            <div key={item.productId} className="flex flex-col gap-1">
                              <div className="flex justify-between items-center">
                                <span className="font-medium">{supplierProducts.find(p => p.id === item.productId)?.name}</span>
                                <span>{item.quantity}</span>
                              </div>
                              {dim?.model && (
                                <div className="text-sm text-gray-500">דגם: {dim.model}</div>
                              )}
                              {dim?.name && (
                                <div className="text-sm text-gray-500">שם: {dim.name}</div>
                              )}
                              {dim?.width !== undefined && (
                                <div className="text-sm text-gray-500">אורך: {dim.width}</div>
                              )}
                              {dim?.length !== undefined && (
                                <div className="text-sm text-gray-500">עומק: {dim.length}</div>
                              )}
                              {dim?.height !== undefined && (
                                <div className="text-sm text-gray-500">גובה: {dim.height}</div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                      <div className="border-t pt-4 space-y-4">
                        <div className="flex gap-2">
                          <button
                            onClick={() => saveOrderAndExport(exportOrderToPDF)}
                            className="flex-1 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
                          >
                            ייצא ל-PDF
                          </button>
                          <button
                            onClick={() => saveOrderAndExport(exportOrderToCSV)}
                            className="flex-1 bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition-colors"
                          >
                            ייצא ל-CSV
                          </button>
                        </div>
                        <button
                          onClick={async () => {
                            if (!orderId || !selectedSupplierForProducts) {
                              alert('שגיאה: לא נמצאה הזמנה פעילה');
                              return;
                            }
                            try {
                              // Add order items
                              const orderItemsData = orderItems.map(item => ({
                                order_id: orderId,
                                product_id: item.productId,
                                quantity: item.quantity,
                                selected_dimension: item.selectedDimension || null
                              }));
                              if (orderItemsData.length > 0) {
                                const { error: itemsError } = await supabase
                                  .from('supplier_order_items')
                                  .insert(orderItemsData);
                                if (itemsError) {
                                  console.error('שגיאה בשמירת פריטי הזמנה:', itemsError);
                                  alert('שגיאה בשמירת פריטי הזמנה');
                                  return;
                                }
                              }
                              setIsOrderModalOpen(false);
                              setOrderItems([]);
                              setOrderId(null);
                            } catch (error) {
                              console.error('שגיאה בשמירת ההזמנה:', error);
                              alert('שגיאה בשמירת ההזמנה');
                            }
                          }}
                          className="w-full bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
                        >
                          שמור הזמנה
                        </button>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
} 