import React, {
  ChangeEvent,
  useEffect,
  useRef,
  useState,
} from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { CheckCircle, Truck, X as XIcon, Trash2 } from 'lucide-react';
import {
  addOrderItems,
  createCustomer,
  deleteOrder,
  deleteOrderItem,
  fetchCustomers,
  getOrderById,
  searchProductsForOrder,
  setOrderStatus,
  updateOrder,
  updateOrderItem,
} from '../../lib/db.orders';
import {
  Customer,
  CustomerOrderItem,
  OrderProductOption,
  OrderStatus,
  OrderWithItems,
} from '../../types/orders';
import { ToastViewport, useToast } from '../../hooks/useToast';
import { fetchWarehousesList } from '../../lib/db.inventory';
import type { Warehouse } from '../../types/inventory';

const statusLabels: Record<OrderStatus, string> = {
  Draft: 'טיוטה',
  Confirmed: 'מאושרת',
  Fulfilled: 'סופקה',
  Cancelled: 'בוטלה',
};

const statusActions: Array<{
  status: OrderStatus;
  label: string;
  description: string;
  className: string;
}> = [
  {
    status: 'Confirmed',
    label: 'אישור הזמנה',
    description: 'אישור רשמי',
    className:
      'border border-blue-300 text-blue-700 bg-white hover:bg-blue-50',
  },
  {
    status: 'Fulfilled',
    label: 'סופק',
    description: 'הזמנה הושלמה',
    className:
      'border border-green-300 text-green-700 bg-white hover:bg-green-50',
  },
  {
    status: 'Cancelled',
    label: 'ביטול',
    description: 'הזמנה לא תסופק',
    className:
      'border border-red-300 text-red-700 bg-white hover:bg-red-50',
  },
];

function formatCurrency(value: number) {
  return new Intl.NumberFormat('he-IL', {
    style: 'currency',
    currency: 'ILS',
    maximumFractionDigits: 2,
  }).format(value);
}

function normalizeDateInput(value?: string | null) {
  if (!value) return '';
  return value.slice(0, 10);
}

type ItemPatchInput = Partial<
  Pick<CustomerOrderItem, 'product_name' | 'variant' | 'qty' | 'unit_price'>
>;

interface CustomerSelectProps {
  currentCustomer: Customer | null;
  onSelectCustomer: (customer: Customer | null) => void;
  onCreateCustomer: (params: { name: string; phone?: string }) => Promise<void>;
}

function CustomerSelect({
  currentCustomer,
  onSelectCustomer,
  onCreateCustomer,
}: CustomerSelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [newCustomerName, setNewCustomerName] = useState('');
  const [newCustomerPhone, setNewCustomerPhone] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { data: customers = [], isLoading } = useQuery({
    queryKey: ['customers', 'order-edit', searchTerm],
    queryFn: () => fetchCustomers(searchTerm),
    enabled: isOpen,
  });

  const closePicker = () => {
    setIsOpen(false);
    setSearchTerm('');
  };

  const openCreateModal = () => {
    setIsCreateModalOpen(true);
    setNewCustomerName('');
    setNewCustomerPhone('');
  };

  const closeCreateModal = () => {
    setIsCreateModalOpen(false);
    setIsSubmitting(false);
  };

  const handleCreateCustomer = async () => {
    if (!newCustomerName.trim()) {
      return;
    }
    setIsSubmitting(true);
    try {
      await onCreateCustomer({
        name: newCustomerName.trim(),
        phone: newCustomerPhone.trim() ? newCustomerPhone.trim() : undefined,
      });
      closeCreateModal();
      setIsOpen(false);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setIsOpen(true)}
        className="w-full rounded-lg border border-gray-300 px-4 py-3 text-right transition hover:border-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-200"
      >
        <div className="text-sm text-gray-500">לקוח</div>
        <div className="text-base font-semibold text-gray-900">
          {currentCustomer?.name ?? 'בחר לקוח...'}
        </div>
        {currentCustomer?.phone && (
          <div className="text-xs text-gray-500">{currentCustomer.phone}</div>
        )}
      </button>

      {isOpen && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/40 px-4" dir="rtl">
          <div className="w-full max-w-2xl rounded-2xl bg-white shadow-2xl">
            <div className="flex items-center justify-between border-b px-6 py-4">
              <h2 className="text-lg font-semibold">בחירת לקוח</h2>
              <button
                type="button"
                onClick={closePicker}
                className="text-gray-500 transition hover:text-gray-700"
              >
                ✕
              </button>
            </div>
            <div className="space-y-4 px-6 py-5">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(event) => setSearchTerm(event.target.value)}
                  placeholder="הקלד שם או טלפון..."
                  className="w-full rounded-lg border border-gray-300 px-4 py-2 text-right focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
                />
                <button
                  type="button"
                  onClick={openCreateModal}
                  className="whitespace-nowrap rounded-lg bg-green-600 px-4 py-2 text-sm font-semibold text-white hover:bg-green-700"
                >
                  לקוח חדש
                </button>
              </div>
              <div className="max-h-80 overflow-y-auto rounded-xl border border-gray-100">
                {isLoading ? (
                  <div className="py-10 text-center text-sm text-gray-500">
                    טוען לקוחות...
                  </div>
                ) : customers.length === 0 ? (
                  <div className="py-10 text-center text-sm text-gray-500">
                    לא נמצאו לקוחות תואמים.
                  </div>
                ) : (
                  <ul className="space-y-2 p-4">
                    {customers.map((customer) => (
                      <li key={customer.id}>
                        <button
                          type="button"
                          onClick={() => {
                            onSelectCustomer(customer);
                            closePicker();
                          }}
                          className={`flex w-full flex-col rounded-xl border px-4 py-3 text-right transition ${
                            currentCustomer?.id === customer.id
                              ? 'border-blue-400 bg-blue-50 text-blue-800'
                              : 'border-transparent bg-white hover:border-blue-200 hover:bg-blue-50'
                          }`}
                        >
                          <span className="text-sm font-semibold">{customer.name}</span>
                          {customer.phone && (
                            <span className="text-xs text-gray-500">{customer.phone}</span>
                          )}
                        </button>
                      </li>
                    ))}
                    <li>
                      <button
                        type="button"
                        onClick={() => {
                          onSelectCustomer(null);
                          closePicker();
                        }}
                        className="flex w-full flex-col rounded-xl border border-dashed border-gray-300 px-4 py-3 text-right text-sm text-gray-600 hover:border-blue-300 hover:text-blue-700"
                      >
                        ללא לקוח
                      </button>
                    </li>
                  </ul>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4" dir="rtl">
          <div className="w-full max-w-md rounded-2xl bg-white shadow-2xl">
            <div className="flex items-center justify-between border-b px-6 py-4">
              <h3 className="text-lg font-semibold">יצירת לקוח חדש</h3>
              <button
                type="button"
                onClick={closeCreateModal}
                className="text-gray-500 transition hover:text-gray-700"
              >
                ✕
              </button>
            </div>
            <div className="space-y-4 px-6 py-5">
              <div>
                <label className="mb-1 block text-sm font-medium text-gray-700">
                  שם
                </label>
                <input
                  value={newCustomerName}
                  onChange={(event) => setNewCustomerName(event.target.value)}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2 text-right focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
                  placeholder="שם מלא"
                />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-gray-700">
                  טלפון
                </label>
                <input
                  value={newCustomerPhone}
                  onChange={(event) => setNewCustomerPhone(event.target.value)}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2 text-right focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
                  placeholder="טלפון (לא חובה)"
                />
              </div>
            </div>
            <div className="flex items-center justify-between border-t px-6 py-4">
              <button
                type="button"
                onClick={closeCreateModal}
                className="rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
                disabled={isSubmitting}
              >
                ביטול
              </button>
              <button
                type="button"
                onClick={handleCreateCustomer}
                className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-70"
                disabled={isSubmitting || !newCustomerName.trim()}
              >
                שמור
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function CustomerOrderDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { toasts, dismissToast, helpers } = useToast();

  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [expectedDate, setExpectedDate] = useState('');
  const [notes, setNotes] = useState('');
  const [itemsState, setItemsState] = useState<CustomerOrderItem[]>([]);
  const [newItem, setNewItem] = useState({
    product_name: '',
    variant: '',
    _model: '',
    _size: '',
    _image: undefined as string | undefined,
    qty: 1,
    unit_price: 0,
  });
  const [productPickerState, setProductPickerState] = useState<{
    open: boolean;
    target: 'new' | string | null;
  }>({ open: false, target: null });
  const [productSearchTerm, setProductSearchTerm] = useState('');
  const [sizePickerProduct, setSizePickerProduct] = useState<OrderProductOption | null>(null);
  const [showServiceForm, setShowServiceForm] = useState(false);
  const [serviceName, setServiceName] = useState('');
  const [servicePrice, setServicePrice] = useState<number>(0);
  // Warehouses for item linking
  const { data: warehouses = [] } = useQuery({
    queryKey: ['warehouses-list'],
    queryFn: fetchWarehousesList,
    staleTime: 300_000,
  });
  const [selectedWarehouseForPicker, setSelectedWarehouseForPicker] = useState<string>('');
  useEffect(() => {
    if (!selectedWarehouseForPicker && warehouses.length > 0) {
      setSelectedWarehouseForPicker(warehouses[0].id);
    }
  }, [warehouses, selectedWarehouseForPicker]);

  const pendingOrderPatch = useRef<Record<string, unknown>>({});
  const orderUpdateTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pendingItemPatch = useRef<Record<string, ItemPatchInput>>({});
  const itemUpdateTimeouts = useRef<Record<string, ReturnType<typeof setTimeout>>>({});

  const orderQuery = useQuery({
    queryKey: ['customer-order', id],
    queryFn: () => getOrderById(id!),
    enabled: Boolean(id),
  });

  const {
    data: productOptions = [],
    isLoading: isProductLoading,
    isError: isProductError,
    error: productError,
  } = useQuery({
    queryKey: ['order-products', productSearchTerm],
    queryFn: () => searchProductsForOrder(productSearchTerm),
    enabled: productPickerState.open,
  });

  useEffect(() => {
    if (orderQuery.data) {
      const { order, items } = orderQuery.data;
      setSelectedCustomer(order.customer ?? null);
      setExpectedDate(normalizeDateInput(order.expected_delivery_date));
      setNotes(order.notes ?? '');
      setItemsState(items);
    }
  }, [orderQuery.data]);

  const updateOrderMutation = useMutation({
    mutationFn: (patch: Record<string, unknown>) => updateOrder(id!, patch),
    onSuccess: (data) => {
      queryClient.setQueryData<OrderWithItems>(['customer-order', id], (current) => {
        if (!current) return current;
        return {
          order: { ...data, customer: data.customer ?? selectedCustomer ?? null },
          items: current.items,
        };
      });
      helpers.success('הזמנה עודכנה');
      orderQuery.refetch();
    },
    onError: (error) => {
      helpers.error(
        error instanceof Error ? error.message : 'אירעה שגיאה בשמירת ההזמנה',
      );
    },
  });

  const setStatusMutation = useMutation({
    mutationFn: (status: OrderStatus) => setOrderStatus(id!, status),
    onSuccess: (order) => {
      queryClient.setQueryData<OrderWithItems>(['customer-order', id], (current) => {
        if (!current) return current;
        return {
          order: { ...order, customer: current.order.customer },
          items: current.items,
        };
      });
      helpers.success(`סטטוס עודכן ל-${statusLabels[order.status]}`);
      queryClient.invalidateQueries({ queryKey: ['customer-orders'] });
    },
    onError: (error) => {
      helpers.error(
        error instanceof Error ? error.message : 'אירעה שגיאה בעדכון הסטטוס',
      );
    },
  });
  const deleteOrderMutation = useMutation({
    mutationFn: () => deleteOrder(id!),
    onSuccess: () => {
      helpers.success('ההזמנה נמחקה');
      queryClient.invalidateQueries({ queryKey: ['customer-orders'] });
      navigate('/customer-orders');
    },
    onError: (error) => {
      helpers.error(error instanceof Error ? error.message : 'שגיאה במחיקת ההזמנה');
    },
  });

  const addItemMutation = useMutation({
    mutationFn: () =>
      addOrderItems(id!, [
        {
          product_name: newItem.product_name.trim(),
          variant: buildVariantMeta({
            model: newItem._model || (newItem.variant || ''),
            size: newItem._size || '',
            image_url: newItem._image || '',
            warehouse_id: selectedWarehouseForPicker || '',
            warehouse_name: getWarehouseName(selectedWarehouseForPicker) || '',
          }) || undefined,
          qty: newItem.qty,
          unit_price: newItem.unit_price,
        },
      ]),
    onSuccess: () => {
      helpers.success('השורה נשמרה');
      setNewItem({
        product_name: '',
        variant: '',
        _model: '',
        _size: '',
        _image: undefined,
        qty: 1,
        unit_price: 0,
      });
      queryClient.invalidateQueries({ queryKey: ['customer-order', id] });
    },
    onError: (error) => {
      helpers.error(
        error instanceof Error ? error.message : 'אירעה שגיאה בשמירת הפריט',
      );
    },
  });

  const addServiceMutation = useMutation({
    mutationFn: () =>
      addOrderItems(id!, [
        {
          product_name: serviceName.trim(),
          variant: 'שירות',
          qty: 1,
          unit_price: Number(servicePrice) || 0,
        },
      ]),
    onSuccess: () => {
      helpers.success('הובלה/שירות נוסף להזמנה');
      setServiceName('');
      setServicePrice(0);
      setShowServiceForm(false);
      queryClient.invalidateQueries({ queryKey: ['customer-order', id] });
    },
    onError: (error) => {
      helpers.error(
        error instanceof Error ? error.message : 'אירעה שגיאה בהוספת השירות',
      );
    },
  });

  // יצירת פריט חדש ישירות מבחירת מוצר (ללא שורה ריקה)
  const createItemFromSelection = useMutation({
    mutationFn: (payload: {
      product_name: string;
      variant?: string;
      qty: number;
      unit_price: number;
    }) => addOrderItems(id!, [payload]),
    onSuccess: () => {
      helpers.success('השורה נשמרה');
      queryClient.invalidateQueries({ queryKey: ['customer-order', id] });
      closeProductPicker();
      setSizePickerProduct(null);
    },
    onError: (error) => {
      helpers.error(
        error instanceof Error ? error.message : 'אירעה שגיאה בשמירת הפריט',
      );
    },
  });

  const updateItemMutation = useMutation({
    mutationFn: ({ itemId, patch }: { itemId: string; patch: ItemPatchInput }) =>
      updateOrderItem(itemId, patch),
    onSuccess: (updatedItem) => {
      helpers.success('השורה נשמרה');
      setItemsState((current) =>
        current.map((item) => (item.id === updatedItem.id ? updatedItem : item)),
      );
      queryClient.invalidateQueries({ queryKey: ['customer-order', id] });
    },
    onError: (error) => {
      helpers.error(
        error instanceof Error ? error.message : 'אירעה שגיאה בשמירת הפריט',
      );
      orderQuery.refetch();
    },
  });

  const deleteItemMutation = useMutation({
    mutationFn: (itemId: string) => deleteOrderItem(itemId),
    onSuccess: (_, itemId) => {
      helpers.success('הפריט הוסר');
      setItemsState((current) => current.filter((item) => item.id !== itemId));
      queryClient.invalidateQueries({ queryKey: ['customer-order', id] });
    },
    onError: (error) => {
      helpers.error(
        error instanceof Error ? error.message : 'אירעה שגיאה במחיקת הפריט',
      );
    },
  });

  const createCustomerMutation = useMutation({
    mutationFn: (payload: { name: string; phone?: string }) => createCustomer(payload),
    onSuccess: (customer) => {
      setSelectedCustomer(customer);
      scheduleOrderPatch({ customer_id: customer.id });
      helpers.success('לקוח חדש נוצר והוצמד להזמנה');
    },
    onError: (error) => {
      helpers.error(
        error instanceof Error ? error.message : 'אירעה שגיאה ביצירת הלקוח',
      );
    },
  });

  const scheduleOrderPatch = (patch: Record<string, unknown>) => {
    pendingOrderPatch.current = { ...pendingOrderPatch.current, ...patch };
    if (orderUpdateTimeout.current) {
      clearTimeout(orderUpdateTimeout.current);
    }
    orderUpdateTimeout.current = setTimeout(() => {
      const payload = pendingOrderPatch.current;
      pendingOrderPatch.current = {};
      updateOrderMutation.mutate(payload);
    }, 400);
  };

  const openProductPicker = (target: 'new' | string) => {
    setProductPickerState({ open: true, target });
    setProductSearchTerm('');
  };

  const closeProductPicker = () => {
    setProductPickerState({ open: false, target: null });
    setProductSearchTerm('');
  };

  const handleProductPicked = (product: OrderProductOption) => {
    // If product has multiple sizes/dimensions -> open secondary picker
    const hasSizes =
      Array.isArray(product.dimensions) && product.dimensions.length > 0;
    if (hasSizes) {
      setSizePickerProduct(product);
      return;
    }

    if (productPickerState.target === 'new') {
      // יצירה מיידית של פריט חדש (כמות 1, מחיר 0)
      createItemFromSelection.mutate({
        product_name: product.name,
        variant: buildVariantMeta({
          model: product.product_code || '',
          size: '',
          image_url: product.image_url || '',
          warehouse_id: selectedWarehouseForPicker || '',
          warehouse_name: getWarehouseName(selectedWarehouseForPicker) || '',
        }),
        qty: 1,
        unit_price: 0,
      });
      return;
    } else if (productPickerState.target) {
      const targetId = productPickerState.target;
      setItemsState((current) =>
        current.map((item) => {
          if (item.id !== targetId) {
            return item;
          }
          const updatedItem: CustomerOrderItem = {
            ...item,
            product_name: product.name,
            variant: buildVariantMeta({
              model: product.product_code || '',
              size: '',
              image_url: product.image_url || '',
              warehouse_id: selectedWarehouseForPicker || '',
              warehouse_name: getWarehouseName(selectedWarehouseForPicker) || '',
            }),
          };
          return updatedItem;
        }),
      );
      scheduleItemPatch(targetId, {
        product_name: product.name,
        variant: buildVariantMeta({
          model: product.product_code || '',
          size: '',
          image_url: product.image_url || '',
          warehouse_id: selectedWarehouseForPicker || '',
          warehouse_name: getWarehouseName(selectedWarehouseForPicker) || '',
        }),
      });
    }
    closeProductPicker();
  };

  const scheduleItemPatch = (itemId: string, patch: ItemPatchInput) => {
    pendingItemPatch.current[itemId] = {
      ...(pendingItemPatch.current[itemId] ?? {}),
      ...patch,
    };
    if (itemUpdateTimeouts.current[itemId]) {
      clearTimeout(itemUpdateTimeouts.current[itemId]);
    }
    itemUpdateTimeouts.current[itemId] = setTimeout(() => {
      const payload = pendingItemPatch.current[itemId];
      delete pendingItemPatch.current[itemId];
      updateItemMutation.mutate({ itemId, patch: payload });
    }, 400);
  };

  const handleItemModelChange = (itemId: string, value: string) => {
    setItemsState((current) =>
      current.map((item) => {
        if (item.id !== itemId) return item;
        const meta = parseVariantMeta(item.variant);
        return { ...item, variant: buildVariantMeta({ ...meta, model: value }) };
      }),
    );
    const meta = parseVariantMeta(itemsState.find((i) => i.id === itemId)?.variant);
    scheduleItemPatch(itemId, { variant: buildVariantMeta({ ...meta, model: value }) });
  };

  const handleItemSizeChange = (itemId: string, value: string) => {
    setItemsState((current) =>
      current.map((item) => {
        if (item.id !== itemId) return item;
        const meta = parseVariantMeta(item.variant);
        return { ...item, variant: buildVariantMeta({ ...meta, size: value }) };
      }),
    );
    const meta = parseVariantMeta(itemsState.find((i) => i.id === itemId)?.variant);
    scheduleItemPatch(itemId, { variant: buildVariantMeta({ ...meta, size: value }) });
  };
  const handleItemWarehouseChange = (itemId: string, warehouseId: string) => {
    setItemsState((current) =>
      current.map((item) => {
        if (item.id !== itemId) return item;
        const meta = parseVariantMeta(item.variant);
        const whName = getWarehouseName(warehouseId);
        return { ...item, variant: buildVariantMeta({ ...meta, warehouse_id: warehouseId, warehouse_name: whName }) };
      }),
    );
    const meta = parseVariantMeta(itemsState.find((i) => i.id === itemId)?.variant);
    scheduleItemPatch(itemId, { variant: buildVariantMeta({ ...meta, warehouse_id: warehouseId, warehouse_name: getWarehouseName(warehouseId) }) });
  };

  const handleExpectedDateChange = (event: ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;
    setExpectedDate(value);
    scheduleOrderPatch({
      expected_delivery_date: value || null,
    });
  };

  const handleNotesChange = (event: ChangeEvent<HTMLTextAreaElement>) => {
    const value = event.target.value;
    setNotes(value);
    scheduleOrderPatch({
      notes: value || null,
    });
  };

  const handleCustomerSelect = (customer: Customer | null) => {
    setSelectedCustomer(customer);
    scheduleOrderPatch({
      customer_id: customer?.id ?? null,
    });
  };

  // Store "דגם" + "מידה" + "תמונה" + "מחסן" בתוך variant כ-JSON
  type VariantMeta = { model?: string; size?: string; image_url?: string; warehouse_id?: string; warehouse_name?: string };
  const parseVariantMeta = (variant?: string | null): VariantMeta => {
    if (!variant) return {};
    try {
      const meta = JSON.parse(variant);
      if (meta && typeof meta === 'object') {
        return {
          model: typeof meta.model === 'string' ? meta.model : undefined,
          size: typeof meta.size === 'string' ? meta.size : undefined,
          image_url: typeof meta.image_url === 'string' ? meta.image_url : undefined,
          warehouse_id: typeof meta.warehouse_id === 'string' ? meta.warehouse_id : undefined,
          warehouse_name: typeof meta.warehouse_name === 'string' ? meta.warehouse_name : undefined,
        };
      }
    } catch {}
    // תומך לאחור: אם נשמר טקסט פשוט, נתייחס אליו כדגם
    return { model: variant };
  };
  const buildVariantMeta = (meta: VariantMeta): string => {
    return JSON.stringify({
      model: meta.model || '',
      size: meta.size || '',
      image_url: meta.image_url || '',
      warehouse_id: meta.warehouse_id || '',
      warehouse_name: meta.warehouse_name || '',
    });
  };
  const getWarehouseById = (id?: string) => (warehouses || []).find(w => w.id === id);
  const getWarehouseName = (id?: string) => getWarehouseById(id || '')?.name || '';

  const handleItemFieldChange = (
    itemId: string,
    field: keyof ItemPatchInput,
    value: string,
  ) => {
    const transformedValue =
      field === 'qty' || field === 'unit_price'
        ? Number(value) || 0
        : field === 'variant'
        ? value.trim() || null
        : value;

    setItemsState((current) =>
      current.map((item) =>
        item.id === itemId
          ? {
              ...item,
              [field]: transformedValue as never,
            }
          : item,
      ),
    );

    scheduleItemPatch(itemId, {
      [field]: transformedValue,
    });
  };

  const handleAddItem = () => {
    // פתיחת בוחר מוצר להוספה מהירה (אין שורה ריקה)
    openProductPicker('new');
  };

  const orderData = orderQuery.data?.order;

  const totalAmount = orderData?.total_amount ?? 0;
  const vatAmount = totalAmount * 0.18;
  const totalWithVat = totalAmount + vatAmount;
  const currentStatus = orderData?.status ?? 'Draft';

  const statusBadgeClass =
    currentStatus === 'Draft'
      ? 'bg-gray-100 text-gray-700 border border-gray-200'
      : currentStatus === 'Confirmed'
      ? 'bg-blue-100 text-blue-800 border border-blue-200'
      : currentStatus === 'Fulfilled'
      ? 'bg-green-100 text-green-800 border border-green-200'
      : 'bg-red-100 text-red-800 border border-red-200';

  const isLoading = orderQuery.isLoading;

  const handleBackToList = () => {
    navigate('/customer-orders');
  };

  if (orderQuery.isError) {
    return (
      <div className="space-y-4" dir="rtl">
        <button
          type="button"
          onClick={handleBackToList}
          className="rounded-lg border border-gray-300 px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
        >
          חזרה לרשימת ההזמנות
        </button>
        <div className="rounded-2xl border border-red-200 bg-red-50 p-6 text-right text-red-700">
          אירעה שגיאה בטעינת ההזמנה
        </div>
      </div>
    );
  }

  if (isLoading || !orderData) {
    return (
      <div className="py-20 text-center text-gray-500" dir="rtl">
        טוען נתוני הזמנה...
      </div>
    );
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header like the reference design */}
      <div className="flex flex-col gap-4">
        {/* Breadcrumb + date */}
        <div className="flex items-center gap-2 text-sm text-gray-500">
          <button
            type="button"
            onClick={handleBackToList}
            className="hover:text-blue-600 transition-colors flex items-center gap-1"
            title="חזרה לרשימת ההזמנות"
          >
            <span className="inline-block">←</span>
            חזרה לרשימת ההזמנות
          </button>
          <span className="text-gray-300">|</span>
          <span className="flex items-center gap-1">
            {new Date(orderData.created_at).toLocaleDateString('he-IL')}
          </span>
        </div>

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          {/* Title + status */}
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-bold text-slate-800">
              הזמנה #{orderData.id.slice(0, 8).toUpperCase()}
            </h1>
            <span
              className={`px-3 py-1 rounded-full text-xs font-bold ${statusBadgeClass}`}
            >
              {statusLabels[currentStatus]}
            </span>
          </div>

          {/* Actions */}
          <div className="flex flex-wrap items-center gap-3">
            {/* Primary: אישור הזמנה */}
            <button
              type="button"
              className="inline-flex items-center gap-2 rounded-full bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 text-sm font-bold shadow"
              onClick={() => setStatusMutation.mutate('Confirmed')}
              disabled={setStatusMutation.isPending || currentStatus === 'Confirmed'}
            >
              אישור הזמנה
              <CheckCircle className="h-4 w-4" />
            </button>

            {/* Supplied: סופק */}
            <button
              type="button"
              className="inline-flex items-center gap-2 rounded-full text-emerald-700 bg-emerald-50 border border-emerald-200 px-5 py-2.5 text-sm font-bold shadow-sm hover:bg-emerald-100"
              onClick={() => setStatusMutation.mutate('Fulfilled')}
              disabled={setStatusMutation.isPending || currentStatus === 'Fulfilled'}
            >
              סופק
              <Truck className="h-4 w-4" />
            </button>

            {/* Cancel: ביטול */}
            <button
              type="button"
              className="inline-flex items-center gap-2 rounded-full text-slate-700 bg-white border border-gray-300 px-5 py-2.5 text-sm font-bold hover:bg-gray-50 shadow-sm"
              onClick={() => setStatusMutation.mutate('Cancelled')}
              disabled={setStatusMutation.isPending || currentStatus === 'Cancelled'}
            >
              ביטול
              <XIcon className="h-4 w-4" />
            </button>

            {/* Divider */}
            <div className="h-8 w-px bg-gray-200 mx-2 hidden lg:block" />

            {/* Delete: מחק הזמנה */}
            <button
              className="inline-flex items-center gap-2 px-4 py-2.5 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors text-sm font-bold"
              type="button"
              onClick={() => {
                if (confirm('למחוק את ההזמנה? הפעולה אינה הפיכה.')) {
                  deleteOrderMutation.mutate();
                }
              }}
              disabled={deleteOrderMutation.isPending}
              title="מחק הזמנה"
            >
              מחק הזמנה
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[3fr,2fr]">
        <div className="space-y-6">
          <section className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
            <h2 className="text-xl font-semibold text-gray-900">פרטי הזמנה</h2>
            <div className="mt-6 grid gap-6 md:grid-cols-2">
              <CustomerSelect
                currentCustomer={selectedCustomer}
                onSelectCustomer={handleCustomerSelect}
                onCreateCustomer={async (payload) => createCustomerMutation.mutateAsync(payload)}
              />
              <div>
                <label className="mb-2 block text-sm font-medium text-gray-700">
                  תאריך יעד
                </label>
                <input
                  type="date"
                  value={expectedDate}
                  onChange={handleExpectedDateChange}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2 text-right focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
                />
              </div>
              <div className="md:col-span-2">
                <label className="mb-2 block text-sm font-medium text-gray-700">
                  הערות
                </label>
                <textarea
                  value={notes}
                  onChange={handleNotesChange}
                  placeholder="הקלד הערות להזמנה..."
                  rows={4}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2 text-right focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
                />
              </div>
            </div>
          </section>

          <section className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
            <div className="flex items-center justify-between gap-3">
              <h2 className="text-xl font-semibold text-gray-900">מוצרים בהזמנה</h2>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowServiceForm((v) => !v)}
                  className="rounded-lg border border-blue-200 px-3 py-2 text-sm font-semibold text-blue-600 hover:bg-blue-50"
                >
                  {showServiceForm ? 'בטל הוספת שירות' : '+ הוסף הובלה/שירות'}
                </button>
                <button
                  type="button"
                  onClick={handleAddItem}
                  className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-60"
                  disabled={createItemFromSelection.isPending}
                >
                  + הוסף מוצר
                </button>
              </div>
            </div>
            {showServiceForm && (
              <div className="mt-3 rounded-xl border border-gray-200 bg-blue-50/30 p-4">
                <div className="grid gap-3 md:grid-cols-3">
                  <div className="md:col-span-2">
                    <label className="mb-1 block text-xs text-gray-600">תיאור שירות/הובלה</label>
                    <input
                      value={serviceName}
                      onChange={(e) => setServiceName(e.target.value)}
                      placeholder="למשל: הובלה עד בית הלקוח / התקנה"
                      className="w-full rounded-lg border border-gray-300 px-3 py-2 text-right focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs text-gray-600">מחיר (₪)</label>
                    <input
                      type="number"
                      min={0}
                      step="0.01"
                      value={servicePrice}
                      onChange={(e) => setServicePrice(Number(e.target.value))}
                      className="w-full rounded-lg border border-gray-300 px-3 py-2 text-right focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
                    />
                  </div>
                </div>
                <div className="mt-3 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowServiceForm(false)}
                    className="rounded-lg border border-gray-300 px-3 py-2 text-xs text-gray-700 hover:bg-gray-50"
                  >
                    ביטול
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (!serviceName.trim()) {
                        helpers.error('אנא הזן תיאור שירות');
                        return;
                      }
                      if ((Number(servicePrice) || 0) < 0) {
                        helpers.error('מחיר חייב להיות מספר חיובי');
                        return;
                      }
                      addServiceMutation.mutate();
                    }}
                    className="rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700 disabled:opacity-60"
                    disabled={addServiceMutation.isPending}
                  >
                    הוסף שירות
                  </button>
                </div>
              </div>
            )}
            <div className="mt-4 grid grid-cols-1 gap-4">
              {itemsState.length === 0 && (
                <div className="flex flex-col items-center justify-center p-12 text-center bg-gray-50/50 rounded-2xl border border-gray-200">
                  <div className="h-24 w-24 bg-white rounded-full flex items-center justify-center mb-6 shadow-sm border border-gray-200">
                    <span className="text-5xl text-gray-300">＋</span>
                  </div>
                  <h3 className="text-lg font-bold text-gray-800 mb-2">טרם נוספו מוצרים</h3>
                  <p className="text-gray-500 max-w-xs mb-6">השתמש בכפתור למטה כדי לאתר מוצרים במלאי ולהוסיף אותם להזמנה זו.</p>
                  <button
                    type="button"
                    onClick={handleAddItem}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl shadow-md hover:shadow-lg transition-all font-bold"
                    disabled={createItemFromSelection.isPending}
                  >
                    הוסף מוצר חדש
                  </button>
                </div>
              )}
              {itemsState.map((item) => {
                const meta = parseVariantMeta(item.variant);
                const src = meta.image_url || 'https://via.placeholder.com/96?text=%20';
                const isService =
                  (typeof item.variant === 'string' && item.variant === 'שירות') ||
                  meta.model === 'שירות';
                return (
                  <div key={item.id} className="rounded-2xl border border-gray-200 p-4 bg-white shadow-sm">
                    <div className="flex items-start gap-4">
                      {!isService && (
                        <img src={src} alt="" className="h-20 w-20 rounded-lg border object-cover" />
                      )}
                      <div className="flex-1 space-y-3">
                        <div className="grid gap-3 md:grid-cols-2">
                          <div className="flex flex-col">
                            <label className="mb-1 text-xs text-gray-500">מוצר</label>
                            <input
                              value={item.product_name}
                              onChange={(e) => handleItemFieldChange(item.id, 'product_name', e.target.value)}
                              className="w-full rounded-lg border border-gray-200 px-3 py-2 text-right text-base focus:border-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-200"
                              placeholder="שם מוצר"
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-3">
                            <div className="flex flex-col">
                              <label className="mb-1 text-xs text-gray-500">דגם</label>
                              <input
                                value={meta.model ?? ''}
                                onChange={(e) => handleItemModelChange(item.id, e.target.value)}
                                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-right text-base focus:border-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-200"
                                placeholder="דגם"
                              />
                            </div>
                            <div className="flex flex-col">
                              <label className="mb-1 text-xs text-gray-500">מידה</label>
                              <input
                                value={meta.size ?? ''}
                                onChange={(e) => handleItemSizeChange(item.id, e.target.value)}
                                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-right text-base focus:border-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-200"
                                placeholder="מידה"
                              />
                            </div>
                          </div>
                          <div className="flex flex-col md:col-span-2">
                            <label className="mb-1 text-xs text-gray-500">מחסן</label>
                            <select
                              value={meta.warehouse_id || ''}
                              onChange={(e) => handleItemWarehouseChange(item.id, e.target.value)}
                              className="w-full rounded-lg border border-gray-200 px-3 py-2 text-right text-base focus:border-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-200"
                            >
                              {(warehouses ?? []).map((w: Warehouse) => (
                                <option key={w.id} value={w.id}>{w.name}</option>
                              ))}
                            </select>
                          </div>
                        </div>
                        <div className="grid grid-cols-3 md:grid-cols-6 gap-3 items-end">
                          <div className="flex flex-col">
                            <label className="mb-1 text-xs text-gray-500">כמות</label>
                            <input
                              type="number"
                              min={0}
                              value={item.qty}
                              onChange={(e) => handleItemFieldChange(item.id, 'qty', e.target.value)}
                              className="w-full rounded-lg border border-gray-200 px-3 py-2 text-right text-base focus:border-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-200"
                            />
                          </div>
                          <div className="flex flex-col md:col-span-2">
                            <label className="mb-1 text-xs text-gray-500">מחיר יחידה (₪)</label>
                            <input
                              type="number"
                              min={0}
                              step="0.01"
                              value={item.unit_price}
                              onChange={(e) => handleItemFieldChange(item.id, 'unit_price', e.target.value)}
                              className="w-full rounded-lg border border-gray-200 px-3 py-2 text-right text-base focus:border-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-200"
                            />
                          </div>
                          <div className="flex flex-col md:col-span-2">
                            <label className="mb-1 text-xs text-gray-500">סכום שורה (₪)</label>
                            <div className="w-full rounded-lg border border-gray-100 bg-gray-50 px-3 py-2 text-right font-semibold">
                              {formatCurrency(item.qty * item.unit_price)}
                            </div>
                          </div>
                          <div className="flex justify-start md:justify-end">
                            <button
                              type="button"
                              onClick={() => deleteItemMutation.mutate(item.id)}
                              className="h-[42px] rounded-lg border border-red-200 px-3 py-2 text-xs font-semibold text-red-600 hover:bg-red-50"
                              disabled={deleteItemMutation.isPending}
                            >
                              מחק
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        </div>

        <aside className="space-y-6">
          {/* Summary card styled like the reference */}
          <section className="rounded-2xl border border-gray-200 bg-white overflow-hidden shadow-sm">
            <div className="p-6 bg-gray-50 border-b border-gray-200">
              <h2 className="text-lg font-bold text-slate-800">סיכום הזמנה</h2>
            </div>
            <div className="p-6 space-y-5">
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-500">סכום ביניים</span>
                <span className="font-medium text-slate-800">
                  {formatCurrency(totalAmount)}
                </span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-500">מע״מ (18%)</span>
                <span className="font-medium text-slate-800">
                  {formatCurrency(vatAmount)}
                </span>
              </div>
              <div className="flex justify-between items-center text-sm text-green-600 font-medium bg-green-50 p-2.5 rounded-lg border border-green-100">
                <span className="flex items-center gap-1">הנחה</span>
                <span>- {formatCurrency(0)}</span>
              </div>
              <div className="pt-5 border-t border-dashed border-gray-300 mt-2">
                <div className="flex justify-between items-end">
                  <span className="text-lg font-bold text-slate-800">סה״כ לתשלום</span>
                  <div className="text-left">
                    <span className="block text-3xl font-bold text-blue-600 leading-none">
                      {formatCurrency(totalWithVat)}
                    </span>
                    <span className="text-xs text-gray-500 mt-1 block">כולל מע״מ</span>
                  </div>
                </div>
              </div>
            </div>
            {/* footer removed per request */}
          </section>
        </aside>
      </div>

      {productPickerState.open && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/40 px-4" dir="rtl">
          <div className="w-full max-w-2xl rounded-2xl bg-white shadow-2xl">
            <div className="flex items-center justify-between border-b px-6 py-4">
              <h2 className="text-lg font-semibold">בחירת מוצר</h2>
              <button
                type="button"
                onClick={closeProductPicker}
                className="text-gray-500 transition hover:text-gray-700"
              >
                ✕
              </button>
            </div>
            <div className="space-y-4 px-6 py-5">
              <div className="flex items-center justify-end gap-2">
                <label className="text-sm text-gray-600">מחסן להזמנה:</label>
                <select
                  className="rounded border px-2 py-1 text-right"
                  value={selectedWarehouseForPicker}
                  onChange={(e) => setSelectedWarehouseForPicker(e.target.value)}
                >
                  {(warehouses ?? []).map((w: Warehouse) => (
                    <option key={w.id} value={w.id}>{w.name}</option>
                  ))}
                </select>
              </div>
              <input
                value={productSearchTerm}
                onChange={(event) => setProductSearchTerm(event.target.value)}
                placeholder="חיפוש לפי שם מוצר או קוד..."
                className="w-full rounded-lg border border-gray-300 px-4 py-2 text-right focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
              />
              <div className="max-h-80 overflow-y-auto rounded-xl border border-gray-100">
                {isProductLoading ? (
                  <div className="py-10 text-center text-sm text-gray-500">
                    טוען מוצרים...
                  </div>
                ) : isProductError ? (
                  <div className="py-10 text-center text-sm text-red-600">
                    אירעה שגיאה בטעינת מוצרים:{' '}
                    {productError instanceof Error ? productError.message : 'לא ידוע'}
                  </div>
                ) : productOptions.length === 0 ? (
                  <div className="py-10 text-center text-sm text-gray-500">
                    לא נמצאו מוצרים תואמים.
                  </div>
                ) : (
                  <ul className="divide-y divide-gray-100">
                    {productOptions.map((product) => (
                      <li key={product.id}>
                        <button
                          type="button"
                          onClick={() => handleProductPicked(product)}
                          className="flex w-full items-center gap-3 px-5 py-3 text-right transition hover:bg-blue-50"
                        >
                          <img
                            src={product.image_url || 'https://via.placeholder.com/64?text=%20'}
                            alt={product.name}
                            className="h-12 w-12 rounded-md border object-cover"
                          />
                          <div className="flex flex-1 flex-col items-start">
                            <span className="text-sm font-semibold text-gray-900">
                              {product.name}
                            </span>
                            <span className="text-xs text-gray-500">
                              {product.product_code
                                ? `קוד מוצר: ${product.product_code}`
                                : product.supplier
                                ? `ספק: ${product.supplier}`
                                : 'ללא קוד מוצר'}
                              {Array.isArray(product.dimensions) && product.dimensions.length > 0
                                ? ' • כולל מספר מידות'
                                : ''}
                            </span>
                          </div>
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
            <div className="flex items-center justify-end gap-3 border-t px-6 py-4">
              <button
                type="button"
                onClick={closeProductPicker}
                className="rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                ביטול
              </button>
            </div>
          </div>
        </div>
      )}

      {sizePickerProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4" dir="rtl">
          <div className="w-full max-w-xl rounded-2xl bg-white shadow-2xl">
            <div className="flex items-center justify-between border-b px-6 py-4">
              <h2 className="text-lg font-semibold">
                בחירת מידה – {sizePickerProduct.name}
              </h2>
              <button
                type="button"
                onClick={() => setSizePickerProduct(null)}
                className="text-gray-500 transition hover:text-gray-700"
              >
                ✕
              </button>
            </div>
            <div className="max-h-96 overflow-y-auto px-6 py-4">
              <div className="mb-3 flex items-center justify-end gap-2">
                <label className="text-sm text-gray-600">מחסן להזמנה:</label>
                <select
                  className="rounded border px-2 py-1 text-right"
                  value={selectedWarehouseForPicker}
                  onChange={(e) => setSelectedWarehouseForPicker(e.target.value)}
                >
                  {(warehouses ?? []).map((w: Warehouse) => (
                    <option key={w.id} value={w.id}>{w.name}</option>
                  ))}
                </select>
              </div>
              <ul className="divide-y divide-gray-100">
                {(sizePickerProduct.dimensions || []).map((d, idx) => {
                  const labelParts: string[] = [];
                  if (d.model) labelParts.push(d.model);
                  // Order dimensions as width × height × length (fallback to depth when length missing)
                  const dims = [d.width, d.height, (d.length ?? d.depth)]
                    .filter((n) => typeof n === 'number' && !Number.isNaN(n))
                    .join('×');
                  if (dims) labelParts.push(dims);
                  const label = labelParts.join(' • ');
                  return (
                    <li key={idx}>
                      <button
                        type="button"
                        onClick={() => {
                          const composedName = label ? `${sizePickerProduct.name} – ${label}` : sizePickerProduct.name;
                          if (productPickerState.target === 'new') {
                            createItemFromSelection.mutate({
                              product_name: sizePickerProduct.name,
                              variant: buildVariantMeta({
                                model: d.product_code || '',
                                size: dims || '',
                                image_url: sizePickerProduct.image_url || '',
                                warehouse_id: selectedWarehouseForPicker || '',
                                warehouse_name: getWarehouseName(selectedWarehouseForPicker) || '',
                              }),
                              qty: 1,
                              unit_price: 0,
                            });
                          } else if (productPickerState.target) {
                            const targetId = productPickerState.target;
                            setItemsState((current) =>
                              current.map((item) =>
                                item.id === targetId
                                  ? {
                                      ...item,
                                      product_name: sizePickerProduct.name,
                                      variant: buildVariantMeta({
                                        model: d.product_code || '',
                                        size: dims || '',
                                        image_url: sizePickerProduct.image_url || '',
                                        warehouse_id: selectedWarehouseForPicker || '',
                                        warehouse_name: getWarehouseName(selectedWarehouseForPicker) || '',
                                      }),
                                    }
                                  : item,
                              ),
                            );
                            const patch: ItemPatchInput = {
                              product_name: sizePickerProduct.name,
                            };
                            patch.variant = buildVariantMeta({
                              model: d.product_code || '',
                              size: dims || '',
                              image_url: sizePickerProduct.image_url || '',
                              warehouse_id: selectedWarehouseForPicker || '',
                              warehouse_name: getWarehouseName(selectedWarehouseForPicker) || '',
                            });
                            scheduleItemPatch(targetId, patch);
                          }
                          setSizePickerProduct(null);
                          closeProductPicker();
                        }}
                        className="flex w-full items-center justify-between px-5 py-3 text-right transition hover:bg-blue-50"
                      >
                        <span className="text-sm text-gray-900">{dims || label || 'מידה'}</span>
                        <span className="text-xs text-gray-500">
                          {d.product_code ? `קוד: ${d.product_code}` : ''}
                        </span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
            <div className="flex items-center justify-between gap-3 border-t px-6 py-4">
              <button
                type="button"
                onClick={() => setSizePickerProduct(null)}
                className="rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                ביטול
              </button>
              <button
                type="button"
                onClick={() => {
                  // בחירה ללא מידה – יצירה עם שם מוצר בלבד
                  if (productPickerState.target === 'new') {
                    createItemFromSelection.mutate({
                      product_name: sizePickerProduct.name,
                      qty: 1,
                      unit_price: 0,
                    });
                  } else if (productPickerState.target) {
                    const targetId = productPickerState.target;
                    setItemsState((current) =>
                      current.map((item) =>
                        item.id === targetId
                          ? {
                              ...item,
                              product_name: sizePickerProduct.name,
                            }
                          : item,
                      ),
                    );
                    scheduleItemPatch(targetId, { product_name: sizePickerProduct.name });
                  }
                  setSizePickerProduct(null);
                  closeProductPicker();
                }}
                className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700"
              >
                בחר ללא מידה
              </button>
            </div>
          </div>
        </div>
      )}

      <ToastViewport toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}

