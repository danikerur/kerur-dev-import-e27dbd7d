import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  CreateOrderDraftInput,
  createOrderDraft,
  fetchCustomerOrders,
  fetchCustomers,
  getOrderById,
} from '../../lib/db.orders';
import { Customer, CustomerOrderListItem } from '../../types/orders';
import { ToastViewport, useToast } from '../../hooks/useToast';
import { AddCustomerModal } from '../../components/AddCustomerModal';
import { deleteOrder } from '../../lib/db.orders';
import { ChevronDown, ChevronRight } from 'lucide-react';
import { format } from 'date-fns';

const statusLabels: Record<string, string> = {
  Draft: 'טיוטה',
  Confirmed: 'מאושרת',
  Fulfilled: 'סופקה',
  Cancelled: 'בוטלה',
};

const statusClasses: Record<string, string> = {
  Draft: 'bg-gray-100 text-gray-700 border border-gray-200',
  Confirmed: 'bg-blue-100 text-blue-800 border border-blue-200',
  Fulfilled: 'bg-green-100 text-green-800 border border-green-200',
  Cancelled: 'bg-red-100 text-red-800 border border-red-200',
};

function formatCurrency(value: number) {
  return new Intl.NumberFormat('he-IL', {
    style: 'currency',
    currency: 'ILS',
    maximumFractionDigits: 2,
  }).format(value);
}

function formatDate(value?: string | null) {
  if (!value) return '-';
  try {
    return format(new Date(value), 'dd/MM/yyyy');
  } catch {
    return value;
  }
}

interface NewOrderDialogProps {
  open: boolean;
  onClose: () => void;
  onCreate: (input: CreateOrderDraftInput) => void;
  isCreating: boolean;
}

function NewOrderDialog({ open, onClose, onCreate, isCreating }: NewOrderDialogProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [showAddCustomer, setShowAddCustomer] = useState(false);

  const { data: customers = [], isLoading } = useQuery({
    queryKey: ['customers', 'new-order', searchTerm],
    queryFn: () => fetchCustomers(searchTerm),
    enabled: open,
  });

  const handleClose = () => {
    setSearchTerm('');
    setSelectedCustomer(null);
    onClose();
  };

  const handleCreate = () => {
    onCreate({
      customer_id: selectedCustomer?.id ?? null,
    });
  };

  if (!open) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/40 px-4" dir="rtl">
      <div className="w-full max-w-lg rounded-2xl bg-white shadow-xl">
        <div className="flex items-center justify-between border-b px-6 py-4">
          <h2 className="text-lg font-semibold">יצירת הזמנה חדשה</h2>
          <button
            type="button"
            onClick={handleClose}
            className="text-gray-500 transition-colors hover:text-gray-700"
          >
            ✕
          </button>
        </div>

        <div className="space-y-4 px-6 py-5">
          <div>
            <label className="mb-2 block text-sm font-medium text-gray-700">
              חיפוש לקוח (לא חובה)
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={searchTerm}
                onChange={(event) => setSearchTerm(event.target.value)}
                placeholder="הקלד שם לקוח..."
                className="w-full rounded-lg border border-gray-300 px-3 py-2 text-right focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
              />
              <button
                type="button"
                onClick={() => setShowAddCustomer(true)}
                className="shrink-0 rounded-lg bg-green-600 px-3 py-2 text-xs font-semibold text-white hover:bg-green-700"
              >
                לקוח חדש
              </button>
            </div>
          </div>

          <div className="max-h-56 space-y-2 overflow-y-auto rounded-lg border border-gray-200 p-2">
            {isLoading ? (
              <div className="py-6 text-center text-sm text-gray-500">טוען לקוחות...</div>
            ) : customers.length === 0 ? (
              <div className="py-6 text-center text-sm text-gray-500">
                לא נמצאו לקוחות. ניתן ליצור הזמנה ללא בחירת לקוח.
              </div>
            ) : (
              customers.map((customer) => {
                const isActive = selectedCustomer?.id === customer.id;
                return (
                  <button
                    key={customer.id}
                    type="button"
                    onClick={() =>
                      setSelectedCustomer((current) =>
                        current?.id === customer.id ? null : customer,
                      )
                    }
                    className={`flex w-full flex-col rounded-lg border px-3 py-2 text-right transition ${
                      isActive
                        ? 'border-blue-400 bg-blue-50 text-blue-800'
                        : 'border-transparent bg-white hover:border-blue-200 hover:bg-blue-50'
                    }`}
                  >
                    <span className="text-sm font-medium">{customer.name}</span>
                    {customer.phone && (
                      <span className="text-xs text-gray-500">{customer.phone}</span>
                    )}
                  </button>
                );
              })
            )}
          </div>
        </div>

        <div className="flex items-center justify-between border-t px-6 py-4" dir="rtl">
          <button
            type="button"
            onClick={handleClose}
            className="rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
            disabled={isCreating}
          >
            ביטול
          </button>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() =>
                onCreate({
                  customer_id: null,
                })
              }
              className="rounded-lg border border-blue-200 px-4 py-2 text-sm font-medium text-blue-700 hover:bg-blue-50 disabled:cursor-not-allowed disabled:opacity-70"
              disabled={isCreating}
            >
              טיוטה ללא לקוח
            </button>
            <button
              type="button"
              onClick={handleCreate}
              className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-70"
              disabled={isCreating}
            >
              צור טיוטה
            </button>
          </div>
        </div>
      </div>
      {showAddCustomer && (
        <AddCustomerModal
          onClose={() => setShowAddCustomer(false)}
          onCustomerAdded={(cust) => {
            setSelectedCustomer({
              id: cust.id,
              name: cust.name,
              phone: cust.phone,
            });
            setShowAddCustomer(false);
          }}
        />
      )}
    </div>
  );
}

export default function CustomerOrdersPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { toasts, dismissToast, helpers } = useToast();
  const [isNewOrderDialogOpen, setIsNewOrderDialogOpen] = useState(false);
  const [search, setSearch] = useState('');

  const { data: orders = [], isLoading, isError, error } = useQuery({
    queryKey: ['customer-orders'],
    queryFn: fetchCustomerOrders,
  });

  const deleteMutation = useMutation({
    mutationFn: (orderId: string) => deleteOrder(orderId),
    onSuccess: () => {
      helpers.success('ההזמנה נמחקה');
      queryClient.invalidateQueries({ queryKey: ['customer-orders'] });
      // עדכן מיידית את עמוד המלאי: הורד מה"‏שמור ללקוחות"
      queryClient.invalidateQueries({ queryKey: ['inventory-reserved-counts'] });
      queryClient.invalidateQueries({ queryKey: ['reserved-details'] });
    },
    onError: (e: unknown) => {
      helpers.error(e instanceof Error ? e.message : 'שגיאה במחיקת ההזמנה');
    },
  });

  const createDraftMutation = useMutation({
    mutationFn: (input: CreateOrderDraftInput) => createOrderDraft(input),
    onSuccess: (order) => {
      helpers.success('נוצרה טיוטת הזמנה חדשה');
      queryClient.invalidateQueries({ queryKey: ['customer-orders'] });
      setIsNewOrderDialogOpen(false);
      navigate(`/customer-orders/${order.id}`);
    },
    onError: (mutationError: unknown) => {
      const message =
        mutationError instanceof Error ? mutationError.message : 'אירעה שגיאה בשמירה';
      helpers.error(message);
    },
  });

  const handleRowClick = (order: CustomerOrderListItem) => {
    navigate(`/customer-orders/${order.id}`);
  };

  const filteredOrders = useMemo(() => {
    const term = search.trim().toLowerCase();
    if (!term) return orders;
    const matchText = (v?: string | null) => (v ? String(v).toLowerCase().includes(term) : false);

    const parseVariantMeta = (variant?: string | null): { model?: string; size?: string } => {
      if (!variant) return {};
      try {
        const meta = JSON.parse(variant as string);
        if (meta && typeof meta === 'object') {
          return {
            model: typeof (meta as any).model === 'string' ? (meta as any).model : undefined,
            size: typeof (meta as any).size === 'string' ? (meta as any).size : undefined,
          };
        }
      } catch {}
      return { model: variant || undefined };
    };

    return (orders || []).filter((o) => {
      const inCustomer =
        matchText(o.customer?.name) ||
        matchText(o.customer?.phone) ||
        matchText((o.customer as any)?.address);

      const inItems =
        (o as any).items?.some(
          (it: any) =>
            matchText(it.product_name) ||
            matchText(parseVariantMeta(it.variant).model) ||
            matchText(parseVariantMeta(it.variant).size),
        ) ?? false;

    return inCustomer || inItems;
    });
  }, [orders, search]);

  const groups = useMemo(() => {
    const sorted = [...filteredOrders].sort(
      (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime(),
    );
    const map = new Map<string, CustomerOrderListItem[]>();
    for (const o of sorted) {
      const d = new Date(o.created_at);
      const key = new Intl.DateTimeFormat('he-IL', {
        month: 'long',
        year: 'numeric',
      }).format(d);
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(o);
    }
    return Array.from(map.entries());
  }, [filteredOrders]);

  // Helper for item preview
  const parseVariantMeta = (variant?: string | null): { model?: string; size?: string } => {
    if (!variant) return {};
    try {
      const meta = JSON.parse(variant as string);
      if (meta && typeof meta === 'object') {
        return {
          model: typeof (meta as any).model === 'string' ? (meta as any).model : undefined,
          size: typeof (meta as any).size === 'string' ? (meta as any).size : undefined,
        };
      }
    } catch {}
    return { model: variant || undefined };
  };

  function OrderRow({ order }: { order: CustomerOrderListItem }) {
    const [open, setOpen] = React.useState(false);
    const { data, isLoading, isError } = useQuery({
      queryKey: ['order-items-preview', order.id],
      queryFn: () => getOrderById(order.id),
      enabled: open,
    });

    const totalWithVat = (order.total_amount ?? 0) * 1.18;

    return (
      <>
        <tr className="hover:bg-blue-50">
          <td className="px-2 py-3 text-center align-top">
            <button
              type="button"
              aria-label={open ? 'סגור פרטים' : 'פתח פרטים'}
              onClick={() => setOpen((v) => !v)}
              className="inline-flex items-center justify-center w-7 h-7 rounded-md border border-gray-300 hover:bg-gray-50"
            >
              {open ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
          </td>
          <td
            className="px-4 py-3 text-sm font-mono text-gray-700 cursor-pointer"
            onClick={() => handleRowClick(order)}
          >
            #{order.id.slice(0, 8).toUpperCase()}
          </td>
          <td
            className="px-4 py-3 text-sm text-gray-700 cursor-pointer"
            onClick={() => handleRowClick(order)}
          >
            {order.customer?.name ?? 'ללא לקוח'}
          </td>
          <td className="px-4 py-3 text-sm">
            <span
              className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold ${
                statusClasses[order.status] ?? statusClasses.Draft
              }`}
            >
              {statusLabels[order.status] ?? order.status}
            </span>
          </td>
          <td className="px-4 py-3 text-sm text-gray-600">{formatDate(order.created_at)}</td>
          <td className="px-4 py-3 text-sm text-gray-600">
            {formatDate(order.expected_delivery_date)}
          </td>
          <td className="px-4 py-3 text-sm font-semibold text-gray-900">
            {formatCurrency(totalWithVat)}
          </td>
          <td className="px-4 py-3 text-sm">
            <button
              type="button"
              onClick={() => {
                if (confirm('למחוק את ההזמנה? הפעולה אינה הפיכה.')) {
                  deleteMutation.mutate(order.id);
                }
              }}
              className="rounded-lg border border-red-200 px-3 py-1 text-xs font-semibold text-red-600 hover:bg-red-50"
            >
              מחק
            </button>
          </td>
        </tr>
        {open && (
          <tr>
            <td colSpan={8} className="bg-gray-50 px-6 py-3">
              {isLoading ? (
                <div className="text-sm text-gray-500">טוען פריטים...</div>
              ) : isError || !data ? (
                <div className="text-sm text-red-600">שגיאה בטעינת פריטים</div>
              ) : data.items.length === 0 ? (
                <div className="text-sm text-gray-500">אין פריטים בהזמנה</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full text-right">
                    <thead className="text-xs text-gray-500">
                      <tr>
                        <th className="px-2 py-1">מוצר</th>
                        <th className="px-2 py-1">דגם</th>
                        <th className="px-2 py-1">מידה</th>
                        <th className="px-2 py-1">כמות</th>
                        <th className="px-2 py-1">מחיר יחידה</th>
                        <th className="px-2 py-1">סכום</th>
                      </tr>
                    </thead>
                    <tbody className="text-sm">
                      {data.items.map((it) => {
                        const meta = parseVariantMeta((it as any).variant);
                        return (
                          <tr key={it.id} className="border-t">
                            <td className="px-2 py-1">{it.product_name}</td>
                            <td className="px-2 py-1">{meta.model ?? '-'}</td>
                            <td className="px-2 py-1">{meta.size ?? '-'}</td>
                            <td className="px-2 py-1">{it.qty}</td>
                            <td className="px-2 py-1">{formatCurrency(it.unit_price)}</td>
                            <td className="px-2 py-1 font-semibold">
                              {formatCurrency(it.qty * it.unit_price)}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </td>
          </tr>
        )}
      </>
    );
  }

  const content = useMemo(() => {
    if (isLoading) {
      return <div className="py-20 text-center text-gray-500">טוען הזמנות...</div>;
    }
    if (isError) {
      return (
        <div className="rounded-lg border border-red-200 bg-red-50 p-6 text-right text-red-700">
          אירעה שגיאה בטעינת ההזמנות: {error instanceof Error ? error.message : 'לא ידוע'}
        </div>
      );
    }
    if (filteredOrders.length === 0) {
      return (
        <div className="rounded-lg border border-gray-200 bg-white p-8 text-center text-gray-600">
          אין הזמנות עדיין. לחץ על “+ הזמנה חדשה” כדי להתחיל.
        </div>
      );
    }

    return (
      <div className="space-y-6">
        {groups.map(([monthLabel, list]) => (
          <div key={monthLabel} className="overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">
            <div className="flex items-center justify-between px-4 py-3 bg-gray-50 border-b">
              <h3 className="text-base font-semibold text-gray-900">{monthLabel}</h3>
              <span className="text-sm text-gray-500">{list.length} הזמנות</span>
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200 text-right">
                <thead className="bg-gray-50 text-gray-700">
                  <tr>
                    <th className="w-10 px-3"></th>
                    <th className="px-4 py-3 text-sm font-semibold">מס׳ הזמנה</th>
                    <th className="px-4 py-3 text-sm font-semibold">לקוח</th>
                    <th className="px-4 py-3 text-sm font-semibold">סטטוס</th>
                    <th className="px-4 py-3 text-sm font-semibold">תאריך יצירה</th>
                    <th className="px-4 py-3 text-sm font-semibold">תאריך יעד</th>
                    <th className="px-4 py-3 text-sm font-semibold">סכום כולל (כולל מע״מ)</th>
                    <th className="px-4 py-3 text-sm font-semibold">פעולות</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {list.map((order) => (
                    <OrderRow key={order.id} order={order} />
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ))}
      </div>
    );
  }, [error, isError, isLoading, filteredOrders, groups, deleteMutation.isPending]);

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between gap-4">
        <h1 className="text-3xl font-bold text-gray-900">הזמנות לקוחות</h1>
        <button
          type="button"
          onClick={() => setIsNewOrderDialogOpen(true)}
          className="inline-flex items-center justify-center rounded-xl bg-blue-600 px-4 py-2 text-sm font-semibold text-white shadow hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-200"
        >
          + הזמנה חדשה
        </button>
      </div>

      <p className="mt-1 text-sm text-gray-600">
        ניהול הזמנות, סטטוסים ופריטים בזמן אמת.
      </p>

      <div className="mt-4">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="חיפוש שם לקוח / עיר / כתובת / מוצר..."
          className="w-full rounded-lg border border-gray-300 px-3 py-2 text-right focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
        />
      </div>

      {content}

      <NewOrderDialog
        open={isNewOrderDialogOpen}
        onClose={() => setIsNewOrderDialogOpen(false)}
        onCreate={(input) => createDraftMutation.mutate(input)}
        isCreating={createDraftMutation.isPending}
      />

      <ToastViewport toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}

