import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation } from '@tanstack/react-query';
import { createOrderDraft } from '../../lib/db.orders';
import { ToastViewport, useToast } from '../../hooks/useToast';

export default function NewCustomerOrderPage() {
  const navigate = useNavigate();
  const { toasts, dismissToast, helpers } = useToast();

  const createDraftMutation = useMutation({
    mutationFn: () => createOrderDraft({}),
    onSuccess: (order) => {
      helpers.success('נוצרה טיוטת הזמנה חדשה');
      navigate(`/customer-orders/${order.id}`, { replace: true });
    },
    onError: (error) => {
      helpers.error(
        error instanceof Error ? error.message : 'אירעה שגיאה ביצירת הטיוטה',
      );
    },
  });

  useEffect(() => {
    createDraftMutation.mutate();
  }, [createDraftMutation]);

  return (
    <div className="flex min-h-[50vh] flex-col items-center justify-center gap-4 text-center" dir="rtl">
      <div className="text-lg font-semibold text-gray-800">
        יוצרים טיוטת הזמנה חדשה...
      </div>
      {createDraftMutation.isError && (
        <button
          type="button"
          onClick={() => createDraftMutation.mutate()}
          className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700"
        >
          נסה שוב
        </button>
      )}
      <ToastViewport toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}

