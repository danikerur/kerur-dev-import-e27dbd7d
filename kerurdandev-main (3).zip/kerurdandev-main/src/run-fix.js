// Script to run the catalog visibility fix
import { fixCatalogVisibility } from './fix-catalog-visibility.js';

// Run the fix
fixCatalogVisibility()
  .then(result => {
    if (result.success) {
      console.log('✅ ' + result.message);
    } else {
      console.error('❌ Error: ' + result.error);
    }
  })
  .catch(err => {
    console.error('❌ Unexpected error:', err);
  });