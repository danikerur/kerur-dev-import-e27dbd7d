-- Create the category_images table
CREATE TABLE IF NOT EXISTS category_images (
    id BIGSERIAL PRIMARY KEY,
    category_id BIGINT NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
    image_url TEXT NOT NULL,
    group_tag TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_category_images_category_id ON category_images(category_id);
CREATE INDEX IF NOT EXISTS idx_category_images_created_at ON category_images(created_at);

-- Create the category-images storage bucket
INSERT INTO storage.buckets (id, name, public) 
VALUES ('category-images', 'category-images', true)
ON CONFLICT (id) DO NOTHING;

-- Set up storage policies for the category-images bucket
-- Allow authenticated users to upload images
CREATE POLICY "Allow authenticated users to upload category images" ON storage.objects
    FOR INSERT WITH CHECK (
        bucket_id = 'category-images' 
        AND auth.role() = 'authenticated'
    );

-- Allow authenticated users to view images
CREATE POLICY "Allow authenticated users to view category images" ON storage.objects
    FOR SELECT USING (
        bucket_id = 'category-images' 
        AND auth.role() = 'authenticated'
    );

-- Allow authenticated users to delete images
CREATE POLICY "Allow authenticated users to delete category images" ON storage.objects
    FOR DELETE USING (
        bucket_id = 'category-images' 
        AND auth.role() = 'authenticated'
    );

-- Enable RLS on the category_images table
ALTER TABLE category_images ENABLE ROW LEVEL SECURITY;

-- Create policies for the category_images table
-- Allow authenticated users to view all category images
CREATE POLICY "Allow authenticated users to view category images" ON category_images
    FOR SELECT USING (auth.role() = 'authenticated');

-- Allow authenticated users to insert category images
CREATE POLICY "Allow authenticated users to insert category images" ON category_images
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- Allow authenticated users to delete category images
CREATE POLICY "Allow authenticated users to delete category images" ON category_images
    FOR DELETE USING (auth.role() = 'authenticated'); 