// Supabase Edge Function: ingest-lead
// Accepts JSON or form-encoded webhooks and inserts a lead into public.leads

import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    // Optional shared secret validation
    const configuredSecret = Deno.env.get("WEBHOOK_SECRET");
    if (configuredSecret) {
      const provided = req.headers.get("x-webhook-secret");
      if (!provided || provided !== configuredSecret) {
        return new Response(JSON.stringify({ error: "Unauthorized" }), {
          status: 401,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        });
      }
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!supabaseUrl || !serviceKey) {
      return new Response(JSON.stringify({ error: "Missing service credentials" }), {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    const admin = createClient(supabaseUrl, serviceKey);

    // Parse payload from JSON or form-encoded
    const contentType = req.headers.get("content-type")?.toLowerCase() || "";
    let payload: Record<string, unknown> = {};
    if (contentType.includes("application/json")) {
      payload = await req.json();
    } else if (contentType.includes("application/x-www-form-urlencoded")) {
      const form = await req.formData();
      for (const [key, value] of form.entries()) {
        payload[key] = value;
      }
    } else {
      // Attempt JSON as default
      try {
        payload = await req.json();
      } catch (_) {
        return new Response(JSON.stringify({ error: "Unsupported content type" }), {
          status: 415,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        });
      }
    }

    const getFirst = (keys: string[], fallback: string | null = null): string | null => {
      for (const k of keys) {
        const v = payload[k];
        if (typeof v === "string" && v.trim() !== "") return v.trim();
        // Accept numbers for phone
        if (typeof v === "number" && keys.includes("phone")) return String(v);
      }
      return fallback;
    };

    const customer_name = getFirst(["customer_name", "full_name", "name", "first_name", "שם", "שם_לקוח"]);
    const business_name = getFirst(["business_name", "company", "business", "שם_עסק"]);
    const city = getFirst(["city", "עיר"]);
    const phone = getFirst(["phone", "phone_number", "mobile", "טלפון", "נייד" ]);
    const status = getFirst(["status", "סטטוס"], "חדש");
    const call_summary = getFirst(["call_summary", "summary", "notes", "סיכום", "הערות"], "");

    // inquiry_date: accept explicit date or default today (UTC)
    let inquiry_date: string | null = null;
    const dateRaw = getFirst(["inquiry_date", "date", "created_at", "submitted_at", "תאריך"]);
    if (dateRaw) {
      const d = new Date(dateRaw);
      if (!isNaN(d.getTime())) {
        inquiry_date = d.toISOString().slice(0, 10); // YYYY-MM-DD
      }
    }
    if (!inquiry_date) {
      const today = new Date();
      inquiry_date = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate()))
        .toISOString()
        .slice(0, 10);
    }

    const insertPayload = {
      customer_name,
      business_name,
      city,
      phone,
      inquiry_date,
      status,
      call_summary,
      is_new: true,
      created_via: 'webhook',
    };

    const { data, error } = await admin.from("leads").insert(insertPayload).select().single();
    if (error) {
      return new Response(JSON.stringify({ error: error.message }), {
        status: 400,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    return new Response(JSON.stringify({ ok: true, id: data.id }), {
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  }
});


