/*
  # Add product specifications to customers table

  1. Changes
    - Add product_specifications column to customers table to store specific product dimensions for each customer
*/

ALTER TABLE customers
ADD COLUMN IF NOT EXISTS product_specifications jsonb DEFAULT '{}'::jsonb;