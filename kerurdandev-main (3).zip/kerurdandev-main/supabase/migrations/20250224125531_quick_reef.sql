/*
  # Make city field optional

  1. Changes
    - Make the city field in customers table optional by removing the NOT NULL constraint
    - Update existing records to have an empty string as city if it's NULL

  2. Security
    - No changes to RLS policies required
*/

ALTER TABLE customers ALTER COLUMN city DROP NOT NULL;
UPDATE customers SET city = '' WHERE city IS NULL;