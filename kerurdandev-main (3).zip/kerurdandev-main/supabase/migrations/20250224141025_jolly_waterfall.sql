/*
  # Update customers table schema

  1. Changes
    - Add products column to store multiple products per customer
*/

-- Add products column
ALTER TABLE customers
ADD COLUMN IF NOT EXISTS products jsonb DEFAULT '[]'::jsonb;