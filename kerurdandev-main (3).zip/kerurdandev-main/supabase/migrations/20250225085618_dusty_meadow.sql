/*
  # הוספת מערכת קטגוריות למוצרים

  1. טבלאות חדשות
    - `categories`
      - `id` (uuid, מפתח ראשי)
      - `name` (text, שם הקטגוריה)
      - `created_at` (timestamp)

  2. שינויים בטבלאות קיימות
    - הוספת עמודת `category_id` לטבלת `products`

  3. אבטחה
    - הפעלת RLS על טבלת הקטגוריות
    - הוספת מדיניות גישה למשתמשים מאומתים
*/

-- Create categories table
CREATE TABLE categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Add category_id to products
ALTER TABLE products
ADD COLUMN category_id uuid REFERENCES categories(id) ON DELETE SET NULL;

-- Enable RLS
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable read access for authenticated users" ON categories
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Enable write access for authenticated users" ON categories
  FOR INSERT TO authenticated
  WITH CHECK (true);

CREATE POLICY "Enable update access for authenticated users" ON categories
  FOR UPDATE TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Enable delete access for authenticated users" ON categories
  FOR DELETE TO authenticated
  USING (true);

-- Create index for faster lookups
CREATE INDEX products_category_id_idx ON products(category_id);