/*
  # Add parent categories support

  1. Changes
    - Add parent_id column to categories table
    - Add self-referential foreign key constraint
    - Add index for faster lookups
    - Update RLS policies
*/

-- Add parent_id column
ALTER TABLE categories
ADD COLUMN parent_id uuid REFERENCES categories(id) ON DELETE SET NULL;

-- Create index for faster lookups
CREATE INDEX categories_parent_id_idx ON categories(parent_id);

-- Update RLS policies to ensure proper access control with parent categories
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON categories;
DROP POLICY IF EXISTS "Enable write access for authenticated users" ON categories;
DROP POLICY IF EXISTS "Enable update access for authenticated users" ON categories;
DROP POLICY IF EXISTS "Enable delete access for authenticated users" ON categories;

CREATE POLICY "Enable read access for authenticated users"
ON categories FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Enable insert access for authenticated users"
ON categories FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Enable update access for authenticated users"
ON categories FOR UPDATE
TO authenticated
USING (true)
WITH CHECK (true);

CREATE POLICY "Enable delete access for authenticated users"
ON categories FOR DELETE
TO authenticated
USING (
  -- Only allow deletion if no products are associated with this category
  NOT EXISTS (
    SELECT 1 FROM products
    WHERE products.category_id = categories.id
  )
  -- And no child categories exist
  AND NOT EXISTS (
    SELECT 1 FROM categories children
    WHERE children.parent_id = categories.id
  )
);