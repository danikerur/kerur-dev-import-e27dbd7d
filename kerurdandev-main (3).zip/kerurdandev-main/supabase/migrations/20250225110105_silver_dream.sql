/*
  # Update category policies for parent-child relationships

  1. Changes
    - Create index on parent_id column for faster lookups
    - Update existing RLS policies to handle parent-child relationships
    - Add deletion constraints for categories

  2. Security
    - Modify policies to ensure proper access control
    - Add deletion constraints to maintain data integrity
*/

-- Create index for faster lookups if it doesn't exist
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE indexname = 'categories_parent_id_idx'
  ) THEN
    CREATE INDEX categories_parent_id_idx ON categories(parent_id);
  END IF;
END $$;

-- Update existing policies with new conditions
ALTER POLICY "Enable delete access for authenticated users" ON categories
USING (
  -- Only allow deletion if no products are associated with this category
  NOT EXISTS (
    SELECT 1 FROM products
    WHERE products.category_id = categories.id
  )
  -- And no child categories exist
  AND NOT EXISTS (
    SELECT 1 FROM categories children
    WHERE children.parent_id = categories.id
  )
);