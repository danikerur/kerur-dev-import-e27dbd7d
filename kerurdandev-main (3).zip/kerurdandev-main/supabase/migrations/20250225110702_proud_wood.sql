/*
  # Update category policies

  1. Changes
    - Update delete policy to handle parent-child relationships
*/

-- Update existing delete policy with new conditions
ALTER POLICY "Enable delete access for authenticated users" ON categories
USING (
  -- Only allow deletion if no products are associated with this category
  NOT EXISTS (
    SELECT 1 FROM products
    WHERE products.category_id = categories.id
  )
  -- And no child categories exist
  AND NOT EXISTS (
    SELECT 1 FROM categories children
    WHERE children.parent_id = categories.id
  )
);