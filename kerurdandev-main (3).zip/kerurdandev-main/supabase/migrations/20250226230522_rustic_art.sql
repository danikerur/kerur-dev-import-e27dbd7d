/*
  # Add dimensions array to products table

  1. Changes
    - Add dimensions array to products table to support multiple dimensions per product
    - This allows products to have multiple size variations
*/

-- Add dimensions array to products table if it doesn't exist
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'products' AND column_name = 'dimensions'
  ) THEN
    ALTER TABLE products ADD COLUMN dimensions JSONB DEFAULT '[]'::jsonb;
  END IF;
END $$;