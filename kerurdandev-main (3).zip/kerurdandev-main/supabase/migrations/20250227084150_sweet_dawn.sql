/*
  # Link Products to Catalog

  1. New Fields
    - Add `catalog_visible` boolean field to products table to control visibility in catalog
    - Add `catalog_order` integer field to products table to control display order in catalog
  
  2. Default Values
    - Set default value for `catalog_visible` to true
    - Set default value for `catalog_order` to 0
*/

-- Add catalog_visible field to products table if it doesn't exist
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'products' AND column_name = 'catalog_visible'
  ) THEN
    ALTER TABLE products ADD COLUMN catalog_visible BOOLEAN DEFAULT true;
  END IF;
END $$;

-- Add catalog_order field to products table if it doesn't exist
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'products' AND column_name = 'catalog_order'
  ) THEN
    ALTER TABLE products ADD COLUMN catalog_order INTEGER DEFAULT 0;
  END IF;
END $$;

-- Create index for faster catalog sorting
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE indexname = 'products_catalog_order_idx'
  ) THEN
    CREATE INDEX products_catalog_order_idx ON products(catalog_order);
  END IF;
END $$;