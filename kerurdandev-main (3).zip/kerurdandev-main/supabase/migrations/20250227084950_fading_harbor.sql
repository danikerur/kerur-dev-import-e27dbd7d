/*
  # Fix Dimensions Structure

  1. Updates
    - Ensure dimensions field has proper structure
    - Add default empty array for dimensions if null
  
  2. Data Migration
    - Add a function to migrate existing products without dimensions
*/

-- Ensure dimensions is never null
UPDATE products 
SET dimensions = '[]'::jsonb 
WHERE dimensions IS NULL;

-- Create a function to migrate products without dimensions
CREATE OR REPLACE FUNCTION migrate_product_dimensions()
RETURNS void AS $$
DECLARE
  product_record RECORD;
BEGIN
  FOR product_record IN 
    SELECT id, specifications 
    FROM products 
    WHERE (dimensions IS NULL OR dimensions = '[]'::jsonb OR jsonb_array_length(dimensions) = 0)
      AND specifications IS NOT NULL
  LOOP
    -- Create a dimension from specifications
    UPDATE products
    SET dimensions = jsonb_build_array(
      jsonb_build_object(
        'id', '1',
        'length', COALESCE((specifications->>'length')::numeric, 0),
        'width', COALESCE((specifications->>'width')::numeric, 0),
        'height', COALESCE((specifications->>'height')::numeric, 0)
      )
    )
    WHERE id = product_record.id;
  END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Run the migration function
SELECT migrate_product_dimensions();

-- Drop the function after use
DROP FUNCTION migrate_product_dimensions();