/*
  # Fix catalog visibility for products

  1. Changes
    - Ensures all products have catalog_visible set to true by default
    - Updates any existing products with null catalog_visible to true
  
  2. Purpose
    - Fixes issue where products aren't showing in the catalog
*/

-- Set default value for catalog_visible to true if not already set
ALTER TABLE products 
ALTER COLUMN catalog_visible SET DEFAULT true;

-- Update any existing products with null or false catalog_visible to true
UPDATE products 
SET catalog_visible = true 
WHERE catalog_visible IS NULL OR catalog_visible = false;