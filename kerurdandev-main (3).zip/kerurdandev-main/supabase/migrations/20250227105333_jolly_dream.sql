-- Set all products to be visible in the catalog
UPDATE products 
SET catalog_visible = true 
WHERE catalog_visible IS NULL OR catalog_visible = false;

-- Ensure the catalog_visible column has a default value of true
ALTER TABLE products 
ALTER COLUMN catalog_visible SET DEFAULT true;

-- Add a comment to explain what this migration does
COMMENT ON COLUMN products.catalog_visible IS 'Controls whether the product is visible in the public catalog (default: true)';