/*
  # Fix catalog visibility for all products

  1. Updates
    - Sets all products to be visible in the catalog by default
    - Updates any products with null or false visibility to true
    - Adds a comment explaining the purpose of the column

  2. Changes
    - Sets the default value for catalog_visible to true
    - Updates existing products to ensure they're visible in the catalog
*/

-- Set all products to be visible in the catalog
UPDATE products 
SET catalog_visible = true 
WHERE catalog_visible IS NULL OR catalog_visible = false;

-- Ensure the catalog_visible column has a default value of true
ALTER TABLE products 
ALTER COLUMN catalog_visible SET DEFAULT true;

-- Add a comment to explain what this migration does
COMMENT ON COLUMN products.catalog_visible IS 'Controls whether the product is visible in the public catalog (default: true)';