/*
  # Add tag column to products table

  1. Changes
    - Add a new `tag` column to the products table to store product tags
    - This allows displaying tags like "חדש", "מבצע", etc. on products in the catalog
*/

-- Add tag column to products table if it doesn't exist
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'products' AND column_name = 'tag'
  ) THEN
    ALTER TABLE products ADD COLUMN tag TEXT DEFAULT NULL;
  END IF;
END $$;

-- Add comment to explain the purpose of the tag column
COMMENT ON COLUMN products.tag IS 'Optional tag to display on product in catalog (e.g., "חדש", "מבצע", "מומלץ")';