/*
  # Enable public access to catalog products
  
  1. Changes
    - Add a policy to allow public (unauthenticated) users to read products
    - This enables the catalog page to be accessible without login
  
  2. Security
    - Only allows READ access (SELECT)
    - Only allows access to products where catalog_visible is true
*/

-- Check if the policy for products already exists before creating it
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'products' AND policyname = 'Allow public access to catalog products'
  ) THEN
    -- Create policy to allow public access to products that are marked as visible in catalog
    EXECUTE 'CREATE POLICY "Allow public access to catalog products" ON products FOR SELECT TO public USING (catalog_visible = true)';
  END IF;
END $$;

-- Check if the policy for categories already exists before creating it
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'categories' AND policyname = 'Allow public access to categories'
  ) THEN
    -- Create policy to allow public access to categories
    EXECUTE 'CREATE POLICY "Allow public access to categories" ON categories FOR SELECT TO public USING (true)';
  END IF;
END $$;