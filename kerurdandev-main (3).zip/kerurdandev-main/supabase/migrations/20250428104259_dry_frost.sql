/*
  # Add Delivery Management System

  1. New Tables
    - `drivers` - Store delivery driver information
      - `id` (uuid, primary key)
      - `full_name` (text)
      - `phone` (text)
      - `notes` (text)
      - `created_at` (timestamp)
    
    - `deliveries` - Store delivery information
      - `id` (uuid, primary key)
      - `driver_id` (uuid, foreign key)
      - `delivery_date` (date)
      - `status` (text)
      - `created_at` (timestamp)
    
    - `delivery_customers` - Store customers in a delivery
      - `id` (uuid, primary key)
      - `delivery_id` (uuid, foreign key)
      - `customer_id` (uuid, foreign key)
      - `delivery_price` (numeric)
      - `notes` (text)
      - `address` (text)
      - `order` (integer)
      - `created_at` (timestamp)
    
    - `delivery_products` - Store products for each customer in a delivery
      - `id` (uuid, primary key)
      - `delivery_customer_id` (uuid, foreign key)
      - `product_id` (uuid, foreign key)
      - `quantity` (integer)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create enum for delivery status
CREATE TYPE delivery_status AS ENUM ('planned', 'completed', 'canceled');

-- Create drivers table
CREATE TABLE drivers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  phone text NOT NULL,
  notes text,
  created_at timestamptz DEFAULT now()
);

-- Create deliveries table
CREATE TABLE deliveries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  driver_id uuid REFERENCES drivers(id) ON DELETE SET NULL,
  delivery_date date,
  status delivery_status DEFAULT 'planned',
  created_at timestamptz DEFAULT now()
);

-- Create delivery_customers table
CREATE TABLE delivery_customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  delivery_id uuid REFERENCES deliveries(id) ON DELETE CASCADE,
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE,
  delivery_price numeric(10,2),
  notes text,
  address text NOT NULL,
  "order" integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create delivery_products table
CREATE TABLE delivery_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  delivery_customer_id uuid REFERENCES delivery_customers(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id) ON DELETE RESTRICT,
  quantity integer NOT NULL CHECK (quantity > 0),
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE drivers ENABLE ROW LEVEL SECURITY;
ALTER TABLE deliveries ENABLE ROW LEVEL SECURITY;
ALTER TABLE delivery_customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE delivery_products ENABLE ROW LEVEL SECURITY;

-- Create policies for drivers
CREATE POLICY "Enable all access for authenticated users" ON drivers
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create policies for deliveries
CREATE POLICY "Enable all access for authenticated users" ON deliveries
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create policies for delivery_customers
CREATE POLICY "Enable all access for authenticated users" ON delivery_customers
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create policies for delivery_products
CREATE POLICY "Enable all access for authenticated users" ON delivery_products
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create indexes for better performance
CREATE INDEX drivers_phone_idx ON drivers(phone);
CREATE INDEX deliveries_date_idx ON deliveries(delivery_date);
CREATE INDEX deliveries_status_idx ON deliveries(status);
CREATE INDEX delivery_customers_order_idx ON delivery_customers("order");
CREATE INDEX delivery_customers_delivery_id_idx ON delivery_customers(delivery_id);
CREATE INDEX delivery_products_delivery_customer_id_idx ON delivery_products(delivery_customer_id);