/*
  # Add dimension index column to delivery products

  1. Changes
    - Add `dimension_index` column to `delivery_products` table
      - Type: integer
      - Nullable: true (to accommodate existing data)
      - Description: Stores the index of the selected dimension for products with multiple dimensions

  2. Notes
    - The column is made nullable to ensure compatibility with existing data
    - No default value is set since it's optional and depends on product configuration
*/

DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'delivery_products' 
    AND column_name = 'dimension_index'
  ) THEN
    ALTER TABLE delivery_products 
    ADD COLUMN dimension_index integer;
  END IF;
END $$;