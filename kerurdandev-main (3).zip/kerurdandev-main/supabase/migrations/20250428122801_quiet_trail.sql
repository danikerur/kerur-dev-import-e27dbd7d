-- Ensure delivery_customers has proper coordinate columns
DO $$ 
BEGIN
  -- Add latitude column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'delivery_customers' 
    AND column_name = 'latitude'
  ) THEN
    ALTER TABLE delivery_customers ADD COLUMN latitude double precision;
  END IF;

  -- Add longitude column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'delivery_customers' 
    AND column_name = 'longitude'
  ) THEN
    ALTER TABLE delivery_customers ADD COLUMN longitude double precision;
  END IF;
END $$;