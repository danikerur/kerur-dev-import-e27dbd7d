DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'delivery_products' 
    AND column_name = 'dimension_index'
  ) THEN
    ALTER TABLE delivery_products 
    ADD COLUMN dimension_index integer;
  END IF;
END $$;