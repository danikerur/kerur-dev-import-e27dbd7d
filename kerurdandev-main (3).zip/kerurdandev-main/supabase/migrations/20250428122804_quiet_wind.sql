DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'delivery_products' 
    AND column_name = 'product_size'
  ) THEN
    ALTER TABLE delivery_products 
    ADD COLUMN product_size jsonb DEFAULT NULL;

    -- Add comment explaining the column's purpose
    COMMENT ON COLUMN delivery_products.product_size IS 'Stores the selected dimensions (length, width, height) for the product at the time of delivery';
  END IF;
END $$;