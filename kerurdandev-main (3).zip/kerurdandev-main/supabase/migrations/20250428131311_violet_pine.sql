/*
  # Add update_delivery function
  
  1. New Functions
    - `update_delivery`: Updates a delivery record and its associated customers
      Parameters:
      - p_delivery_id: UUID of the delivery to update
      - p_driver_id: UUID of the assigned driver
      - p_delivery_date: Date of the delivery
      - p_status: delivery_status enum value
      - p_customers: JSONB array of customer data
      
  2. Function Details
    - Updates the main delivery record
    - Handles customer updates, including:
      - Order sequence
      - Delivery price
      - Notes
      - Address
      - Coordinates
    - Updates associated delivery products
*/

CREATE OR REPLACE FUNCTION public.update_delivery(
  p_delivery_id UUID,
  p_driver_id UUID,
  p_delivery_date DATE,
  p_status delivery_status,
  p_customers JSONB
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  customer_data JSONB;
  delivery_customer_id UUID;
  product_data JSONB;
BEGIN
  -- Update the main delivery record
  UPDATE deliveries
  SET 
    driver_id = p_driver_id,
    delivery_date = p_delivery_date,
    status = p_status
  WHERE id = p_delivery_id;

  -- Delete existing delivery_customers that are not in the new list
  DELETE FROM delivery_customers
  WHERE delivery_id = p_delivery_id
  AND id NOT IN (
    SELECT (value->>'id')::UUID 
    FROM jsonb_array_elements(p_customers)
    WHERE value->>'id' IS NOT NULL
  );

  -- Update or insert delivery customers
  FOR customer_data IN SELECT * FROM jsonb_array_elements(p_customers)
  LOOP
    -- Check if delivery customer exists
    IF (customer_data->>'id') IS NOT NULL THEN
      delivery_customer_id := (customer_data->>'id')::UUID;
      
      -- Update existing delivery customer
      UPDATE delivery_customers
      SET
        delivery_price = NULLIF(customer_data->>'delivery_price', '')::NUMERIC,
        notes = customer_data->>'notes',
        address = customer_data->>'address',
        "order" = (customer_data->>'order')::INTEGER,
        latitude = NULLIF(customer_data->>'latitude', '')::DOUBLE PRECISION,
        longitude = NULLIF(customer_data->>'longitude', '')::DOUBLE PRECISION
      WHERE id = delivery_customer_id;

      -- Delete existing delivery products for this customer
      DELETE FROM delivery_products
      WHERE delivery_customer_id = delivery_customer_id;
    ELSE
      -- Insert new delivery customer
      INSERT INTO delivery_customers (
        delivery_id,
        customer_id,
        delivery_price,
        notes,
        address,
        "order",
        latitude,
        longitude
      )
      VALUES (
        p_delivery_id,
        (customer_data->>'customer_id')::UUID,
        NULLIF(customer_data->>'delivery_price', '')::NUMERIC,
        customer_data->>'notes',
        customer_data->>'address',
        (customer_data->>'order')::INTEGER,
        NULLIF(customer_data->>'latitude', '')::DOUBLE PRECISION,
        NULLIF(customer_data->>'longitude', '')::DOUBLE PRECISION
      )
      RETURNING id INTO delivery_customer_id;
    END IF;

    -- Insert new delivery products
    FOR product_data IN SELECT * FROM jsonb_array_elements(customer_data->'products')
    LOOP
      INSERT INTO delivery_products (
        delivery_customer_id,
        product_id,
        quantity,
        dimension_index,
        product_size
      )
      VALUES (
        delivery_customer_id,
        (product_data->>'product_id')::UUID,
        (product_data->>'quantity')::INTEGER,
        (product_data->>'dimension_index')::INTEGER,
        product_data->'product_size'
      );
    END LOOP;
  END LOOP;

  RETURN p_delivery_id;
END;
$$;