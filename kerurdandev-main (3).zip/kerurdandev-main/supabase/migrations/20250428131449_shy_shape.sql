/*
  # Fix update_delivery function

  1. Changes
    - Drop and recreate update_delivery function to fix return type
    - Fix ambiguous column references
    - Improve error handling and validation

  2. Security
    - Function remains accessible to authenticated users only
*/

-- Drop existing function first
DROP FUNCTION IF EXISTS update_delivery(uuid,uuid,date,delivery_status,jsonb);

-- Create new function
CREATE FUNCTION update_delivery(
  p_delivery_id uuid,
  p_driver_id uuid,
  p_delivery_date date,
  p_status delivery_status,
  p_customers jsonb
) RETURNS void AS $$
DECLARE
  customer_record jsonb;
  product_record jsonb;
  delivery_customer_id uuid;
  delivery_product_id uuid;
BEGIN
  -- Update delivery
  UPDATE deliveries
  SET 
    driver_id = p_driver_id,
    delivery_date = p_delivery_date,
    status = p_status
  WHERE id = p_delivery_id;

  -- Delete existing delivery_customers and their products
  DELETE FROM delivery_products 
  WHERE delivery_customer_id IN (
    SELECT id FROM delivery_customers WHERE delivery_id = p_delivery_id
  );
  DELETE FROM delivery_customers WHERE delivery_id = p_delivery_id;

  -- Insert new customers and products
  FOR customer_record IN SELECT * FROM jsonb_array_elements(p_customers)
  LOOP
    -- Insert delivery customer
    INSERT INTO delivery_customers (
      id,
      delivery_id,
      customer_id,
      delivery_price,
      notes,
      address,
      "order"
    ) VALUES (
      (customer_record->>'id')::uuid,
      p_delivery_id,
      (customer_record->>'customer_id')::uuid,
      (customer_record->>'delivery_price')::numeric,
      customer_record->>'notes',
      customer_record->>'address',
      (customer_record->>'order')::integer
    )
    RETURNING id INTO delivery_customer_id;

    -- Insert products for this customer
    FOR product_record IN SELECT * FROM jsonb_array_elements(customer_record->'products')
    LOOP
      INSERT INTO delivery_products (
        id,
        delivery_customer_id,
        product_id,
        quantity
      ) VALUES (
        (product_record->>'id')::uuid,
        delivery_customer_id,
        (product_record->>'product_id')::uuid,
        (product_record->>'quantity')::integer
      );
    END LOOP;
  END LOOP;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Update function permissions
REVOKE ALL ON FUNCTION update_delivery FROM PUBLIC;
GRANT EXECUTE ON FUNCTION update_delivery TO authenticated;