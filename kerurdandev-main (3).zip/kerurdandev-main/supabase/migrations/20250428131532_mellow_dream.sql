/*
  # Fix ambiguous column reference in update_delivery function

  1. Changes
    - Drop and recreate the update_delivery function with properly qualified column references
    - Add explicit table aliases to avoid ambiguity
    - Ensure all column references are properly qualified

  2. Security
    - Maintain existing security context (function runs with invoker's rights)
    - No changes to access control
*/

CREATE OR REPLACE FUNCTION update_delivery(
  p_delivery_id uuid,
  p_driver_id uuid,
  p_delivery_date date,
  p_status delivery_status,
  p_customers jsonb
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_customer jsonb;
  v_product jsonb;
  v_delivery_customer_id uuid;
  v_delivery_product_id uuid;
BEGIN
  -- Update delivery
  UPDATE deliveries
  SET
    driver_id = p_driver_id,
    delivery_date = p_delivery_date,
    status = p_status
  WHERE id = p_delivery_id;

  -- Delete existing delivery_products that are no longer in the updated list
  DELETE FROM delivery_products dp
  WHERE dp.delivery_customer_id IN (
    SELECT dc.id 
    FROM delivery_customers dc 
    WHERE dc.delivery_id = p_delivery_id
  );

  -- Delete existing delivery_customers
  DELETE FROM delivery_customers
  WHERE delivery_id = p_delivery_id;

  -- Insert new delivery_customers and their products
  FOR v_customer IN SELECT * FROM jsonb_array_elements(p_customers)
  LOOP
    -- Insert delivery_customer
    INSERT INTO delivery_customers (
      id,
      delivery_id,
      customer_id,
      delivery_price,
      notes,
      address,
      latitude,
      longitude,
      "order"
    )
    VALUES (
      (v_customer->>'id')::uuid,
      p_delivery_id,
      (v_customer->>'customer_id')::uuid,
      (v_customer->>'delivery_price')::numeric,
      v_customer->>'notes',
      v_customer->>'address',
      (v_customer->>'latitude')::float8,
      (v_customer->>'longitude')::float8,
      (v_customer->>'order')::integer
    )
    RETURNING id INTO v_delivery_customer_id;

    -- Insert delivery_products for this customer
    FOR v_product IN SELECT * FROM jsonb_array_elements(v_customer->'products')
    LOOP
      INSERT INTO delivery_products (
        id,
        delivery_customer_id,
        product_id,
        quantity,
        dimension_index
      )
      VALUES (
        (v_product->>'id')::uuid,
        v_delivery_customer_id,
        (v_product->>'product_id')::uuid,
        (v_product->>'quantity')::integer,
        (v_product->>'dimension_index')::integer
      );
    END LOOP;
  END LOOP;
END;
$$;