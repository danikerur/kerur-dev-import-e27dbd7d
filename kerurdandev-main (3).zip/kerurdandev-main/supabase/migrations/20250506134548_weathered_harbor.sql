/*
  # Add Inventory Management System

  1. New Tables
    - `warehouses` - Store warehouse information
      - `id` (uuid, primary key)
      - `name` (text)
      - `location` (text, nullable)
      - `created_at` (timestamp)
    
    - `warehouse_inventory` - Store inventory levels for each product in each warehouse
      - `id` (uuid, primary key)
      - `warehouse_id` (uuid, foreign key)
      - `product_id` (uuid, foreign key)
      - `quantity` (integer)
      - `updated_at` (timestamp)

  2. Changes to Existing Tables
    - Add `product_code` and `supplier` to products table
    
  3. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Add new columns to products table
ALTER TABLE products
ADD COLUMN IF NOT EXISTS product_code text,
ADD COLUMN IF NOT EXISTS supplier text;

-- Create warehouses table
CREATE TABLE warehouses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  location text,
  created_at timestamptz DEFAULT now()
);

-- Create warehouse_inventory table
CREATE TABLE warehouse_inventory (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  warehouse_id uuid REFERENCES warehouses(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id) ON DELETE CASCADE,
  quantity integer NOT NULL DEFAULT 0,
  updated_at timestamptz DEFAULT now(),
  -- Add unique constraint to prevent duplicate entries
  UNIQUE(warehouse_id, product_id)
);

-- Create trigger to update updated_at
CREATE TRIGGER update_warehouse_inventory_updated_at
  BEFORE UPDATE ON warehouse_inventory
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Enable RLS
ALTER TABLE warehouses ENABLE ROW LEVEL SECURITY;
ALTER TABLE warehouse_inventory ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable all access for authenticated users" ON warehouses
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Enable all access for authenticated users" ON warehouse_inventory
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create indexes for better performance
CREATE INDEX warehouse_inventory_warehouse_id_idx ON warehouse_inventory(warehouse_id);
CREATE INDEX warehouse_inventory_product_id_idx ON warehouse_inventory(product_id);