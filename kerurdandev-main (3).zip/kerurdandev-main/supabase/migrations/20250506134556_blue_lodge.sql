/*
  # Add Inventory Management Functions

  1. New Functions
    - `update_inventory_on_delivery`: Updates inventory levels when a delivery is created/updated
    - This function is triggered when a delivery is created or updated
*/

-- Function to update inventory when a delivery is created/updated
CREATE OR REPLACE FUNCTION update_inventory_on_delivery()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  delivery_customer RECORD;
  delivery_product RECORD;
  warehouse_id UUID;
BEGIN
  -- Get the warehouse ID (in the future, this could be configurable per delivery)
  SELECT id INTO warehouse_id FROM warehouses LIMIT 1;
  
  -- If no warehouse exists yet, do nothing
  IF warehouse_id IS NULL THEN
    RETURN NULL;
  END IF;

  -- For each customer in the delivery
  FOR delivery_customer IN 
    SELECT * FROM delivery_customers 
    WHERE delivery_id = NEW.id
  LOOP
    -- For each product in the delivery
    FOR delivery_product IN 
      SELECT * FROM delivery_products 
      WHERE delivery_customer_id = delivery_customer.id
    LOOP
      -- Insert or update inventory record
      INSERT INTO warehouse_inventory (
        warehouse_id,
        product_id,
        quantity
      ) VALUES (
        warehouse_id,
        delivery_product.product_id,
        0
      )
      ON CONFLICT (warehouse_id, product_id) DO UPDATE
      SET quantity = warehouse_inventory.quantity - EXCLUDED.quantity;
    END LOOP;
  END LOOP;

  RETURN NEW;
END;
$$;

-- Create trigger for deliveries
CREATE TRIGGER update_inventory_after_delivery
  AFTER INSERT OR UPDATE ON deliveries
  FOR EACH ROW
  EXECUTE FUNCTION update_inventory_on_delivery();