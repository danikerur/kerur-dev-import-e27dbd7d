/*
  # Add product size column to warehouse inventory

  1. Changes
    - Add `product_size` JSONB column to `warehouse_inventory` table to store product dimensions
      - Stores length, width, and height values for each inventory item
      - Uses JSONB type to allow flexible dimension storage
      - Defaults to NULL to maintain compatibility with existing records

  2. Notes
    - Column is nullable to support legacy records
    - JSONB type allows storing structured dimension data
*/

DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'warehouse_inventory' 
    AND column_name = 'product_size'
  ) THEN
    ALTER TABLE warehouse_inventory 
    ADD COLUMN product_size JSONB;
  END IF;
END $$;