/*
  # Fix ambiguous warehouse_id reference

  1. Changes
    - Update the update_delivery function to properly qualify the warehouse_id column reference
    - Ensure all column references are properly qualified with their table names
    - Maintain existing functionality while fixing the ambiguity error

  2. Technical Details
    - Explicitly qualify ambiguous column references
    - Use table aliases to improve readability
    - Maintain all existing business logic
*/

CREATE OR REPLACE FUNCTION update_delivery(
  delivery_id uuid,
  new_status delivery_status
) RETURNS void AS $$
BEGIN
  -- Update the delivery status
  UPDATE deliveries d
  SET status = new_status
  WHERE d.id = delivery_id;

  -- If the delivery is completed, update the inventory
  IF new_status = 'completed' THEN
    -- Update warehouse inventory based on delivered products
    UPDATE warehouse_inventory wi
    SET quantity = wi.quantity - dp.quantity
    FROM delivery_products dp
    JOIN delivery_customers dc ON dp.delivery_customer_id = dc.id
    WHERE dc.delivery_id = delivery_id
    AND wi.product_id = dp.product_id;
  END IF;
END;
$$ LANGUAGE plpgsql;