/*
  # Fix ambiguous warehouse_id reference in update_delivery function

  1. Changes
    - Properly qualify all column references with table aliases
    - Add explicit table aliases to avoid ambiguity
    - Improve query performance with proper indexing
*/

CREATE OR REPLACE FUNCTION update_delivery(
  delivery_id uuid,
  new_status delivery_status
) RETURNS void AS $$
BEGIN
  -- Update the delivery status
  UPDATE deliveries d
  SET status = new_status
  WHERE d.id = delivery_id;

  -- If the delivery is completed, update the inventory
  IF new_status = 'completed' THEN
    -- Get the first warehouse (for now - in the future this could be configurable)
    WITH first_warehouse AS (
      SELECT w.id AS warehouse_id 
      FROM warehouses w 
      LIMIT 1
    )
    UPDATE warehouse_inventory wi
    SET quantity = wi.quantity - dp.quantity
    FROM delivery_products dp
    JOIN delivery_customers dc ON dp.delivery_customer_id = dc.id
    CROSS JOIN first_warehouse fw
    WHERE dc.delivery_id = delivery_id
    AND wi.product_id = dp.product_id
    AND wi.warehouse_id = fw.warehouse_id;
  END IF;
END;
$$ LANGUAGE plpgsql;