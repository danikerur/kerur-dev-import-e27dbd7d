/*
  # Fix delivery status update function

  1. Changes
    - Simplify the update_delivery function to focus only on status updates
    - Remove inventory management for now to fix the core functionality
    - Add proper error handling
*/

CREATE OR REPLACE FUNCTION update_delivery_status(
  p_delivery_id uuid,
  p_status delivery_status
) RETURNS void AS $$
BEGIN
  -- Update the delivery status
  UPDATE deliveries
  SET status = p_status
  WHERE id = p_delivery_id;
END;
$$ LANGUAGE plpgsql;