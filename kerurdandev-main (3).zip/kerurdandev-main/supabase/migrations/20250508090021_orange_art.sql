/*
  # Fix delivery status update function
  
  1. Changes
    - Simplify the function to only update status
    - Remove inventory management (will be handled separately)
    - Add proper error handling
*/

CREATE OR REPLACE FUNCTION update_delivery_status(
  p_delivery_id uuid,
  p_status delivery_status
) RETURNS void AS $$
BEGIN
  -- Update the delivery status
  UPDATE deliveries
  SET status = p_status
  WHERE id = p_delivery_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Delivery with ID % not found', p_delivery_id;
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION update_delivery_status TO authenticated;