/*
  # Fix warehouse inventory unique constraint for dimensions

  1. Changes
    - Drop existing unique constraint that only checks warehouse_id and product_id
    - Create a new function to generate a unique key from product dimensions
    - Add new unique constraint using the generated key
    - This allows multiple entries for the same product with different dimensions
*/

-- Drop the existing unique constraint
ALTER TABLE warehouse_inventory 
DROP CONSTRAINT IF EXISTS warehouse_inventory_warehouse_id_product_id_key;

-- Create function to generate unique key from dimensions
CREATE OR REPLACE FUNCTION generate_inventory_key(warehouse_id uuid, product_id uuid, product_size jsonb)
RETURNS text AS $$
BEGIN
  RETURN warehouse_id::text || '_' || 
         product_id::text || '_' || 
         COALESCE(product_size->>'length', '') || '_' ||
         COALESCE(product_size->>'width', '') || '_' ||
         COALESCE(product_size->>'height', '');
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Add generated column for the unique key
ALTER TABLE warehouse_inventory
ADD COLUMN IF NOT EXISTS inventory_key text
GENERATED ALWAYS AS (generate_inventory_key(warehouse_id, product_id, product_size)) STORED;

-- Add unique constraint on the generated key
ALTER TABLE warehouse_inventory
ADD CONSTRAINT warehouse_inventory_unique_dimensions
UNIQUE (inventory_key);