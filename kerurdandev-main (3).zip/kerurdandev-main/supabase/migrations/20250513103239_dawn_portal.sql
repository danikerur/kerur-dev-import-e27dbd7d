/*
  # Add Supplier Management System

  1. New Tables
    - `suppliers` - Store supplier information
      - `id` (uuid, primary key)
      - `name` (text)
      - `contact_name` (text)
      - `phone` (text)
      - `email` (text)
      - `country` (text)
      - `notes` (text)
      - `created_at` (timestamp)
    
    - `supplier_orders` - Store orders from suppliers
      - `id` (uuid, primary key)
      - `supplier_id` (uuid, foreign key)
      - `status` (enum: open, ordered, delivered)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `supplier_order_items` - Store items in supplier orders
      - `id` (uuid, primary key)
      - `order_id` (uuid, foreign key)
      - `product_id` (uuid, foreign key)
      - `quantity` (integer)
      - `created_at` (timestamp)

  2. Changes to Existing Tables
    - Add supplier_id to products table
    
  3. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create enum for supplier order status
CREATE TYPE supplier_order_status AS ENUM ('open', 'ordered', 'delivered');

-- Create suppliers table
CREATE TABLE suppliers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  contact_name text,
  phone text,
  email text,
  country text,
  notes text,
  created_at timestamptz DEFAULT now()
);

-- Create supplier_orders table
CREATE TABLE supplier_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  supplier_id uuid REFERENCES suppliers(id) ON DELETE CASCADE,
  status supplier_order_status DEFAULT 'open',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create supplier_order_items table
CREATE TABLE supplier_order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES supplier_orders(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id) ON DELETE CASCADE,
  quantity integer NOT NULL CHECK (quantity > 0),
  created_at timestamptz DEFAULT now()
);

-- Add supplier_id to products table
ALTER TABLE products
ADD COLUMN supplier_id uuid REFERENCES suppliers(id) ON DELETE SET NULL;

-- Enable Row Level Security
ALTER TABLE suppliers ENABLE ROW LEVEL SECURITY;
ALTER TABLE supplier_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE supplier_order_items ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable all access for authenticated users" ON suppliers
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Enable all access for authenticated users" ON supplier_orders
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Enable all access for authenticated users" ON supplier_order_items
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create indexes for better performance
CREATE INDEX suppliers_name_idx ON suppliers(name);
CREATE INDEX supplier_orders_supplier_id_idx ON supplier_orders(supplier_id);
CREATE INDEX supplier_orders_status_idx ON supplier_orders(status);
CREATE INDEX supplier_order_items_order_id_idx ON supplier_order_items(order_id);
CREATE INDEX supplier_order_items_product_id_idx ON supplier_order_items(product_id);
CREATE INDEX products_supplier_id_idx ON products(supplier_id);

-- Create trigger to update updated_at
CREATE TRIGGER update_supplier_orders_updated_at
  BEFORE UPDATE ON supplier_orders
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();