ALTER TABLE supplier_shipments
ADD COLUMN supplier_tracking_number text;
