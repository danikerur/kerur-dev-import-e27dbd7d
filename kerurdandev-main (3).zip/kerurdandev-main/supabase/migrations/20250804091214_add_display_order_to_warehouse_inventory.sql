-- Add display_order column to warehouse_inventory table
ALTER TABLE warehouse_inventory 
ADD COLUMN display_order INTEGER;

-- Create index for better performance when sorting by display_order
CREATE INDEX idx_warehouse_inventory_display_order 
ON warehouse_inventory(warehouse_id, display_order); 