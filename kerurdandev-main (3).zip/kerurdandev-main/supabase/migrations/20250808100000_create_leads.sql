-- Create leads table
create table if not exists public.leads (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  customer_name text,
  business_name text,
  city text,
  phone text,
  inquiry_date date default (now() at time zone 'utc')::date,
  status text default 'חדש',
  call_summary text,
  inserted_by uuid references auth.users(id)
);

-- trigger to update updated_at
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists set_leads_updated_at on public.leads;
create trigger set_leads_updated_at
before update on public.leads
for each row execute function public.set_updated_at();

-- Enable RLS
alter table public.leads enable row level security;

-- Policies: allow authenticated users CRUD
drop policy if exists "leads_select" on public.leads;
create policy "leads_select" on public.leads
  for select
  to authenticated
  using (true);

drop policy if exists "leads_insert" on public.leads;
create policy "leads_insert" on public.leads
  for insert
  to authenticated
  with check (true);

drop policy if exists "leads_update" on public.leads;
create policy "leads_update" on public.leads
  for update
  to authenticated
  using (true)
  with check (true);

drop policy if exists "leads_delete" on public.leads;
create policy "leads_delete" on public.leads
  for delete
  to authenticated
  using (true);


