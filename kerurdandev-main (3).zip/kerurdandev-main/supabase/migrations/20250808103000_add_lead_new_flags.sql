-- Add flags to support unseen/new markers and source of creation
alter table public.leads
  add column if not exists is_new boolean not null default true,
  add column if not exists created_via text not null default 'manual';

-- Backfill existing rows to not be considered new
update public.leads
set is_new = false
where is_new is distinct from false;

-- Helpful index for counting/filtering new leads quickly
create index if not exists idx_leads_is_new_created_at on public.leads (is_new, created_at desc);



