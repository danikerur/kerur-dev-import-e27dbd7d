/*
  # Disable delivery-driven inventory deduction

  1. Changes
    - Drop the deliveries trigger that attempted to update inventory on insert/update
    - Drop the update_inventory_on_delivery() helper function (no longer needed)
    - Override the 2-arg update_delivery(delivery_id, new_status) function to ONLY update status
      and NOT touch warehouse inventory (to prevent double-deduction with order fulfillment)
*/

-- Safe drop: trigger may or may not exist in target environment
DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_trigger
    WHERE tgname = 'update_inventory_after_delivery'
  ) THEN
    EXECUTE 'DROP TRIGGER update_inventory_after_delivery ON deliveries';
  END IF;
END $$;

-- Safe drop: helper function may exist
DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_proc
    WHERE proname = 'update_inventory_on_delivery'
  ) THEN
    EXECUTE 'DROP FUNCTION IF EXISTS update_inventory_on_delivery()';
  END IF;
END $$;

-- Replace the 2-arg function to ONLY update status; no inventory modifications here.
CREATE OR REPLACE FUNCTION update_delivery(
  delivery_id uuid,
  new_status delivery_status
) RETURNS void AS $$
BEGIN
  UPDATE deliveries d
  SET status = new_status
  WHERE d.id = delivery_id;
  -- Intentionally no inventory updates here to avoid double-deduction.
END;
$$ LANGUAGE plpgsql;


